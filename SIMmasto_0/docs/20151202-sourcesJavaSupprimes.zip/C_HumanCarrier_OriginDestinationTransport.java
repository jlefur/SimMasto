package thing;
import java.util.ArrayList;
import java.util.List;
import simmasto0.C_ContextCreator;
import simmasto0.util.C_PathWanderer;
import thing.dna.I_diploid_genome;
import thing.ground.C_SoilCellGraphed;
import thing.ground.C_Vehicle;
import thing.ground.C_Vehicle_OriginDestinationTransport;

/** @author Mboup 03/07/2015 */
public class C_HumanCarrier_OriginDestinationTransport extends C_HumanCarrier {
	// for  Hcarrier's output (origin and destination)
	private List <String> originDestinationList;

	public C_HumanCarrier_OriginDestinationTransport(I_diploid_genome genome) {
		super(genome);
		this.originDestinationList = new ArrayList<String>();
	}
	/** Get a new vehicle, instantiate the graph (no node in path yet), name the carrier,
	 * @param vehicleType */
	@Override
	public C_Vehicle ownVehicle(String vehicleType) {
		this.vehicle = new C_Vehicle_OriginDestinationTransport(vehicleType, this);
		C_ContextCreator.protocol.contextualizeNewAgentInCell(vehicle, currentSoilCell);
		this.pathWanderer = new C_PathWanderer(this.currentSoilCell);
		this.parked = true;
		this.name = "HC-" + this.vehicle.getType() + NAMES_SEPARATOR + this.myId;
		return this.vehicle;
	}
	@Override
	protected void addOriginDestination(C_SoilCellGraphed currentCityCell, C_SoilCellGraphed targetCityCell){
//		this.originDestinationList.add(
//				currentCityCell.getLandPlot(CITY).getThisName()
//				+CSV_FIELD_SEPARATOR+ targetCityCell.getLandPlot(CITY).getThisName()); //ex. Dakar;Saint-Louis
	}
	public List<String> getOriginDestinationList(){
		return originDestinationList;
	}
}