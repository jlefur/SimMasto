package simmasto0.protocol;
import java.text.ParseException;
import java.util.Date;
import presentation.dataOutput.C_FileWriter;
import presentation.epiphyte.C_InspectorCentenal_OriginDestinationTransport;
import repast.simphony.context.Context;
import simmasto0.C_Calendar;
import thing.C_HumanCarrier;
import thing.C_HumanCarrier_OriginDestinationTransport;
import thing.dna.C_GenomeAmniota;
import thing.ground.C_City;
/** @author Mboup 03/07/2015 */
public class C_ProtocolCentenal_OriginDestinationTransport extends C_ProtocolCentenal {
	private Date startDate;
	private Date endDate;
	private int nbr;
	// CONSTRUCTOR
	public C_ProtocolCentenal_OriginDestinationTransport(Context<Object> ctxt) {
		super(ctxt);
		inspectorTransportation = new C_InspectorCentenal_OriginDestinationTransport();
		nbr = 0;
		try {
//			startDate = C_Calendar.shortDatePattern.parse("24/09/2012 00:00:00");
			startDate = C_Calendar.shortDatePattern.parse("31/12/1910 00:00:00");
			endDate   = C_Calendar.shortDatePattern.parse("01/10/2012 00:00:00");
		} catch(ParseException e) {
			e.printStackTrace();
		}
	}
	// METHODS
	@Override
	protected C_HumanCarrier createCarrier(){
		return new C_HumanCarrier_OriginDestinationTransport(new C_GenomeAmniota());
	}
	@Override
	protected void addRodentsInCity(int nbRodents, C_City city) {}
	/*// le nombre de carrier dans chaque ville
	protected void addCitiesOutputDatas(){
		super.addCitiesOutputDatas();
		if(protocolCalendar.stringShortDate().contains("04/04/")){ revoir use date.after
			if(RepastEssentials.GetTickCount() > tickTester){// allows to avoid to enter 24 times here when tick == 1h for ex.
				((C_InspectorCentenal_OriginDestinationTransport) inspectorTransportation).addOutputDataLineForHCarrier();
				tickTester = Double.MAX_VALUE;
			}
		}else if(tickTester != 0)	tickTester = 0;
	}
	@Override
	//// pour origine-destination
	protected void setHcarriersOutputData(C_HumanCarrier oneHCarrier){
		if(protocolCalendar.getTime().after(startDate) && protocolCalendar.getTime().before(endDate)){
			((C_InspectorCentenal_OriginDestinationTransport) inspectorTransportation)
				.setOriginDestinationOutput(
					((C_HumanCarrier_OriginDestinationTransport) oneHCarrier).getOriginDestinationList());
		}
		((C_HumanCarrier_OriginDestinationTransport) oneHCarrier).getOriginDestinationList().clear();
	}
	@Override
	@Override
	protected void haltSimulation() {
		C_FileWriter file = new C_FileWriter("sommDesCarresDesEcarts.csv", true);
		((C_InspectorCentenal_OriginDestinationTransport) inspectorTransportation).leastSquareSum(file);
		file.closeFile();
		super.haltSimulation();
	}////*/
	@Override
	////pour compter le nombre de fois que chq ville est visit�e
	protected void addCitiesOutputDatas(){
		super.addCitiesOutputDatas();

		((C_InspectorCentenal_OriginDestinationTransport) inspectorTransportation).eachStep();
		if(protocolCalendar.getTime().after(startDate)){
			((C_InspectorCentenal_OriginDestinationTransport) inspectorTransportation).each5years(nbr ++);
			startDate.setYear(startDate.getYear()+5); //TODO PAM number in source
		}
	}
	@Override
	protected void haltSimulation() {
		C_FileWriter file = new C_FileWriter("nbrDeHcarrierArrivInCitiesChq5an.csv", true);
		C_FileWriter file2 = new C_FileWriter("ecartNombreDeHcarrierArrivdInCities.csv", true);
		((C_InspectorCentenal_OriginDestinationTransport) inspectorTransportation).nbrDfoiVisitedCity(file, file2);
		//C_FileWriter file = new C_FileWriter("sommDesCarresDesEcarts.csv", true);
		//((C_InspectorCentenal_OriginDestinationTransport) inspectorTransportation).leastSquareSum(file);
		file.closeFile();
		file2.closeFile();
		super.haltSimulation();
	}////
	@Override
	protected boolean isSimulationEnd() {
		return protocolCalendar.getTime().after(endDate) ;
	}
	@Override
	public String toString() {
		return "C_ProtocolCentenal_OriginDestinationTransport";
	}
}