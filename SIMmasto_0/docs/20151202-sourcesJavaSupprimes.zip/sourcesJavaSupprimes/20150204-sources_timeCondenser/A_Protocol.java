/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt */
package simmasto0.protocol;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.TreeSet;

import presentation.dataOutput.C_FileWriter;
import presentation.display.C_Background;
import presentation.epiphyte.A_Inspector;
import presentation.epiphyte.C_InspectorCMR;
import presentation.epiphyte.C_InspectorPopulation;
import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunState;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.essentials.RepastEssentials;
import repast.simphony.space.Dimensions;
import simmasto0.C_Calendar;
import simmasto0.C_ContextCreator;
import simmasto0.C_Raster;
import simmasto0.I_ground_manager;
import simmasto0.util.C_TimeAndSpaceConverter;
import simmasto0.util.C_TimeCondenser;
import simmasto0.util.C_VariousUtilities;
import simmasto0.util.C_sound;
import thing.A_NDS;
import thing.A_VisibleAgent;
import thing.C_Rodent;
import thing.I_situated_thing;
import thing.dna.C_GenomeAmniota;
import thing.ground.C_SoilCell;
import data.C_Chronogram;
import data.C_Event;
import data.C_Parameters;
import data.I_string_constants;
/** Master class for the various simmasto0.protocol of the SimMasto platform
 * @author Jean Le Fur & Pape Adama Mboup 07.2012, rev. JLF 02.2013, 08.2014, 10.2014 */
public abstract class A_Protocol implements I_protocol, I_string_constants {
	//
	// FIELDS
	//
	protected C_TimeCondenser timeCondenser;
	protected I_ground_manager raster;
	protected Context<Object> context;
	public static C_InspectorPopulation inspector = null;
	protected TreeSet<A_Inspector> inspectorList;
	protected C_FileWriter indicatorsFile; // TODO JLF output file must be managed by inspectors (epiphyte system)
	public static C_Calendar protocolCalendar; // Multiscale contexts: several protocols with their own calendar may run
												// concurrently JLF 08.2014
	protected static Boolean breedingSeason;// TODO JLF put in other place ? (specific to species/environment)
	protected C_Chronogram chronogram = null;// Contains the whole chrono from the csv file
	protected C_Background facilityMap;// used for displaying a bitmap over the grid
	//
	// CONSTRUCTOR
	//
	public A_Protocol(I_ground_manager gm, Context<Object> ctxt) {
		protocolCalendar = new C_Calendar();
		initCalendar();// sets the date for the beginning of the simulation
		System.out.println("A_Protocol.constructor(): simulation starts at " + protocolCalendar.stringLongDate());
		readUserParameters();
		timeCondenser = new C_TimeCondenser(C_Parameters.HC_ACTIVITY_LENGTH_Utick, C_Parameters.HC_TOTAL_TIME_LENGTH_Utick);
		System.out.println("A_Protocol.constructor(): time condenser created");
		inspectorList = new TreeSet<A_Inspector>();
		indicatorsFile = new C_FileWriter(OUTPUT_PATH + "Indicateurs.csv", true);
		raster = gm;
		context = ctxt;
		inspector = new C_InspectorPopulation();
		inspectorList.add(inspector);
		breedingSeason = false;
	}
	//
	// METHODS
	//
	/** In short: make this method inherit its daughters at startup (which is not the case within the constructor (super must be
	 * first)<br>
	 * Longer: Triggered by the context creator at the beginning of the simulation and after constructing the protocol<br>
	 * The procedure can be realized only after all the cascading inspectors and headers have been defined in the subclass hierarchy
	 * i.e., contains procedure that cannot be put in the constructor to avoid the overload when subclasses use super in their
	 * constructor */
	public void initProtocol() {
		System.out.println("A_Protocol.initProtocol(): " + C_ContextCreator.INSPECTOR_NUMBER + " inspectors defined: ");
		recordHeadersInFile();
	}

	/** check the sizes of the rodents'list, manage time stuff, proceed to rodents' step, updates indicators, remove dead agents
	 * Author J.Le Fur 2012, 02.2013, 08.2014 */
	@ScheduledMethod(start = 0, interval = 1)
	public void step_Utick() {
		TreeSet<C_Rodent> rodentList = C_InspectorPopulation.rodentList;
		checkRodentLists(rodentList);
		if (chronogram != null) {
			updateUniverseFromChrono(); // Manage chrono events if protocol used a chrono event file.
		}
		manageTimeLandmarks();
		Iterator<C_Rodent> rodents = rodentList.iterator();
		while (rodents.hasNext())
			// LIVE AND LET DIE RODENTS //
			rodents.next().step_Utick();
		inspector.setNbDeath(removeDeadRodents());// inspector accounts for the changes.
		inspector.step_Utick();
		recordIndicatorsInFile();// manage indicators file
		if (isSimulationEnd()) haltSimulation(); // then close files
	}

	/** Manages time, breeding season, agricultural changes Authors JEL2011, AR, rev. Le Fur 2011,2012,04.2014,08.2014,09.2014 */
	public void manageTimeLandmarks() {
		int currentYear = protocolCalendar.get(Calendar.YEAR);
		// if either active or sleeping (and time to check)
		if (timeCondenser.isTimeToCheck()) timeCondenser.switchTimeCondensedStatus();
		protocolCalendar.incrementDate();
		// beep if start or end of reproduction season
		if (breedingSeason != checkBreedingSeason()) if (C_Parameters.VERBOSE) System.out
				.println("A_Protocol.manageTimeLandmarks() start/end of breeding season");;
		// PERIODIC UNIVERSE MANAGEMENT (each new month/year)
		// TODO JLF 10.2014 should be protocol dependent (or independent: e.g., each 100 ticks)
		// if (protocolCalendar.get(Calendar.MONTH) != currentMonth) {
		// }
		raster.resetCellsColor();
		this.readUserParameters();
		if (protocolCalendar.get(Calendar.YEAR) != currentYear) {
			raster.resetCellsColor();
			// if (C_Parameters.VERBOSE) C_sound.sound("tip.wav");
		}
	}
	/** Update the environment with every events (chrono) occurred at the current date Triggers manageEvent for each new event */
	protected void updateUniverseFromChrono() {
		// chronogram tests dates, retrieves genuine events, processes the string stuff, fills in a TreeSet of C_Event.
		TreeSet<C_Event> readEvents = chronogram.retrieveCurrentEvents(protocolCalendar.getTime());
		if (readEvents != null) { // TODO PAM bug TimeCondensed correction 2 ok pour JLF
			TreeSet<String> eventTypes = new TreeSet<String>();
			int nbEvents = 0;
			for (C_Event oneEvent : readEvents) {
				eventTypes.add(oneEvent.type);
				manageOneEvent(oneEvent);
				nbEvents++;
			}
			manageReadEventTypes(eventTypes);
			// print only if events occurred
			if (nbEvents > 0) System.out.println(getStringShortDate() + " " + nbEvents + " " + " event(s) read of type(s) "
					+ eventTypes);
		}
	}
	protected void manageReadEventTypes(TreeSet<String> eventTypes) {
		// TODO Auto-generated method stub
	}
	/** This method must be redefined in daughter protocols */
	protected void manageOneEvent(C_Event oneEvent) {}
	/** Breeding season declaration : implies that REPRO_START_Umonth < REPRO_END_Umonth */
	private boolean checkBreedingSeason() {
		if (protocolCalendar.get(Calendar.MONTH) >= C_Parameters.REPRO_START_Umonth
				&& protocolCalendar.get(Calendar.MONTH) <= C_Parameters.REPRO_END_Umonth) return (breedingSeason = true);
		else return (breedingSeason = false);
	}
	/** Declares a new object in the context and positions it within the raster ground
	 * @see contextualizeNewAgentInCell(I_situated_thing thing, C_SoilCell cell) */
	protected void contextualizeNewAgentInGrid(I_situated_thing thing, int line_Ucell, int col_Ucell) {
		C_SoilCell cell = raster.getSoilCellsMatrix()[line_Ucell][col_Ucell];
		contextualizeNewAgentInCell(thing, cell);
	}
	/** Declares a new object in the context and positions it within the raster ground */
	public void contextualizeNewAgentInCell(I_situated_thing thing, C_SoilCell cell) {
		if (!context.contains(thing)) {
			context.add(thing);
			raster.moveToLocation(thing, cell.getInternalPointCoordinate());
			cell.agentIncoming(thing);
			if (thing instanceof A_VisibleAgent) ((A_VisibleAgent) thing).bornCoord_Umeter = raster.getCoord_Umeter(thing);
			if (thing instanceof A_NDS) ((A_NDS) thing).setAge_Utick(0);
			if (thing instanceof C_Rodent) {
				inspector.addRodentToList((C_Rodent) thing);
				((C_Rodent) thing).setAge_Utick(C_TimeAndSpaceConverter.days_Utick(C_Parameters.FEMALE_SEXUAL_MATURITY_Uday));
			}
		}
		else System.err.println("A_Protocol.contextualizeNewAgentInCell: " + ((A_NDS) thing).getThisName() + "/"
				+ ((A_NDS) thing).getMyId() + " already exist in context");
	}
	/** Declares a new object in the context and positions it within the raster ground */
	protected void contextualizeOldAgentInGrid(I_situated_thing thing, int line, int col) {
		C_SoilCell cell = raster.getSoilCellsMatrix()[line][col];
		contextualizeOldAgentInCell(thing, cell);
	}
	/** Declares a new object in the context and positions it within the raster ground */
	public void contextualizeOldAgentInCell(I_situated_thing thing, C_SoilCell cell) {
		thing.getCurrentSoilCell().agentLeaving(thing);
		raster.moveToLocation(thing, cell.getInternalPointCoordinate());
		cell.agentIncoming(thing);
	}
	/** LIVE AND LET DIE AGENTS 2/ RODENTS'DEATH PROCEDURE<br>
	 * To avoid concurrent modification exception as well as scrambling the order of rodents, all death procedure mark the rodent as
	 * having to die. The death and remove of dead rodents is then proceeded in one shot <br>
	 * Author J.Le Fur 2012, rev. 02.2013 */
	protected int removeDeadRodents() {
		TreeSet<C_Rodent> rodentList = C_InspectorPopulation.rodentList;
		int nbDeath = 0;
		Object[] table = C_InspectorPopulation.rodentList.toArray();// needed to avoid concurrent modification exception
		for (Object rodent : table) {
			C_Rodent rodent2 = (C_Rodent) rodent;// used since the array could not be cast to C_Rodent (?!)
			if ((rodent2.isMustDie() && !rodent2.trappedOnBoard)) { // rodents that die within their trap may not be correctly
																	// referenced when they leave it
				if (C_Parameters.VERBOSE) System.out.print("/");
				rodentList.remove(rodent2);
				raster.wipeOffObject(rodent2);
				// patch,JLF 26.10.13 TODO JLF&MD wrong place, reset the list in C_InspectorBandia.step() for example
				C_InspectorCMR.taggedRodents.remove(rodent2);
				nbDeath++;
			}
		}
		C_InspectorPopulation.rodentList = rodentList;// Replace with the full rodent list without dead rodents
		return nbDeath;
	}
	@Override
	public void readUserParameters() {
		C_Parameters.VERBOSE = ((Boolean) C_Parameters.parameters.getValue("VERBOSE")).booleanValue();
		initFixedParameters();
	}
	protected void initFixedParameters() {
		C_Parameters.EXCLOS = false; // TODO JLF bug to fix on C_Raster.bordure() when exclos=true
		C_Parameters.TICK_MAX = 0;
		C_Parameters.MAX_POP = 0;
	}
	/** Fills the context with simple _wandering_ C_Rodent agents (as opposed to C_RodentFossorial's that dig burrows) <br>
	 * The sex ratio is randomly generated , rev. JLF 07.2014 currently unused */
	public void randomlyAddRodents(int nbAgent) {
		double[] newLocation = new double[2];
		Dimensions dim = raster.getValueLayer().getDimensions();
		int grid_width = (int) dim.getWidth();
		int grid_height = (int) dim.getHeight();
		for (int i = 0; i < nbAgent; i++) {
			// BELOW, THREE POSSIBLE PATTERNS OF INITIAL DISTRIBUTION :
			// 1) random number to produce a sensitivity analysis
			// int randx = (int)(Math.random()*grid_width);
			// int randy = (int)(Math.random()*grid_height);
			// 2) reproducible random distribution
			int randx = (int) (C_ContextCreator.randomGeneratorForInitialisation.nextDouble() * grid_width);
			int randy = (int) (C_ContextCreator.randomGeneratorForInitialisation.nextDouble() * grid_height);
			// 3) put all rodents at the middle at init:
			// int randx = (int) (grid_width / 2);
			// int randy = (int) (grid_height / 2);

			newLocation[0] = randx * C_Parameters.CELL_SIZE_UcontinuousSpace; // cell / cs.cell^-1 -> cs;
			newLocation[1] = randy * C_Parameters.CELL_SIZE_UcontinuousSpace; // cell / cs.cell^-1 -> cs;

			C_Rodent agent = createRodent();
			// provide a random age to agents at initialization
			long randAge_Uday = Math.round(C_ContextCreator.randomGeneratorForInitialisation.nextDouble() //
					* C_Parameters.FEMALE_SEXUAL_MATURITY_Uday);
			agent.setAge_Utick(C_TimeAndSpaceConverter.days_Utick(randAge_Uday));
			contextualizeNewAgentInGrid(agent, randx, randy);
			agent.getNewRandomDisplacement();
		}
	}
	/** record the current state of every inspectors'indicators in one unique .csv indicatorsFile */
	public void recordIndicatorsInFile() {
		String indicatorValues = "";
		for (A_Inspector inspector : inspectorList) {
			indicatorValues += inspector.getIndicatorsValues();
			indicatorValues += ";";
		}
		indicatorValues += indicatorsFile.getNumRun();
		indicatorsFile.writeln(indicatorValues);
	}
	/** record the current state of every inspectors'indicators in one unique .csv indicatorsFile */
	public void recordHeadersInFile() {
		String indicatorHeader = "";
		for (A_Inspector inspector : inspectorList) {
			indicatorHeader += inspector.getIndicatorsHeader();
			indicatorHeader += ";";
		}
		indicatorHeader += "NumRun";
		System.out.println("A_Protocol.recordHeadersInFile(): " + indicatorHeader);
		indicatorsFile.writeln(indicatorHeader);
	}
	public C_Rodent createRodent() {
		return new C_Rodent(new C_GenomeAmniota());
	}
	/** check rodent list sizes */
	private void checkRodentLists(TreeSet<C_Rodent> rodentList) {
		int withinContext_Urodent = 0, withinSoilMatrix_Urodent = 0;
		Object[] contextContent = RunState.getInstance().getMasterContext().toArray();
		int contextSize = contextContent.length;
		for (int i = 0; i < contextSize; i++) {
			if (contextContent[i] instanceof C_Rodent) withinContext_Urodent++;
		}
		for (int i = 0; i < raster.dim_Ucell.getWidth(); i++) {
			for (int j = 0; j < raster.dim_Ucell.getHeight(); j++) {
				withinSoilMatrix_Urodent += raster.getSoilCellsMatrix()[i][j].getFullRodentList().size();
			}
		}
		if ((withinContext_Urodent != rodentList.size()) || (withinSoilMatrix_Urodent != rodentList.size())) {
			System.err.println("A_Protocol.step: taille des listes diff�rentes: rodentList/context/soilMatrix" + rodentList.size()
					+ "/" + withinContext_Urodent + "/" + withinSoilMatrix_Urodent);
			System.out.println(rodentList);
		}
	}
	/** record the current state of every inspectors'indicators in one unique .csv indicatorsFile */
	protected void haltSimulation() {
		for (A_Inspector inspector : inspectorList) {
			inspector.closeSimulation();
		}
		double simLength = System.currentTimeMillis() - C_ContextCreator.simulationStartTime_Ums;
		C_FileWriter simulationLength = new C_FileWriter("simulationLength_Usecond.csv", true);
		simulationLength.write(simLength / 1000 + "");
		System.out.println("A_Protocol.haltSimulation(), simulation length: " + ((int) simLength / 1000) + "sec. (~"
				+ ((int) simLength / 60000) + "mn, ~" + ((int) simLength / 3600000) + "h.) / Tick "
				+ (int) RepastEssentials.GetTickCount() + ".");
		indicatorsFile.closeFile();
		if (C_Parameters.VERBOSE) C_sound.sound("bip.wav");
		RepastEssentials.EndSimulationRun(); // Halt simulation once all step_Utick() are proceeded !
	}
	/** Display the context on the output (for checking or debugging) */
	public static void printContextFullContent() {
		Object[] list = RunState.getInstance().getMasterContext().toArray();
		System.out.println("=================================");
		System.out.println("A_Protocol, context size/nb agents/current tick: " + list.length + "/" + C_ContextCreator.AGENT_NUMBER
				+ "/" + RepastEssentials.GetTickCount());
		System.out.println("=================================");
		System.out.println("A_Protocol, START OF full context content : ");
		for (int i = 0; i < list.length; i++)
			System.out.println("�l�ment: " + C_VariousUtilities.getShortClassName(list[i].getClass()) + ": " + list[i]);
		System.out.println("A_Protocol, END OF full context content.");
		System.out.println("=================================");
	}
	/** Display the map if on, remove it if off. Only one map object the switch can only go from on to off and vice versa / author
	 * J.Le Fur, 09.2014 */
	protected void switchDisplayMap() {
		if (context.contains(facilityMap)) raster.wipeOffObject(facilityMap);// wipe off map
		System.out.println("A_Protocol.switchDisplayMap()");
		else contextualizeNewAgentInGrid(facilityMap, facilityMap.whereX, facilityMap.whereY);
	}
	/** Sets the initial time for simulation. Sets it to current time if not declared in daughter protocols. */
	public void initCalendar() {
		Date date = new Date();// get current date of the run
		protocolCalendar.set(date.getYear() + 1900, date.getMonth(), date.getDate());
	}
	//
	// GETTERS
	//
	/** @return the current date of the protocol as a short string (jj/mm/aa) */
	public String getStringShortDate() {
		return protocolCalendar.stringShortDate();
	}
	/** @return the current date of the protocol as a long string (day month year)) */
	public String getStringLongDate() {
		return protocolCalendar.stringLongDate();
	}
	/** @return the current date of the protocol as a long string (day month year)) */
	public String getStringHourDate() {
		return protocolCalendar.stringHourDate();
	}
	/** @return the value of seasonToMate (Boolean) */
	public static Boolean isBreedingSeason() {
		return breedingSeason;
	}
	/** Closes the simulation if population is < 2 or if a precondition is verified. <br>
	 * This method may be redefined by daughter protocols */
	protected boolean isSimulationEnd() {
		if ((chronogram != null) && (chronogram.isEndOfChrono)) {
			System.out.println("A_Protocol.isSimulationEnd(), chronogram exhausted; halting simulation");
			return true;
		}
		if (C_Parameters.TICK_MAX != 0 && RepastEssentials.GetTickCount() >= C_Parameters.TICK_MAX) {
			System.out.println("A_Protocol.isSimulationEnd(), TickMax reached; halting simulation");
			return true;
		}
		return false;
	}
}
