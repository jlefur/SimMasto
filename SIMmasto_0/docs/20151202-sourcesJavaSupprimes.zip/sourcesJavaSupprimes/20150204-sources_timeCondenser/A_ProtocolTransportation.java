/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt */
package simmasto0.protocol;

import java.util.ArrayList;
import java.util.Map;
import java.util.TreeSet;
import presentation.display.C_Background;
import presentation.display.C_CustomPanelSet;
import presentation.epiphyte.C_InspectorTransportation;
import repast.simphony.context.Context;
import repast.simphony.essentials.RepastEssentials;
import simmasto0.C_RasterGraph;
import simmasto0.I_ground_manager;
import simmasto0.util.C_Graph;
import simmasto0.util.C_TimeAndSpaceConverter;
import thing.C_HumanCarrier;
import thing.C_Rodent;
import thing.ground.C_City;
import thing.ground.C_LandPlot;
import thing.ground.C_Region;
import thing.ground.C_SoilCell;
import thing.ground.C_SoilCellGraphed;
import data.C_Event;
import data.C_Parameters;
import data.I_transportation_constants;

/** Initialize the simulation and manages the inputs coming from the events file.csv
 * @author J.Le Fur, Mboup 07/2012, rev. P.A.Mboup, 08.2013, JLF 09.2014 */

public abstract class A_ProtocolTransportation extends A_Protocol implements I_transportation_constants {
	//
	// FIELDS
	//
	public C_InspectorTransportation inspectorTransportation;// initialized in daughter protocols
	//
	// CONSTRUCTOR
	//
	public A_ProtocolTransportation(I_ground_manager gm, Context<Object> ctxt) {
		super(gm, ctxt);
		raster = (C_RasterGraph) gm;
		facilityMap = new C_Background(-.46, 44, 31);
		inspectorTransportation = new C_InspectorTransportation();
		C_CustomPanelSet.addTransportationInspector((C_InspectorTransportation) inspectorTransportation);
		inspectorList.add(inspectorTransportation);
	}
	//
	// METHODS
	//
	@Override
	public void readUserParameters() {
		super.readUserParameters();
		/** If true, display the affinity map, else display the value layer */
		C_Parameters.DISPLAY_MAP = ((Boolean) C_Parameters.parameters.getValue("DISPLAY_MAP")).booleanValue();
		/** If true cleanly end the simulation */
		C_Parameters.TERMINATE = ((Boolean) C_Parameters.parameters.getValue("TERMINATE")).booleanValue();
		// SUPER AGENTS
		C_Parameters.RODENT_SUPER_AGENT_SIZE = ((Integer) C_Parameters.parameters.getValue("RODENT_SUPER_AGENT_SIZE")).intValue();
		C_Parameters.HUMAN_SUPER_AGENT_SIZE = ((Integer) C_Parameters.parameters.getValue("HUMAN_SUPER_AGENT_SIZE")).intValue();
		// DEFAULT VALUES
		C_Parameters.VEHICLE_LOADING_PROBA = ((Integer) C_Parameters.parameters.getValue("VEHICLE_LOADING_PROBA")).intValue();
		// TIME CONDENSED STUFF //
		double activityRatio_Upercent = ((Integer) C_Parameters.parameters.getValue("HC_ACTIVITY_RATIO")).intValue();
		double activityRatio = activityRatio_Upercent / 100;// convert percent into rate 0 -> 1
		double totalTimeLength_Ucalendar = ((Integer) C_Parameters.parameters.getValue("HC_TOTAL_TIME_LENGTH_Ucalendar"))
				.intValue();
		String activityTimeUnit_Ucalendar = (String) C_Parameters.parameters.getValue("HC_ACTIVITY_TIME_UNIT_Ucalendar");
		if (0 < activityRatio && activityRatio < 1) {
			if (activityTimeUnit_Ucalendar.equalsIgnoreCase(TICK)) C_Parameters.HC_TOTAL_TIME_LENGTH_Utick = Math
					.round(totalTimeLength_Ucalendar);
			else C_Parameters.HC_TOTAL_TIME_LENGTH_Utick = Math.round(C_TimeAndSpaceConverter.convertTimeDurationToTick(
					totalTimeLength_Ucalendar, activityTimeUnit_Ucalendar));
			C_Parameters.HC_ACTIVITY_LENGTH_Utick = Math.round(activityRatio * C_Parameters.HC_TOTAL_TIME_LENGTH_Utick);
		}
		else System.err
				.println("A_ProtocolTransportation.readParametersFromGUI Error : HC_ACTIVITY_RATIO must be between 1 and 99 !");
	}
	@Override
	protected void initFixedParameters() {
		super.initFixedParameters();
		C_Parameters.AGENT_PERCEPTION_RADIUS_UmeterByDay = 1;// TODO JLF junk value
		C_Parameters.RODENT_SPEED_UmeterByTick = 60;
		C_Parameters.MAX_AGE_Uday = 10000;
		C_Parameters.REPRO_START_Umonth = 3;// TODO JLF junk value
		C_Parameters.REPRO_END_Umonth = 4;// TODO JLF junk value
		C_Parameters.MALE_SEXUAL_MATURITY_Uday = 75;// Rattus rattus 75 day (JMD)
		C_Parameters.FEMALE_SEXUAL_MATURITY_Uday = 75;// Rattus rattus 75 day (JMD)
	}
	@Override
	public void step_Utick() {
		if (C_Parameters.TERMINATE) haltSimulation();
		inspectorTransportation.checkLandPlotLists();
		// CARRIERS' STEP PROCEDURE
		ArrayList<C_HumanCarrier> mustDieHClist = new ArrayList<C_HumanCarrier>();
		for (C_HumanCarrier oneHC : inspectorTransportation.getCarrierList()) {
			oneHC.manageCondensedTime();
			if (oneHC.isMustDie()) mustDieHClist.add(oneHC);
		}
		removeDeadHumanCarriers(mustDieHClist);// clean the corps
		if (timeCondenser.isActive) inspectorTransportation.addOutputDataLine(RepastEssentials.GetTickCount() + "");
		inspectorTransportation.step_Utick();
		super.step_Utick(); // has to be after the other inspectors step since it records indicators in file
	}
	/** Updates landplots and graphs if necessary after reading new events
	 * @see A_Protocol#updateUniverseFromChrono()
	 * @see manageEvent */
	@Override
	protected void manageReadEventTypes(TreeSet<String> changedEventTypes) {
		// BELOW: Update landplots _and_ graphs when they have been modified.
		// Snippet placed here since many cells of a given ground type may have been updated at the same time
		// Various types of ground event (city, road, GNT...) are successively dealt with
		for (String eventType : changedEventTypes) {
			if (eventType.equals(TRACK)) eventType = ROAD;
			if (GROUND_TYPE_CODES.containsKey(eventType)) {// When ground has been modified
				// If area has been modified, reset all areas// TODO JLF 26.09.2014 patch for centenal GNT (eventTypes are added in
				// protocol), should be revised
				if (AREA_TYPES.contains(eventType)) {
					for (String areaType : AREA_TYPES) {
						// 1) sets the landPlot list from the rasterGraph 2) include the changes in the existing landplots
						TreeSet<C_LandPlot> landplotsOfAType = ((C_RasterGraph) raster).identifyTypeLandPlots(areaType);
						updateLandPlots(landplotsOfAType, areaType);
					}
				}
				// 1) sets the landPlot list from the rasterGraph 2) include the changes in the existing landplots
				// TODO JLF should be the raster not casted here, identifyTypeLandplots in raster(-manager)
				TreeSet<C_LandPlot> landplotsOfAType = ((C_RasterGraph) raster).identifyTypeLandPlots(eventType);
				updateLandPlots(landplotsOfAType, eventType);
				// Update cities for each landplot
				for (C_LandPlot landplot : inspectorTransportation.getLandPlotList()) {
					if (landplot instanceof C_Region) ((C_Region) landplot).setCityList();
				}
				inspectorTransportation.setCityList();// inspector renew its cityList
				if (GRAPH_TYPES.contains(eventType)) {// When event is also involved in graphs
					// Force all human carriers to reach destination (useful just before updating the ground) */
					for (C_HumanCarrier oneCarrier : inspectorTransportation.getCarrierList()) {
						if (eventType.equals(oneCarrier.getVehicle().getGraphType())) oneCarrier.pathWanderer.reachPathEndNow();
					}
					// Update graph of the type
					A_Protocol.event("A_ProtocolTransportation.manageReadEventTypes()" + landplotsOfAType, isNotError);
					((C_RasterGraph) raster).buildGraphsFromLandPlots(landplotsOfAType);
					A_Protocol.event(eventType + " graph build or updated: ",isNotError);
				}
				if (AREA_TYPES.contains(eventType)) {// When event is also involved in graphs
					// Force all human carriers to reach destination (useful just before updating the ground) */
					for (C_HumanCarrier oneCarrier : inspectorTransportation.getCarrierList()) {
						if (eventType.equals(oneCarrier.getVehicle().getGraphType())) oneCarrier.pathWanderer.reachPathEndNow();
					}
					// Update graph of the type
					((C_RasterGraph) raster).buildGraphsFromLandPlots(landplotsOfAType, ROAD);
					A_Protocol.event( eventType + " graph build or updated: ",isNotError);
				}
			}
		}
		reactivateHumanCarriers(); // activate carriers in case time condenser is on
	}
	/** Update the universe according to oneEventLine from Events <br />
	 * @param event from dataChrono */
	@Override
	protected void manageOneEvent(C_Event event) {
		super.manageOneEvent(event);
		switch (event.type) {
			case CITY :
			case TOWN :
				manageCityEvent(event);
				break;
			case RIVER :
			case ROAD :
			case RAIL :
			case GNT_WEAK :
			case GNT_MEDIUM :
			case GNT_HEAVY :
				manageGroundEvent(event);
				break;
			case TRUCK :
			case CAR :
			case TRAIN :
			case BOAT :
				manageVehicleEvent(event);
				break;
			case RAT :
				int nbRodents = Integer.parseInt(event.value1);
				if (nbRodents > C_Parameters.RODENT_SUPER_AGENT_SIZE) nbRodents = nbRodents / C_Parameters.RODENT_SUPER_AGENT_SIZE;
				addRodentsInSoilCell(nbRodents, event.whereX_Ucell, event.whereY_Ucell);
				break;
			case POPULATION :
				managePopulationEvent(event);
				break;
			case DEPRECATED :
				break;
			default :
				break;
		}
	}
	/** Perform the regular manageGroundEvent(event) can be overloaded by daughter protocols (e.g. ,decenal) */
	protected void manageCityEvent(C_Event event) {
		manageGroundEvent(event);
	}
	protected void managePopulationEvent(C_Event event) {
		C_City city = inspectorTransportation.getCityByName(event.value1);
		if (city == null) System.err.println("A_ProtocolTransportation.managePopulationEvent: city " + event.value1 + " not found");
		city.setHumanPopSize_Uindividual(Integer.parseInt(event.value2));
	}
	/** 1/add the ground type to the event soil cell, 2/sets the ground type value in valuelayer2 (the map of groundtypes)
	 * @see C_RasterGraph#valueLayer2 author PA Mboup 2014, rev. JLF 09.2014 */
	public void manageGroundEvent(C_Event event) {
		int x = event.whereX_Ucell, y = event.whereY_Ucell;
		String eventType = event.type;
		C_SoilCell eventSC = raster.getSoilCellsMatrix()[x][y];// SC for SoilCell

		// ADD GROUND TYPE to cell
		eventSC.getGroundTypes().add(eventType);// Assert ground type of the soilCell (one soilCell can have many groundType)
		// NAME THE CELL: event name or plot type followed with ground name separator followed with cell's unique ID.
		// if the cell is already a city do not change name.
		if (!eventSC.getGroundTypes().contains(CITY) || event.type.equals(CITY)) {
			if (event.value1.length() != 0) eventSC.setThisName(event.value1 + GROUND_NAMES_SEPARATOR + eventSC.getMyId());
			else eventSC.setThisName(event.type + GROUND_NAMES_SEPARATOR + eventSC.getMyId());
		}

		// SET VALUE LAYER 2 in position (x,y) according to the following priority (for display 2):
		// city > rail > river > road > track > (GNT) weak > (GNT) medium > (GNT) heavy > (border, ocean, foreign countries)
		int eventCode = GROUND_TYPE_CODES.get(eventType);
		// tracks are considered as road for graph computation, however, keep the track code for GUI colors display
		if ((event.type.equals(ROAD) && (eventSC.isGroundType(TRACK)))) eventCode = GROUND_TYPE_CODES.get(TRACK);
		if (eventCode < ((C_RasterGraph) raster).getValueLayer2().get(x, y)) ((C_RasterGraph) raster).setValueLayer2(eventCode, x,
				y);
	}
	/** Create or remove a population of human carriers with a given vehicle
	 * @param event The event in this case is of the form: type of vehicle/number of human carriers to add/option: cities, area of
	 *            activity / author PA Mboup 2014, rev. JLF 09.2014, 10.2014 */
	protected void manageVehicleEvent(C_Event event) {
		int x = event.whereX_Ucell, y = event.whereY_Ucell;
		C_SoilCellGraphed eventSC = (C_SoilCellGraphed) raster.getSoilCellsMatrix()[x][y];// SC for SoilCell
		int nCarriers = Integer.parseInt(event.value1);
		// do not reduce e.g., BOAT or TRAIN which are single units JLF 09.2014
		if (nCarriers > C_Parameters.HUMAN_SUPER_AGENT_SIZE) nCarriers = nCarriers / C_Parameters.HUMAN_SUPER_AGENT_SIZE;

		// CHECK compatibility between vehicle and C_SoilCell type
		String vehicleType = event.type;
		if ((vehicleType.equals(TRUCK) && !(eventSC.isGroundType(ROAD)))//
				|| (vehicleType.equals(TRAIN) && !eventSC.isGroundType(RAIL))//
				|| (vehicleType.equals(BOAT) && !eventSC.isGroundType(RIVER))) //
		// if (!eventSC.isGroundType(CITY) && !eventSC.isGroundType(TOWN)) // either city or town
		System.err.println("Protocol manageHCarrierEvent : " + eventSC + " is of type" + eventSC.getGroundTypes() + "no "
				+ vehicleType + " can be created there !");
		// CHECK End

		else if ((eventSC.getLandPlot(TOWN) != null) || (eventSC.getLandPlot(CITY) != null)) {// iff creation is within a city
			// PROCESS EVENT VALUE 2 - determine the cities to trade (when the event has a second value (cities, area))
			String graphType = VEHICLE_SPECS.get(vehicleType)[GRAPH_TYPE_COL];
			TreeSet<C_City> citiesToTrade = new TreeSet<C_City>();// the set of cities(/accointances) known by the carrier
			String areaTypeToTrade = null;// in case of e.g., "ground nut trade area"
			if (event.value2.length() != 0) {
				String tagOfValue2 = event.value2.split(CSV_FIELD_SEPARATOR)[0];// retrieve tag city or areaType
				// Case: list of cities
				if ((tagOfValue2.equals(CITY) || (tagOfValue2.equals(TOWN)))) {// Convert the string into a list of C_City
					String[] stringCities = event.value2.split(CSV_FIELD_SEPARATOR);
					for (int i = 1; i < stringCities.length; i++) {// do not count the first value ("city" tag)
						String cityString = stringCities[i];
						citiesToTrade.add(inspectorTransportation.getCityByName(cityString));
					}
				}
				// Case: a trade area ex GNT
				else if (AREA_TYPES.contains(tagOfValue2)) {
					if (eventSC.getLandPlot(tagOfValue2) == null) System.err
							.println("A_ProtocolTransportation.manageVehicleEvent; cannot create a : " + event.type + " in "
									+ eventSC + " which is not part of " + tagOfValue2 + " area.");
					else {
						areaTypeToTrade = event.value2.split(CSV_FIELD_SEPARATOR)[0];
						citiesToTrade = ((C_Region) eventSC.getLandPlot(areaTypeToTrade)).getCityList();
					}
				}
			}
			// Simplest case, e.g., event occurs on a road and retrieve all cities within this plot
			else citiesToTrade = ((C_Region) eventSC.getLandPlot(graphType)).getCityList();

			// PROCESS EVENT VALUE 1 - CARRIERS CREATION/REMOVAL
			// Add n carriers if n >= 0
			C_City targetCity = (C_City) eventSC.getLandPlot(CITY);
			C_SoilCell targetTown = eventSC;
			C_Graph graph = eventSC.getGraph(graphType);
			if (graph == null) System.err.println("A_ProtocolTransportation.manageVehicleEvent, no " + graphType
					+ " graph for this " + vehicleType + " event in " + eventSC);
			if (nCarriers > 0) { // eventType : road, rail or river ...
				// count the number of cells of this graphType in the target city
				TreeSet<C_SoilCellGraphed> graphCellsOfCity = targetCity.getGraphCells(graphType);
				int citySize_UcellGraphed = graphCellsOfCity.size();
				int nCarriersByCell = (nCarriers / citySize_UcellGraphed) + 1, restOfIntegerDivision = nCarriers
						% citySize_UcellGraphed;
				for (C_SoilCellGraphed cell : graphCellsOfCity) {
					if (restOfIntegerDivision == 0) nCarriersByCell--;
					restOfIntegerDivision--;
					for (int i = 1; i <= nCarriersByCell; i++) {
						createCarrier(cell, vehicleType, graph, citiesToTrade);
					}
				}
			}
			// Delete n carriers if n < 0
			else if (nCarriers < 0) removeCarrierPop(nCarriers, eventSC, vehicleType, citiesToTrade);
		}
		else System.err.println("A_ProtocolTransportation.manageVehicleEvent : no city at: " + eventSC + ", " + nCarriers
				+ " not created");
	}
	// // HUMAN_CARRIER AND RODENT POPULATION ////
	/** create one humanCarrier of a vehicle type and positions it in a city */
	protected void createCarrier(C_SoilCell cell, String vehicleType, C_Graph graph, TreeSet<C_City> citiesToTrade) {
		C_HumanCarrier one_carrier = new C_HumanCarrier(vehicleType);
		contextualizeNewAgentInCell(one_carrier, cell);// Declares a new object in the context and positions it within the raster
														// ground
		one_carrier.setTargetPoint_Umeter(one_carrier.getCoord_Umeters());
		one_carrier.pathWanderer.setTargetSoilCell((C_SoilCellGraphed) one_carrier.getCurrentSoilCell());
		one_carrier.pathWanderer.setGraph(graph);
		one_carrier.setCityList(citiesToTrade);
		inspectorTransportation.addCarrier(one_carrier);
	}
	protected void removeDeadHumanCarriers(ArrayList<C_HumanCarrier> mustDieHClist) {
		for (C_HumanCarrier oneHC : mustDieHClist) {
			if (C_Parameters.VERBOSE) System.out.print("|");
			// reach its destination to remove the rats that it contained (if loaded)
			if (!oneHC.getVehicle().getFullRodentList().isEmpty()) {
				oneHC.isArrived();
			}
			inspectorTransportation.carrierRemoved(oneHC); // From the inspector carriersList
			raster.wipeOffObject(oneHC);
		}
		mustDieHClist.clear(); // pas n�cessaire car var locale (mais je crois que c'est mieux de la vider aussi
	}
	/** Activation de tous les carriers (TIME CONDENSER) */
	protected void reactivateHumanCarriers() {
		for (C_HumanCarrier oneHC : inspectorTransportation.getCarrierList()) {
			if (oneHC.getTimeCondenser() != null && !oneHC.getTimeCondenser().isActive()) {
				oneHC.getTimeCondenser().manageLoadsHistory();
				oneHC.getTimeCondenser().setActive();
			}
		}
		timeCondenser.setActive();
	}
	/** Update the list of all landPlots in the groundType in parameter by updating each landPlot : <br />
	 * The code compares the old landplot list and the new computed landplot list. &nbsp;&nbsp;&nbsp; Can update, shorten or extend
	 * landPlot and group several landPlots in one single. <br />
	 * &nbsp;&nbsp;&nbsp; Can update a landPlot divided into two or several <br />
	 * &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp; (divide the road into several roads is to shorten it and add others). <br />
	 * &nbsp;&nbsp;&nbsp; But can not yet destroy a road that does not exist anymore. <br />
	 * This method should only be called after building or rebuilding a groundType landPlots with identifyTypeLandPlots() method. <br />
	 * With new landPlots from identifyTypeLandPlots(), this method update the old one and add news. <br />
	 * An old landPlot and a new are the same if 2 conditions :<br/>
	 * &nbsp;&nbsp;&nbsp; 1- they get a same groundType <br/>
	 * &nbsp;&nbsp;&nbsp; 2- they own a cell in common <br/>
	 * After this call this method we must call updateLandPlotCitiesList() to update for each updated LP the cities list associated
	 * @param newLandPlots
	 * @param groundTypes
	 * @see simmasto0.C_RasterGraph#identifyTypeLandPlots <br>
	 *      author P.A. Mboup, 2013, rev. JLF 09.2014 */
	protected void updateLandPlots(TreeSet<C_LandPlot> newLandPlots, String groundType) {// TODO JLF 09.2014 should be placed in
																							// A_Protocol ?
		// Recover all existing landPlots of this groundType
		TreeSet<C_LandPlot> currentLandPlotsOfAType = inspectorTransportation.getLandPlotList(groundType);
		// If this ground type has no recorded landplot, a type is created and filled with the new land plot list, nothing more.
		if (currentLandPlotsOfAType.size() == 0) //
		for (C_LandPlot aNewLandPlot : newLandPlots) {
			aNewLandPlot.setThisName("");
			contextualizeNewAgentInCell(aNewLandPlot, aNewLandPlot.getCell(0));// landplot situated at its first cell's coordinates
			inspectorTransportation.addLandPlot(aNewLandPlot);
		}
		// Else update the landplots for the given ground type
		else {
			ArrayList<C_SoilCell> newLandPlotCells;
			// Si le new lp correspond � un old ou si c'est le prolongement ou l'�courtement d'un old alors on met � jour le old �
			// partir du new
			// Pour chaque new landPlot
			for (C_LandPlot oneNewLandPlot : newLandPlots) {
				newLandPlotCells = oneNewLandPlot.getCells();
				C_LandPlot updatedLandPlot = null; //
				// On regarde les old landPlots � qui il correspond
				for (C_LandPlot oneOldLandPlot : currentLandPlotsOfAType) {
					for (C_SoilCell soilCell_1 : oneOldLandPlot.getCells()) {
						// S'il correspond � celui ci (m�me groundType et un SC en commun)
						if (oneNewLandPlot.getPlotType().equals(oneOldLandPlot.getPlotType())
								&& newLandPlotCells.contains(soilCell_1)) {
							// Si on n'a pas encore mis � jour un old LP avec ce new LP (updatedLandPlot == null) on ne supprime pas
							// l'ancien
							// landPlot, mais on le met � jour, donc les carriers qui s'y pointent s'y pointent toujours
							if (updatedLandPlot == null) {
								// ALORS PREMIER MIS � JOUR AVEC CE NEW LP :
								// Suppression du LP de ses SC
								for (C_SoilCell soilCell_2 : oneOldLandPlot.getCells()) {
									((C_SoilCellGraphed) soilCell_2).removeLandPlotByGroundType(groundType);
									((C_SoilCellGraphed) soilCell_2).removeGroundType(groundType);
								}
								// Suppression des SC du LP
								oneOldLandPlot.getCells().clear();
								// Reconstruction du old LP avec les SC de new LP (on garde l'ancienne r�f�rence que les agents
								// connaisse d�j�)
								for (C_SoilCell soilCell_3 : oneNewLandPlot.getCells()) {
									((C_SoilCellGraphed) soilCell_3).setLandPlotByGroundType(groundType, oneOldLandPlot);
									((C_SoilCellGraphed) soilCell_3).addGroundType(groundType);
								}
								updatedLandPlot = oneOldLandPlot;
							}
							// Sinon si on a d�j� mis � jour un ancien LP et on trouve un autre correspondant � ce new, alors c'est
							// le regroupement de 2 ou plusieurs old LP
							// Et donc c'est d�j� pris en compte dans l'autre et donc on doit supprimer celui ci
							else {
								for (C_SoilCell sc : oneOldLandPlot.getCells())
									if (((C_SoilCellGraphed) sc).getLandPlot(groundType) == oneOldLandPlot) {
										((C_SoilCellGraphed) sc).removeLandPlotByGroundType(groundType);
										((C_SoilCellGraphed) sc).removeGroundType(groundType);
									}
								oneOldLandPlot.getCells().clear();
							}
							break; // Un seul SC en commun suffit pour que les landPlot soit les m�mes
						}
					}
				}
				/*
				 * Et si le new lp ne correspond pas � un old lp alors c'est un tout new lp qu'on ajoute dans la liste et dans le
				 * context
				 */
				if (updatedLandPlot == null) {
					oneNewLandPlot.setThisName("");
					contextualizeNewAgentInCell(oneNewLandPlot, oneNewLandPlot.getCell(0));// landplot situated at its first cell's
																							// coordinates
					inspectorTransportation.addLandPlot(oneNewLandPlot);
				}
			}
		}
	}
	//
	// SETTERS & GETTERS
	//
	/** Mark carriers to destroy in carriers with a specify citiesList or in a landPlot M
	 * @param nCarriers
	 * @param VehicleType
	 * @param cityToTrade must be null if xy is given
	 * @return the number of carrier not marked mustDie */
	public int removeCarrierPop(int nCarriers, C_SoilCellGraphed eventCell, String VehicleType, TreeSet<C_City> citiesToTrade) {
		if (nCarriers < 0) nCarriers = -nCarriers;
		// Pour d�truire des carriers avec une liste de villes sp�cifi�es
		if (citiesToTrade != null) {
			int n = citiesToTrade.size();
			for (C_HumanCarrier oneCarrier : inspectorTransportation.getCarrierList()) {
				if (nCarriers == 0) return nCarriers; // ou break;
				if (!oneCarrier.isMustDie() // is not must die yet
						&& oneCarrier.getVehicle().getType().equals(VehicleType) // same vehicle type
						&& n == oneCarrier.getCityList().size() // same number of city
						&& oneCarrier.getCityList().containsAll(citiesToTrade)) { // same list of cities
					oneCarrier.setMustDie(true);
					nCarriers--;
				}
			}
		}
		// Pour d�truire des carriers sur un landPlot (de type route, rail,
		// river ...)
		else {// remove carriers on the same landplot
				// select the landplot corresponding to the vehicleType (which is unique)
			C_Region lp = (C_Region) eventCell.getLandPlot(VEHICLE_SPECS.get(VehicleType)[GRAPH_TYPE_COL]);
			TreeSet<C_HumanCarrier> carrierList = lp.getCarrierList();
			for (C_HumanCarrier oneCarrier : carrierList) {
				if (nCarriers == 0) return nCarriers; // ou break;
				if (!oneCarrier.isMustDie()) {
					oneCarrier.setMustDie(true);
					nCarriers--;
				}
			}
		}
		return nCarriers;
	}
	/** Create a set of rodents and place them in a soil cell
	 * @param x soilcell line
	 * @param y soilcell colomne
	 * @param nbRodents */
	protected void addRodentsInSoilCell(int nbRodents, int x, int y) {
		for (int i = 0; i < nbRodents; i++) {
			C_Rodent one_rodent = createRodent();
			contextualizeNewAgentInGrid(one_rodent, x, y);
		}
	}
	/** Create a set of rodents and place it in a city + distribute equally between city's soil cells
	 * @param nbRodents
	 * @param city */
	protected void addRodentsInCity(int nbRodents, C_City city) {
		// Dans une ville en distribuant le nombre de rats sur le nombre de SC
		ArrayList<C_SoilCell> cellList = city.getCells();
		int cityCellSize = cellList.size(), n = (nbRodents / cityCellSize) + 1, r = nbRodents % cityCellSize;
		for (int j = 0; j < cityCellSize; j++) {
			if (r == 0) n--; // done only once
			r--;
			C_SoilCell oneSC = cellList.get(j);
			for (int i = 1; i <= n; i++) {
				C_Rodent one_rodent = createRodent();
				contextualizeNewAgentInGrid(one_rodent, oneSC.getLineNo(), oneSC.getColNo());
			}
		}
	}

	/** Mark rodents to destroy in a soilcell or a city
	 * @param x soilcell line
	 * @param y soilcell colomne
	 * @param nbOfRodentsToDelete
	 * @param city optional
	 * @return the number of rodents not marked mustDie */
	// TODO PAM can or must be redefined ? if must, --> must be an abstract
	public int deleteRodents(int x, int y, int nbOfRodentsToDelete, C_City... city) {
		if (nbOfRodentsToDelete < 0) nbOfRodentsToDelete = -nbOfRodentsToDelete;
		// Pour d�truire des rodents dans une ville
		if (city.length != 0) {
			ArrayList<C_SoilCell> cellList = city[0].getCells();
			int cityCellSize = cellList.size(), i = 0, n, r;
			int j = 0, j0 = 0;
			while (nbOfRodentsToDelete > 0) { // tanqu'il y a des rats � suprimer
				n = (nbOfRodentsToDelete / cityCellSize) + 1; // division enti�re +1, n = nombre de rats � supp dans chaque cellule
																// de cette ville +/-
																// 1
				r = nbOfRodentsToDelete % cityCellSize; // r = reste de la division enti�re
				for (j = j0; j < cityCellSize; j++) { // Pour chaque cell
					j0++;
					if (r == 0) n = n - 1; // par ce qu'il avait + 1 Ex: n= 15/4 =3 r=3; r!=0 => n=4. Dans les 3 1eres cell je mets
											// 4, et quand r==0
											// (4i�me cell) je met 3 (n-1)
					r--;
					i = 0;
					TreeSet<C_Rodent> rodentList = ((C_SoilCellGraphed) cellList.get(j)).getFullRodentList();
					for (C_Rodent oneRodent : rodentList) {
						if (!oneRodent.isMustDie()) {
							oneRodent.setMustDie(true);
							nbOfRodentsToDelete--;
							i++;
						}
						if (i == n) break; // Si on atteint le nombre de rats �
											// d�truire(i==n), break pr cett cell
					}
					if (i < n) break; // Si on n'a pas d�truit n rats dans cett cell =>
										// refaire le calcul pr n et r.
										// j0 va nous permetre de sauter les cells d�j�
										// touch�es
				}
				if (nbOfRodentsToDelete == 0 || j0 == j) break; // si nbRats est �puis�e ou si la ville n'a plus de rats � d�truire
			}
		}
		// Pour d�truire des rodents dans une soilCell
		else {
			TreeSet<C_Rodent> rodentList = ((C_SoilCellGraphed) raster.getSoilCellsMatrix()[x][y]).getFullRodentList();
			// System.err.print("nbr init rats in cell : "+rodentList.size());
			if (rodentList != null) for (C_Rodent oneRodent : rodentList) {
				if (!oneRodent.isMustDie()) {
					oneRodent.setMustDie(true);
					nbOfRodentsToDelete--;
				}
				if (nbOfRodentsToDelete == 0) break;
			}
		}
		// Pour retourner le nombre de rats qui n'a pas pu etre d�truit
		// System.err.println(", rest rats non supp:	"+nbRats);
		return nbOfRodentsToDelete;
	}
	/** This method must be redefined in daughter protocols */
	protected Map<String, String[]> getVehicleSpecs() {
		return VEHICLE_SPECS;
	}
}