package thing;
import java.util.TreeMap;
import java.util.TreeSet;
import simmasto0.C_ContextCreator;
import simmasto0.C_RasterGraph;
import simmasto0.util.C_PathWanderer;
import simmasto0.util.C_TimeCondenser;
import thing.dna.C_GenomeAmniota;
import thing.dna.I_diploid_genome;
import thing.ground.C_City;
import thing.ground.C_SoilCell;
import thing.ground.C_SoilCellGraphed;
import thing.ground.C_Vehicle;
import data.I_string_constants;
import data.I_transportation_constants;

/** A human carrier owns a C_Vehicle and go from one city to the other.
 * @author Mboup & Le Fur 07-09.2012 */
public class C_HumanCarrier extends A_Mammal implements I_time_condensed, I_string_constants, I_transportation_constants {
	//
	// FIELDS
	//
	private C_Vehicle vehicle;
	/** inform rodents if this carrier's vehicle is parked or not, to get on it or do nothing if they are within <br />
	 * If the HC is sleeping, parked is false too */
	private boolean parked;
	public C_PathWanderer pathWanderer;
	// private C_LandPlot landPlot;
	private TreeSet<C_City> cityList;
	private boolean hasToChange;
	private C_TimeCondenser timeCondenser;
	//
	// CONSTRUCTORS
	//
	/** In the constructor, we define : the type of this carrier's vehicle, parked = true and instance path (to say that there are no
	 * node in path yet)
	 * @param vehicleType */
	public C_HumanCarrier(String vehicleType) {
		super(new C_GenomeAmniota());
		this.vehicle = new C_Vehicle(vehicleType);
		this.pathWanderer = new C_PathWanderer(this.currentSoilCell, this.vehicle.getSpeed_UmeterByTick());
		this.parked = true;
		this.name = this.vehicle.getType() + GROUND_NAMES_SEPARATOR + this.myId;
	}
	/** Build HC associated with time condenser
	 * @param vehicleType : type of the vehicle associated with this HC
	 * @param activityLength_Utick : the activity duration of this HC (int)
	 * @param totalTime_Utick : the total duration of this HC : activityLength + sleepingLength (int) */
	// TODO PAM de JLF 09.2014 je ne comprends pas ta remarque : "n'est pas un param�tre 06.2014 YEAR, MONTH(MON), DAY(DATE, D),
	// HOUR(H), MINUTE(MIN),
	// SECOND(S), MILLISECOND(MS),NANOSECOND(NS)" */
	public C_HumanCarrier(String vehicleType, long activityLength_Utick, long totalTime_Utick) {
		this(vehicleType); // Appel du constructeur en haut
		this.timeCondenser = new C_TimeCondenser(activityLength_Utick, totalTime_Utick);
	}
	/** used to allow the giveBirth procedure
	 * @see giveBirth */
	public C_HumanCarrier(I_diploid_genome genome) {
		super(genome);
	}
	//
	// METHODS
	//
	/** If this.isActive : do the step() else do not step(). <br />
	 * If managActAccordTimeU object is instantiated and it is time to manage activity then manage it. <br />
	 * If return is true so we want to manage this HC's loadsHistory.
	 * @return true or false (ie isActive). */
	public void manageCondensedTime() {
		if (this.timeCondenser == null) { // regular activity
			step_Utick();
		}
		else {// time condensed activity
			if (this.timeCondenser.isActive) step_Utick(); // performs normal step before
			// if either active or sleeping (and time to check)
			if (this.timeCondenser.isTimeToCheck()) {
				if (timeCondenser.isActive) {
					// Prepare to sleep
					this.isArrived(); //
					this.parked = false; // avoid rodent loadings
					this.getTimeCondenser().manageLoadsHistory();
				}
				this.timeCondenser.switchTimeCondensedStatus();
			}
		}
	}
	/** Activity within one time step : if a city is reached: select a new city, elaborates its path, unload rodents. If new city not
	 * reached : steps towards its current path. If vehicle speed is higher than cell size selectNextNode() is repeated several
	 * times / authors P.A.Mboup & J.Le Fur - sept.2012, rev. PAM 03.2014 */
	@Override
	public void step_Utick() {
		boolean enterInCurrentSC = false;
		this.pathWanderer.trackLengthCounter_Ucell = 0;
		while (this.pathWanderer.crossingIntermediateSCs()) {
			if (this.pathWanderer.hasToSetNextNode()) { // arrived in any path cell towards the // targetCell
				this.targetPoint_Umeter = this.pathWanderer.setNextNodeAndGetTargetPoint_Umeter();
			}
			else if (this.pathWanderer.pathEnd() && this.parked == false) { // When a carrier has reached a destination city (just
																			// before stoped)
				this.isArrived();
				break; // pour que parked reste plus de temps true (pendant un step)
			}
			else if (this.parked) { // just before leaving
				// DECISION PROCESS
				C_SoilCellGraphed targetSoilCellFinal = (C_SoilCellGraphed) selectDestination(deliberation(null));// null arg kept
																													// here only for
																													// compatibility
																													// with super
																													// method
				if (targetSoilCellFinal != null) // patch in cases (unexplained, #1/1000) where deliberation does not succeed, JLF
													// 09.2014
				this.targetPoint_Umeter = this.pathWanderer.setPathAndGetTargetPoint_Umeter(this.currentSoilCell,
						targetSoilCellFinal);
				if (!this.vehicle.getFullRodentList().isEmpty()) // le HC part du currentSoilCell avec n rats TIME SUSPENDED
				// on d�placera n rats de currentSoilCell vers targetSoilCell
				if (timeCondenser != null) timeCondenser.storeLoadsHistory(this.currentSoilCell, targetSoilCellFinal, this.vehicle
						.getFullRodentList().size());
				this.parked = false;
				this.hasToChange = true;
			}
			if (this.pathWanderer.isLastStep()) enterInCurrentSC = true;
			this.moveToDestination(enterInCurrentSC);// moves the /agent, carries rodents
		}
	}
	@Override
	public boolean isArrived() {
		this.pathWanderer.reachPathEndNow();
		C_ContextCreator.protocol.contextualizeOldAgentInCell(this, pathWanderer.targetSoilCell);
		this.parked = true; // to allow rodents to load within the vehicle
		if (!this.vehicle.getFullRodentList().isEmpty()) {
			unloadRodents();
			this.hasToChange = true;
		}
		return super.isArrived();
	}
	/** Select a destination city - build a map <city,cumulative weights> from its own cities, draw a random number.<br>
	 * The number has more chances to be in the interval of a big city, since it gets a great contribution to the total population
	 * @param candidateCells unused kept here only for compatibility with super method / author Mboup 07.2014, rev. JLF 09.2014 */
	@Override
	protected TreeSet<C_SoilCell> deliberation(TreeSet<I_situated_thing> candidateCells) {
		TreeSet<C_SoilCell> selectedCells = new TreeSet<C_SoilCell>();// result of deliberation (the cells of the chosen city)
		// Elaborate its known city list with cumulated population
		TreeMap<C_City, Integer> cityChoiceMap = new TreeMap<C_City, Integer>();
		int cumulatedPopulation_Uindividual = 0;
		for (C_City oneCity : this.cityList) {
			if (oneCity != ((C_SoilCellGraphed) this.currentSoilCell).getLandPlot(CITY)) {// Does not choose the city where it
																							// stands
				cumulatedPopulation_Uindividual += oneCity.getHumanPopSize_Uindividual();
				cityChoiceMap.put(oneCity, cumulatedPopulation_Uindividual);
			}
		}
		// Select a city
		int previousWeight = 0;
		int randomWeight = (int) (C_ContextCreator.randomGeneratorForDestination.nextDouble() * cumulatedPopulation_Uindividual);
		for (C_City oneCity : cityChoiceMap.keySet()) {
			if ((randomWeight <= cityChoiceMap.get(oneCity) && (randomWeight > previousWeight))) {
				for (C_SoilCell cell : oneCity.getCells())
					// Add the cell of the chosen city to selectedCells (those of the correct graphType)
					if (cell.isGroundType(this.vehicle.getGraphType())) selectedCells.add(cell);
				return selectedCells;
			}
			else previousWeight = cityChoiceMap.get(oneCity);
		}
		return selectedCells; // if destination city not found, return the empty treeSet
	}
	/*
	 * @Override protected void moveToDestination() { this.computeNextMove(vehicle.getSpeed_UmeterByTick()); this.moveMe(); if
	 * (!vehicle.getRodentList().isEmpty()) this.carryRodents(); }
	 */
	protected void moveToDestination(boolean enterInSC) {
		if ((this.vehicle.getType().equals(TRUCK)) && (this.currentSoilCell.isGroundType(TRACK))) this.computeNextMove(this.vehicle
				.getSpeed_UmeterByTick()
				/ TRACK_SLOW_FACTOR);
		else this.computeNextMove(this.vehicle.getSpeed_UmeterByTick());
		this.moveMe(enterInSC);
		if (enterInSC && !this.vehicle.getFullRodentList().isEmpty()) this.carryRodents();
	}
	private void carryRodents() {
		for (C_Rodent one_rodent : this.vehicle.getFullRodentList()) {
			C_ContextCreator.protocol.contextualizeOldAgentInCell(one_rodent, this.currentSoilCell);
		}
	}
	protected void moveMe(boolean enterInSC) {
		// if (trappedOnBoard) {} else // TODO PAM de JLF 09.2014 pourquoi est-ce comment� ?
		((C_RasterGraph) groundManager).moveObject(this, this.nextMove_Umeter, enterInSC);
	}

	public void unloadRodents() {
		for (C_Rodent one_rodent : vehicle.getFullRodentList()) {
			C_ContextCreator.protocol.contextualizeOldAgentInCell(one_rodent, this.currentSoilCell);
			one_rodent.trappedOnBoard = false;
			// one_rodent.getNewRandomDisplacement(); //TODO PAM � d�commenter ?
			// one_rodent.moveToDestination(); //TODO PAM � d�commenter ?
			// one_rodent.step();//TODO PAM � d�commenter ?
		}
		this.vehicle.getFullRodentList().clear();
	}
	@Override
	public boolean hasToChangeFace() {
		if (this.hasToChange) {
			this.hasToChange = false;
			return true;
		}
		return false;
	}
	/** Compatibility with the abstract class A_Animal only */
	@Override
	public void mate(I_reproducing_thing parent2) {}
	@Override
	/** Generating a new animal is compulsory for each A_Mammal daughter class */
	public A_Animal giveBirth(I_diploid_genome genome) {
		return new C_HumanCarrier(genome);
	}
	@Override
	/** Do nothing and overrides previous methods*/
	protected void interact(A_Animal animal) {}
	@Override
	public String toString() {
		return this.name;
	}
	//
	// SETTERS & GETTERS
	//
	public void setParked(boolean bool) {
		this.parked = bool;
	}
	public void setVehicle(C_Vehicle vehicle) {
		this.vehicle = vehicle;
	}
	public void setCityList(TreeSet<C_City> newCityList) {
		this.cityList = newCityList;
	}
	public boolean isParked() {
		return this.parked;
	}
	public int getRodentLoad() {
		return this.vehicle.getRodentLoad();
	}
	public C_Vehicle getVehicle() {
		return this.vehicle;
	}
	public TreeSet<C_City> getCityList() {
		return this.cityList;
	}
	public C_TimeCondenser getTimeCondenser() {
		return this.timeCondenser;
	}
	@Override
	public void getCalendarUnit() {
		// TODO Auto-generated method stub
	}
}
