package simmasto0.util;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;
import repast.simphony.essentials.RepastEssentials;
import simmasto0.C_ContextCreator;
import thing.C_Rodent;
import thing.ground.C_SoilCell;
import thing.ground.C_SoilCellGraphed;

/** @author P.A. Mboup, J. Le Fur 2013-12, rev. 04.2014 */
public class C_TimeCondenser {

	protected long activityLength_Utick;
	protected long totalTime_Utick;
	protected double nextCheck_Utick;
	public Boolean isActive;
	/** for each rodents carried stores origin-destination-nb rats */
	private Map<C_SoilCell, Map<C_SoilCell, Integer>> actionsPerformedHistory;

	// CONSTRUCTOR //

	/** To condense time. <br> */
	public C_TimeCondenser(long activityLength_Utick, long totalTime_Utick) {
		this.activityLength_Utick = activityLength_Utick;
		this.totalTime_Utick = totalTime_Utick;
		actionsPerformedHistory = new HashMap<C_SoilCell, Map<C_SoilCell, Integer>>();

		isActive = true; // active at initialization
		nextCheck_Utick = RepastEssentials.GetTickCount() + activityLength_Utick;
	}

	// METHODS //
	public boolean isTimeToCheck() {
		return nextCheck_Utick == RepastEssentials.GetTickCount();
	}
	/** switch activity (set active or inactive according to isActive) and set the next activity tick */
	public void switchTimeCondensedStatus() {
		if (isActive) this.setAsleep();
		else this.setActive();
	}

	// SETTERS & GETTERS //
	public void setActive() {
		nextCheck_Utick = RepastEssentials.GetTickCount() + activityLength_Utick;
		isActive = true;
	}
	public void setAsleep() {
		nextCheck_Utick = RepastEssentials.GetTickCount() + (totalTime_Utick - activityLength_Utick);
		isActive = false;
	}
	// public Map<C_SoilCell, Map<C_SoilCell, Integer>> getActionsPerformedHistory() {
	// return actionsPerformedHistory;
	// }
	public void storeLoadsHistory(C_SoilCell startSoilCell, C_SoilCell arrivedSoilCell, int rodentsNumber) {
		if (!actionsPerformedHistory.containsKey(startSoilCell)) actionsPerformedHistory.put(startSoilCell,
				new HashMap<C_SoilCell, Integer>());
		if (actionsPerformedHistory.get(startSoilCell).containsKey(arrivedSoilCell)) rodentsNumber += actionsPerformedHistory.get(
				startSoilCell).get(arrivedSoilCell);

		actionsPerformedHistory.get(startSoilCell).put(arrivedSoilCell, rodentsNumber);
	}
	/** This method manage the load history of a HC to put or delete a number of rodents in cells after extrapolate by the following
	 * calculation :<br>
	 * &nbsp;&nbsp;&nbsp; n : for each cell, n = the number of rat that was brought into (if n > 0) or taken from (if n < 0) the
	 * cell.<br>
	 * &nbsp;&nbsp;&nbsp; multiplicator = sleepLength / activityLength (ex: 11/1 : sleep 11 and active 1 month ).<br>
	 * &nbsp;&nbsp;&nbsp; Thus by extrapolation, the number of rats to delete or to put in the cell is : <br>
	 * &nbsp;&nbsp;&nbsp; n * multiplicator ex: <br>
	 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; if n = 1, 1*11/1 = 11 rats more. At total 12+1 rats in the yeat)<br>
	 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; if n = 2, 2*11/1 = 22 rats more. At total 22+2 rats in the yeat) */
	public void manageLoadsHistory() {// TODO PAM revoir le javadoc
		if (actionsPerformedHistory.size() != 0) {
			int nbRatsToManage;
			double sleepLength = (getSleepingLength_Utick() - (getNextCheck_UabsoluteTick() - activityLength_Utick - RepastEssentials
					.GetTickCount()));
			double multiplicator = sleepLength / (double) activityLength_Utick; // le nombre de rats � ajouter =
																				// n(sleepLen/actLen)
																				// System.err.println(sleepLength
																				// +" "+activityLength_Utick+" "+multiplicator);
			for (C_SoilCell oneStartSC : actionsPerformedHistory.keySet()) {
				for (C_SoilCell oneArrivedSC : actionsPerformedHistory.get(oneStartSC).keySet()) {
					nbRatsToManage = actionsPerformedHistory.get(oneStartSC).get(oneArrivedSC);
					System.err.print(oneStartSC+"->"+oneArrivedSC+", "+ nbRatsToManage+"->");
					nbRatsToManage = (int) Math.round(nbRatsToManage * multiplicator);
					System.err.println(+nbRatsToManage+ " � d�placer ->"+
					teleportA_NbrOfRodents(oneStartSC, oneArrivedSC, nbRatsToManage)
					 + " d�plac�s ("+	 actionsPerformedHistory.get(oneStartSC).get(oneArrivedSC)+" avant extrapolation)");
				}
			}
			actionsPerformedHistory.clear();
		}
	}
	private int teleportA_NbrOfRodents(C_SoilCell startSoilCell, C_SoilCell arrivedSoilCell, int nbrOfRodent) {
		TreeSet<C_Rodent> rodentList = ((C_SoilCellGraphed) startSoilCell).getFullRodentList();
		for (C_Rodent oneRodent : rodentList) {
			if (nbrOfRodent <= 0) break;
			C_ContextCreator.protocol.contextualizeOldAgentInCell(oneRodent, arrivedSoilCell);
			nbrOfRodent--;
		}
		return nbrOfRodent; // number of not teleported rodent
	}

	public double getActivityLength_Utick() {
		return activityLength_Utick;
	}
	public double getSleepingLength_Utick() {
		return totalTime_Utick - activityLength_Utick;
	}
	public double getNextCheck_UabsoluteTick() {
		return nextCheck_Utick;
	}
	public boolean isActive() {
		return isActive;
	}
}
