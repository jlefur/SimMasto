package thing;

public interface I_time_condensed {
	// C_TimeCondensed timeCondensed = new C_TimeCondensed(activityLength, totalTimeLength, calendarFieldUnit);
	public void manageCondensedTime();
	//public void prepareToSleep();
	public void getCalendarUnit();
}