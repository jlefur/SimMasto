package thing.dna.phenotyper;

import java.util.ArrayList;
import java.util.List;

import simmasto0.C_ContextCreator;
import thing.dna.C_ChromosomePair;
import thing.dna.C_GenePair;
import thing.dna.I_mapped_dna;


/**
 * Sex is also encoded using one gene pair .
 * 
 * @author kyle wagner, elyk@acm.org, adapted JLF 02.2011 was formerly PulseRateMapLocPhenotyper
 * @version 1.0, dec 7, 2001, 2.0, feb. 2011
 */

public class C_EucaryotePhenotyper extends C_MapLocPhenotyper {
	public static final boolean VERBOSE = false;

	/**
	 * Sex TraitExpressor - anonymous class
	 */
	private class C_TraitExpressorSex implements I_map_loc_trait_expressor {
		/**
		 * @return a String indicating sex ("female" or "male")
		 */
		public Object evalTrait(I_mapped_dna mappedDNA, ArrayList<Double> traitMapLocs) {
			if (mappedDNA instanceof C_ChromosomePair) {
				double sexMapLoc = ((Number) traitMapLocs.get(0)).doubleValue();
				C_GenePair genePair = (C_GenePair) mappedDNA.getLocusAllele(sexMapLoc);
				String leftAllele = (String) genePair.getGene(C_GenePair.LEFT).getAllele();
				String rightAllele = (String) genePair.getGene(C_GenePair.RIGHT).getAllele();
				if (leftAllele.equals(thing.dna.C_XsomePairSexual.SEX_GENE_X)
						&& rightAllele.equals(thing.dna.C_XsomePairSexual.SEX_GENE_X)) return "female";
				else return "male";
			}
			else return "genome is not a sexed genome";
		}
	}

	/**
	 * @param gonosomeMapLoc
	 *            an int indicating sex determination (1 locus)
	 */
	public C_EucaryotePhenotyper(Double gonosomeMapLoc) {

		// Add gonosomeMapLoc to a list since phenotyper expects a list of mapLocs
		ArrayList<Double> gonosomeMapLocs = new ArrayList<Double>();
		gonosomeMapLocs.add(new Double(gonosomeMapLoc));
		setTrait("sex", gonosomeMapLocs, new C_TraitExpressorSex());
		if (VERBOSE) System.out.println("- Cr�ation d'un EucaryotePhenotyper");
	}

	public C_EucaryotePhenotyper() {
		int numSexLoci = 1;// TODO number 1 in DNA source
		List<Double> sexLocs = new ArrayList<Double>();
		for (int i = 0; i < numSexLoci; i++)
			sexLocs.add(new Double(C_ContextCreator.randomGeneratorForDNA.nextDouble() * 100));
	}
	public boolean isMale(C_ChromosomePair genome) {
		String sex = (String) getTraitValue("sex", genome);
		return sex.equals("male");
	}

	public boolean isFemale(C_ChromosomePair genome) {
		String sex = (String) getTraitValue("sex", genome);
		return sex.equals("female");
	}
}
