package simmasto0;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.TreeSet;

import presentation.epiphyte.C_InspectorPopulation;
import repast.simphony.context.Context;
import repast.simphony.space.gis.Geography;
import repast.simphony.util.ContextUtils;
import repast.simphony.valueLayer.GridValueLayer;
import thing.A_Animal;
import thing.A_VisibleAgent;
import thing.C_Rodent;
import thing.I_situated_thing;
import thing.ground.C_BurrowSystem;
import thing.ground.C_LandPlot;
import thing.ground.C_SoilCell;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.Envelope;
import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LinearRing;
import com.vividsolutions.jts.geom.Polygon;

import data.I_numeric_constants;

/** this class allows to read shapefile which contains polygons in order to use them as support for the simulation
 * @author Quentin - april 2009
 * @author jlefur review - may 2009
 * @author J-E. Longueville */
public class C_GISManager implements I_ground_manager, I_sim_constants {
	// this attribute is used to give dimension to the table which
	private int hahtable_size = 50; // TODO number in source hahtable_size JLF 02.2014;
	// we create two hashtables, the first one will allow to associate one agent with the field on
	// which he stand
	private Hashtable<I_situated_thing, C_SoilCell> ht_agent_and_field;
	// the second will be used to get the neighbors of a given field agent.
	private Hashtable<C_SoilCell, Object> ht_field_neighbors;
	private String geography_name = "";
	// the envelope which will contains the features of the shp file
	private Envelope envelope = null;

	private ArrayList<C_BurrowSystem> burrowSystemInitList = new ArrayList<C_BurrowSystem>();
	private C_InspectorPopulation insp; // Pas encrore utilis�
	// METHOD
	/** This is the ground Manager GIS constructor
	 * @param context (I_situated_thing) the context in which we add the GIS
	 * @param geo_name the geography of the context which will contains the "Field_Agents"
	 * @param shapefile_url "an URL which locate the shapefile
	 * @return the context where the ground is created */
	public Context<Object> createGround(Context<Object> context, String geo_name,
			String shapefile_url) {return context;}
/*	public Context<Object> createGround(Context<Object> context, String geo_name,
			String shapefile_url) {
		// declaration of an agent type which will represent an area from the GIS
		geography_name = geo_name;
		// the field agent a will be used to build all elements in the shapefile
		C_SoilCell a;
		// we create instance of the hashtables
		ht_agent_and_field = new Hashtable<I_situated_thing, C_SoilCell>(hahtable_size);
		ht_field_neighbors = new Hashtable<C_SoilCell, Object>(hahtable_size);
		// creation of the geography projection
		GeographyParameters geoparam = new GeographyParameters<Object>();
		Geography<Object> geo = GeographyFactoryFinder.createGeographyFactory(null).createGeography(
				geography_name, context, geoparam);
		try { // we try to load the file from the specified url
			File file = new File(shapefile_url);
			if (file == null) {
				System.out.println(" error while loading the file");
			}
			// declaration of a "map" object,which is useful to register the parameters needed to
			// build the dataStore
			Map<String, Serializable> connectParameters = new HashMap<String, Serializable>();
			connectParameters.put("url", file.toURI().toURL());
			connectParameters.put("create spatial index", true);
			// Creation of the dataStore
			ShapefileDataStore dataStore = (ShapefileDataStore) DataStoreFinder
					.getDataStore(connectParameters);

			// we retrieve the different types contained in the datastore (there
			// should be only one)
			String[] typeNames = dataStore.getTypeNames();
			// we take the first
			String typeName = typeNames[0];
			System.out.print("Reading content " + typeName + " ...");
			// we get the source of features from the dataStore
			FeatureSource fs = dataStore.getFeatureSource(typeName);
			System.out.println("OK");
			// we create a featureCollection and an iterator to "read" each feature
			FeatureCollection collection;
			FeatureIterator iterator;

			collection = fs.getFeatures();
			System.out.print("Retrieving bounds and field agents neighbors ...");
			envelope = collection.getBounds();// we get the envelope which contains the GIS
			// we may send the boundaries of the SIg to the Agent class by a static way
			// it's convenient to place agent and keep them in the field of the GIS
			iterator = collection.features();
			double totalLength = 0.0;
			try {// we read all the content of the collection
				while (iterator.hasNext()) {// and we process each feature
					SimpleFeature feature = (SimpleFeature) iterator.next();
					Geometry geometry = (Geometry) feature.getDefaultGeometry();
					// we may get back each attribute which interest us and use them as
					// parameter for agent's building.
					double x = Double.parseDouble(feature.getAttribute(shp_field_attribute_name).toString());
					// we create an agent for each feature with the attribute we use for the
					// simulation
					a = new C_SoilCell((int) x);// when an agent is created,
					// we have to add it in the context
					context.add(a);
					// then, we may associate it with a geometry to give it a shape and coordinate
					// you cannot represent an agent without a geometry neither a geometry without
					// agent
					geo.move(a, geometry);
					totalLength += geometry.getLength();
				}
				
				 * we make an array in which we register for each Field agent the list of the neighbors Field the first
				 * field contains a reference over one field Agent the second field contains a list of Field_agent when
				 * the simulation area is build, we will associate each field agent with its neighbors
				 
				for (Object o : geo.getAllObjects()) {
					// if the current object is a field agent
					if (o instanceof C_SoilCell) {
						// we create a new list to store its neighbors
						ArrayList<C_SoilCell> neighbors_list = new ArrayList<C_SoilCell>();
						// to find its neighbors, we have to test all field
						// agent from the geography
						for (Object p : geo.getAllObjects()) {
							// if there is a distance of 10 or less between the
							// current field agent and the one we test, we
							// register it
							// in the list of neighbors
							if (p instanceof C_SoilCell
									&& geo.getGeometry(p).isWithinDistance((geo.getGeometry(o)), 10)) {
								neighbors_list.add((C_SoilCell) p);
							}
						}
						// then we create an array to store the object field
						// agent at the index 0 and
						// the list of his neighbors at the index 1
						ht_field_neighbors.put((C_SoilCell) o, neighbors_list);
					}
					else System.out.println("autre type d'objet: " + o);
				}
				System.out.println("OK");
			}
			finally {
				if (iterator != null) {
					// you must close the iterator
					iterator.close();
				}
			}
			System.out.println("Total Length " + totalLength);
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println(" error during geography building");
			System.exit(1);
		}
		return context;
	}*/
	/** The enveloppe is the it's the smallest "rectangle" which contains all geometry
	 * @return this method return the envelope of the gis, it's the smallest "rectangle" which contains all geometry (
	 *         ie the shapefile) */
	public Envelope getenvelope() {
		return envelope;
	}
	/** TODO [GIS] JAVADOC */
	@Override
	public Coordinate getObjectCoordinate_Ucs(Object o) {
		// is the tested object is an agent
		if (o instanceof I_situated_thing) {
			// we find his related context
			Context<I_situated_thing> context = ContextUtils.getContext(o);
			Geography projection = (Geography) context.getProjection(geography_name);
			// then we ask the geography to get the geometry of the agent
			Geometry geom = projection.getGeometry(o);
			// finaly, we return the coordinate of this geometry
			return geom.getCoordinate();
		}
		return null;
	}
	/** This function aims to permit the destroy of an agent TODO [GIS] Must be implemented for the GIS_Manager author:
	 * Jean-Emmanuel Longueville 2011-01
	 * @param agent => A_NDS Agent */
	public void destroy(I_situated_thing agent) {
		// TODO [GIS] ecrire cette m�thode
	}
	/** The method move object shouldn't be used to move field_agent,but it may works if you want to move some objects
	 * which are a part from the field */
	@Override
	public void moveObject(A_Animal agent, Coordinate dep) {
		// to move the agent, we start by get back his geometry
		Context<I_situated_thing> context = ContextUtils.getContext(agent);
		Geography projection = (Geography) context.getProjection(geography_name);
		Geometry geom = projection.getGeometry(agent);

		// then we get his coordinate
		Coordinate coord = geom.getCoordinate();
		C_SoilCell currentField_a = null;

		// we look for the agent in the hashtable and we get his related field
		// agent.
		currentField_a = ht_agent_and_field.get(agent);

		// we make test in order to prevent the agent to go out the simulation
		if ((coord.x < envelope.getMinX() && dep.x < 0) || (coord.x > envelope.getMaxX() && dep.x > 0)) {
			dep.x = -dep.x;
		}

		if ((coord.y < envelope.getMinY() && dep.y < 0) || (coord.y > envelope.getMaxY() && dep.y > 0)) {
			dep.y = -dep.y;
		}

		coord.x += dep.x;
		coord.y += dep.y;
		projection.move(agent, geom);

		// when we move an agent, we must change the reference of his related
		// Field agent if necessary,so we get all the neighbors
		// of the current field agent and we test if they are in intersection
		// with the agent's geometry

		// if the current field agent doesn't intersect the geometry agent, we
		// look for the neighbors
		if (!geom.intersects(projection.getGeometry(currentField_a))) {
			Object neighbors_list = ht_field_neighbors.get(currentField_a);

			// if we found the list of neighbors
			ArrayList list;
			if (neighbors_list instanceof ArrayList) // if the array contained a
			// list, we use it
			{
				list = (ArrayList) neighbors_list;
			}
			else // we must test the two case; if there is only one neighbor,
			// there is no list so we read only one element
			{
				list = new ArrayList();
				list.add((C_SoilCell) neighbors_list);
			}
			int z = 0;
			boolean moved = false;
			// we found the list , we have to test each elements to find the new
			// field agent related to the dynamic agent
			while (z < list.size() && !moved) {
				if (list.get(z) != currentField_a
						&& projection.getGeometry(agent).intersects(projection.getGeometry(list.get(z)))) {
					moved = true;
					// we change the reference of concerned field agents
					currentField_a.agentLeaving(agent);
					((C_SoilCell) list.get(z)).agentIncoming(agent);
					ht_agent_and_field.remove(agent);
					ht_agent_and_field.put(agent, (C_SoilCell) list.get(z));
				}
				z++;
			}
		}
	}
	/** TODO [GIS] ecrire la java doc */
	@Override
	public TreeSet<I_situated_thing> findObjectsOnContinuousSpace(I_situated_thing agent, double radius) {
		Context context = ContextUtils.getContext(agent);
		Geography projection = (Geography) context.getProjection(geography_name);

		// this list contains all object visible by the agent
		TreeSet<I_situated_thing> visibles_objects_list = new TreeSet<I_situated_thing>();

		C_SoilCell current_field_agent = null;
		ArrayList<C_SoilCell> neighbors_field_list = null;

		// we get back the field agent which contain our agent
		current_field_agent = ht_agent_and_field.get(agent);
		// the field agent is always visible by the agent ( he know on what he
		// stands)
		visibles_objects_list.add(current_field_agent);

		// for the following test, we will use the objects stored in the area
		// around the current agent field
		Object liste = ht_field_neighbors.get(current_field_agent);
		// it may be a list of field agent or only one element
		if (liste instanceof ArrayList) {
			neighbors_field_list = (ArrayList<C_SoilCell>) liste;
		}
		else {
			neighbors_field_list = new ArrayList<C_SoilCell>();
			neighbors_field_list.add((C_SoilCell) liste);
		}

		if (radius == 0.0) {
			Geometry agent_geom = projection.getGeometry(agent);
			TreeSet<I_situated_thing> dynamic_agent_list = current_field_agent.getAgentList();
			Iterator i = dynamic_agent_list.iterator(); // on cr�e un Iterator pour parcourir le
														// HashSet
			while (i.hasNext()) // tant qu'on a un suivant
			{
				Object o = i.next();
				if (o instanceof I_situated_thing && projection.getGeometry(o) != null
						&& projection.getGeometry(o).intersects(agent_geom)) {
					visibles_objects_list.add((I_situated_thing) o);
				}
			}
		}
		else {
			Coordinate agent_geom = agent.getCoord_Umeters();
			Geometry circle = createCircle(agent_geom.x, agent_geom.y, radius);
			// to get the visible objects, we test each field agent in the
			// neighborhood .
			for (int x = 0; x < neighbors_field_list.size(); x++) {
				C_SoilCell field_agent = neighbors_field_list.get(x);
				// if they are in intersection with the agent view
				if (projection.getGeometry(field_agent) != null
						&& projection.getGeometry(field_agent).intersects(circle)) {
					// we had the field agent in the list of the objects visible
					// by the agent

					visibles_objects_list.add(field_agent);
					TreeSet<I_situated_thing> list_contained_agent = field_agent.getAgentList();
					Iterator i = list_contained_agent.iterator(); // on cr�e un Iterator pour
																	// parcourir le HashSet
					while (i.hasNext()) // tant qu'on a un suivant
					{
						Object o = i.next();
						// and we test the elements that the field agent
						// contains
						if (o instanceof I_situated_thing && o != null && projection.getGeometry(o) != null
								&& projection.getGeometry(o).intersects(circle)) {
							visibles_objects_list.add((I_situated_thing) o);
						}
					}
				}
			}
		}
		return visibles_objects_list;
	}

	/** This method allow to generate a geometry with a circle shape the type returned is "multipolygon" which is accept
	 * by repast simphony( and not a simple polygon)
	 * @param x : x coordinate of the center of the circle
	 * @param y / y coordinate of the center of the circle
	 * @param RADIUS :
	 * @return a geometry which is a circle */
	public static Geometry createCircle(double x, double y, final double RADIUS) {

		final int SIDES = CIRCLE_ACCURACY_Upx;
		GeometryFactory factory = new GeometryFactory();

		// we create a points array
		Coordinate coords[] = new Coordinate[SIDES + 1];
		// for each point, we will create coordinate around the center given by
		// x and y
		// we create (side-1) points
		for (int i = 0; i < SIDES; i++) {
			double angle = ((double) i / (double) SIDES) * Math.PI * 2.0;
			double dx = Math.cos(angle) * RADIUS;// d�calage x par rapport au
			// centre
			double dy = Math.sin(angle) * RADIUS;// d�calage y par rapport au
			// centre
			coords[i] = new Coordinate((double) x + dx, (double) y + dy);
		}
		// the last pooint must be the same as the first in order to complete
		// the polygon
		coords[SIDES] = coords[0];
		// once the points are created, we have to link them to make a "ring"
		LinearRing ring = factory.createLinearRing(coords);
		// then we converse the rong as a polygon
		Polygon polygon = factory.createPolygon(ring, null);
		// because the geometry should be the same as all the shape, we have to
		// converse the polygon
		// to multipolygon
		Polygon[] tab_p = {polygon};
		Geometry mp = factory.createMultiPolygon(tab_p);
		// finaly we send back the circle geometry
		return mp;
	}
/*	*//** TODO [GIS] JAVADOC 
 * @author: Q.Baduel 2010 *//*
	public void randomlyAddRodents(Context<I_situated_thing> context, int nb_agent) {
		GeometryFactory gf = new GeometryFactory();
		Geography projection = (Geography) context.getProjection(geography_name);
		int x;
		int y;
		// we get the boundaries from the envelope
		int x_min = (int) envelope.getMinX();
		int y_min = (int) envelope.getMinY();
		int x_max = (int) envelope.getMaxX();
		int y_max = (int) envelope.getMaxY();

		// finally we add agents

		for (int i = 0; i < nb_agent; i++) {
			C_Rodent agent = new C_Rodent(new C_GenomeEucaryote());
			// C_StepEnvironment.popSize.increment();
			context.add(agent); // we add one agent in the context
			C_InspectorPopulation.addRodentToList(agent);
			// we take a couple of random coordinate inside the SIG
			x = (int) (C_ContextCreator.randomGeneratorForDNA.nextDouble() * ((x_max - x_min) + x_min));
			y = (int) (C_ContextCreator.randomGeneratorForDNA.nextDouble() * ((y_max - y_min) + y_min));
			Coordinate agent_coordinate = new Coordinate(x, y);
			// then we build a geometry where we can put the agent
			com.vividsolutions.jts.geom.Point agent_geometry = gf.createPoint(agent_coordinate);
			projection.move(agent, agent_geometry);

			for (Object o : projection.getAllObjects()) {
				if (o instanceof C_SoilCell && projection.getGeometry(o).intersects(agent_geometry)) {
					((C_SoilCell) o).agentIncoming(agent);
					ht_agent_and_field.put(agent, (C_SoilCell) o);
				}
			}
		}
	}*/
	/** TODO [GIS] JAVADOC */
	public void addChildAgent(A_Animal parent, A_Animal child) {
		// TODO [GIS]remettre les choses � leur place, init etc
		System.out.println("- Ajout par Raster_Manager d'un child ");
		Context<I_situated_thing> context = ContextUtils.getContext(parent);
		Geography projection = (Geography) context.getProjection(geography_name);
		Geometry geom = projection.getGeometry(parent);
		Coordinate coordParent_Ucs = getObjectCoordinate_Ucs(parent);
		double[] new_location = new double[2];
		new_location[0] = coordParent_Ucs.x;
		new_location[1] = coordParent_Ucs.y;
		child.init(this);
		parent.getCurrentSoilCell().agentIncoming(child);
		context.add(child);
		if (child instanceof C_Rodent) C_InspectorPopulation.addRodentToBirthList((C_Rodent) child);
		projection.move(child, geom);
	}
	/*
	@Override
	public Coordinate getInternalPoint_Ucs(C_SoilCell fa) { 
		Context context = ContextUtils.getContext(fa);
		// we get back the projection
		Geography projection = (Geography) context.getProjection(geography_name);
		// then we get back the geometry of the field agent
		Geometry geom = projection.getGeometry(fa);
		// and we take a point inside this geometry
		com.vividsolutions.jts.geom.Point p = geom.getCentroid().getInteriorPoint();
		Coordinate c = new Coordinate(p.getX(), p.getY());
		return c;
	}*/
	/** This function return the current coordinate of the agent in meter
	 * @param agent I_situated_thing
	 * @return coordinate of the agent in meter TODO [GIS] ADAPTED */
	public Coordinate getCoord_Umeter(I_situated_thing agent) {
		System.out.println("CETTE METHODE N'EST PAS IMPLEMENTEE!!!!!!!!!!!!!!");
		Coordinate a = new Coordinate(0, 0);
		return a;
	}
	@Override
	public void makeBurrowSystem(A_VisibleAgent ind) {
		// TODO [GIS] Auto-generated method stub

	}
	public void moveToLocation(I_situated_thing agent, Coordinate coordonee_Ucs) {
		System.out.println("MUST NOT BE IMPLEMENTED");
	};
	@Override
	public C_SoilCell[][] getSoilCellsMatrix() {
		// TODO [GIS] Auto-generated method stub
		return null;
	}
	public GridValueLayer getValueLayer() {
		// TODO [GIS] Auto-generated method stub
		return null;// TODO [GIS] used for RasterManager only : for changing cultures in fields
					// (C_StepVariousProcedure)
	}
	@Override
	public TreeSet<C_LandPlot> identifyAffinityLandPlots(Context<Object> context) {
		// TODO [GIS] Auto-generated method stub
		return null;
	}
	@Override
	public void resetCellsColor() {
		// TODO [GIS] Auto-generated method stub

	}
	@Override
	public TreeSet<C_LandPlot> getLandPlotsInitList() {
		// TODO [GIS] Auto-generated method stub
		return null;
	}
	@Override
	public void setLandPlotsInitList(TreeSet<C_LandPlot> identifyLandPlots) {
		// TODO [GIS] Auto-generated method stub
		
	}
}
