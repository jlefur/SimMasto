package thing.dna.phenotyper;

import java.util.ArrayList;
import java.util.List;

import thing.dna.C_ChromosomePair;

/**
 * Describes how a (mapped)DNA will be expressed as traits. Traits are:
 * traitxxx, traityyy, traitzzz
 * 
 * 
 * @author kyle wagner, elyk@acm.org, modified by J. Le Fur 02.2011
 * @version 1.0, dec 7, 2001
 */

public class C_MuroideaPhenotyper extends C_EucaryotePhenotyper {

	/**
	 * @param litterSizeMapLocs , traityyyMapLocs the map location of each trait on the DNA
	 */
	public C_MuroideaPhenotyper(ArrayList<Double> litterSizeMapLocs, ArrayList<Double> traityyyMapLocs,
			ArrayList<Double> traitxxxMapLocs, int numLocusPairsToCompare) {
		System.out.println("- Cr�ation d'un Muroidea phenotyper");
		setTrait("litterSize", litterSizeMapLocs, new C_TraitExpressorAvgMapLoc());
		setTrait("Trait yyy", traityyyMapLocs, new C_TraitExpressorSumMapLoc());
		setTrait("Trait xxx", traitxxxMapLocs, new C_TraitExpressorSumMapLoc());
	}

	/**
	 * @return the life-trait values
	 */
	public double getTraitZzz(C_ChromosomePair xsome) {
		return (Double) getTraitValue("Trait zzz", xsome);
	}

	public double getTraitYyy(C_ChromosomePair xsome) {
		Double traitYyy = (Double) getTraitValue("Trait yyy", xsome);
		return traitYyy.doubleValue();
	}

	public double getTraitXxx(C_ChromosomePair xsome) {
		Double traitXxx = (Double) getTraitValue("Trait xxx", xsome);
		return traitXxx.doubleValue();
	}

}
