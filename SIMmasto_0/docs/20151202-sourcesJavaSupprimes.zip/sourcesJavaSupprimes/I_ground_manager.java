package simmasto0;

import java.util.TreeSet;

import repast.simphony.context.Context;
import repast.simphony.valueLayer.GridValueLayer;
import thing.A_Animal;
import thing.A_VisibleAgent;
import thing.I_situated_thing;
import thing.ground.C_LandPlot;
import thing.ground.C_SoilCell;
import com.vividsolutions.jts.geom.Coordinate;

/** Establish the relationship between space and the rest of the world. The world communicate with space using I_ground_manager, it can thus function
 * either on SIG, raster, etc. (classes that implement the interface and specific types of projection).
 * @author Q. Baduel, 2008, rev. JLF 2012 */
public interface I_ground_manager {
	/** @param o an object contained in the projection
	 * @return the coordinate of the object in the projection */
	public Coordinate getObjectCoordinate_Ucs(Object o);
	/** Authors Jean-Emmanuel Longueville 2011-01 / Jean Le Fur
	 * @param agent : the object (A_VisibleAgent) to remove from the context */
	public void wipeOffObject(I_situated_thing agent);
	/** @param a : the object to move
	 * @param c : the destination coordinate */
	public void moveObject(A_Animal a, Coordinate c);
	/** @param a : the agent which is looking around him
	 * @param radius_Umeter the field of view
	 * @return an array list of the object which are in the field of view of the agent */
	public TreeSet<I_situated_thing> findObjectsOnContinuousSpace(I_situated_thing a, double radius_Umeter);
	public void digBurrowSystem(A_VisibleAgent ind);
	public void addChildAgent(A_Animal parent, A_Animal child);
	/** Move the desired object to a point. <br />
	 * CAUTION This method is a patch : using this procedure should be accompanied with the various list update necessary (see previous uses for help) */
	public void moveToLocation(I_situated_thing agent, Coordinate coordinate_Ucs);
	/** get the coordinate in agent unit.
	 * @param thing I_situated_thing */
	public Coordinate getCoord_Umeter(I_situated_thing thing);
	public C_SoilCell[][] getSoilCellsMatrix();
	public GridValueLayer getValueLayer();
	public TreeSet<C_LandPlot> identifyAffinityLandPlots(Context<Object> context);
	public void resetCellsColor();
	public TreeSet<C_LandPlot> getLandPlotsInitList();
}
