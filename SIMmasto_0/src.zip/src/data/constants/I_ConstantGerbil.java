package data.constants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/** Gathers all variables since software specifications requires no numbers in the java sources <br>
 * PE: Petite Emprise, ME, Moyenne Emprise, TPE: Tr�s Petite Emprise
 * @author Le Fur & Sall 09.2015 */
public interface I_ConstantGerbil extends I_ConstantString {

	// CHRONOGRAM FILE NAME
	// public static final String CHRONO_FILENAME = "20151029_GerbilEventsOfficiel.2a.jlf.csv";
//	 public static final String CHRONO_FILENAME = "20160719_GerbilEventsOfficiel.2b.jlf.csv";
	// public static String CHRONO_FILENAME = "20151029_GerbilEventsOfficielJunk.2a.jlf.csv";
	public static String CHRONO_FILENAME = "20160916_GerbilEventsJunk.1c.jlf.csv";

	public static int CELL_SIZE = 245; // DEFAULT : 15
	// INITIALYSE SIMULATION also modify Raster_File once parameters_scenario_GERBIL
	public static final ArrayList<Integer> width_heightRaster_Ukilometer = new ArrayList<Integer>() {
		{
			add(0);
			add(0);
		}
		private static final long serialVersionUID = 1L;
	};
	public static final ArrayList<Double> rasterLongitudeWest_LatitudeSouth_Udegree = new ArrayList<Double>() {
		{
			add(0.0);
			add(0.0);
		}
		private static final long serialVersionUID = 1L;
	};
	public static final ArrayList<String> rainUrl_suffixRainFile = new ArrayList<String>() {
		{
			add("");
			add("");
		}
		private static final long serialVersionUID = 1L;
	};
	public static int distancePELatitudeToOriginME_Ukilometer = 217;
	public static int distancePELongitudeToOriginME_Ukilometer = 247;
	public static final double rasterLatitudeNorth_Udegree = 16.75;
	public static final double rasterLongitudeEast_Udegree = -14.;
	// ME
	public static final int widthME_Ukilometer = 976;
	public static final int heightME_Ukilometer = 606;
	public static final double gerbilMELatitudeNorth_Udegree = 18.97833333;
	public static final double gerbilMELatitudeSouth_Udegree = 13.511944;
	public static final double gerbilMELongitudeWest_Udegree = -18.;
	public static final double gerbilMELongitudeEast_Udegree = -9.;
	/** Fixed Values of Gerbillus Nigeriae */
	// Vegetation names
	public static final String CROPS = "crops";
	public static final String GRASSES = "grasses";
	public static final String SHRUBS = "shrubs";
	public static final String WATER = "water";
	public static final String BARREN = "barren";
	public static final String TREES = "tree";
	/** Constant initial of vegetation */
	public static final Map<Integer, String[]> LANDCOVER_TO_VEGETATION = new HashMap<Integer, String[]>() {
		{
			put(18, new String[]{TREES, SHRUBS});
			put(36, new String[]{TREES, CROPS});
			put(37, new String[]{SHRUBS, SHRUBS});
			put(38, new String[]{GRASSES, SHRUBS});
			put(39, new String[]{CROPS, SHRUBS});
			put(40, new String[]{BARREN, SHRUBS});
			put(41, new String[]{GRASSES, GRASSES});
			put(42, new String[]{GRASSES, CROPS});
			put(43, new String[]{GRASSES, BARREN});
			put(44, new String[]{CROPS, CROPS});
			put(45, new String[]{BARREN, BARREN});
		}
		private static final long serialVersionUID = 1L;
	};
	/** Constant of distance between two vegetation */
	public static final double DISTANCE_THRESHOLD = 0.3; //Junk value
	public static final Map<String, Double> Per = new HashMap<String, Double>() {
		{
			put(SHRUBS , 0.1);
			put(TREES , 0.15);
			put(GRASSES , 0.15);
			put(CROPS , 0.05);
			put(BARREN , .0);
		}
		private static final long serialVersionUID = 1L;
	};
	// Vegetation values TODO MS 2016-01 junk values
	public static final double VegetationCarryingCapacity_Ugram = 1.E3;
	public static final double initialVegetationBiomass_Ugram = 1E4;

	// Gap between the raster of landcover and rain
	public static final int discardValueLandcoverRain_Ukilometer = 8;// TODO MS 2016-01 junk
	// Daily consumption of Gerbillus Nigeriae
	public static final double dailyConsumptionOfGerbil_Ugram = 1.0;// TODO MS 2016-01 junk
	public static final int averageDistanceHuntingOWL_Umeter = 2500;// Source : P.TABERLET, 1983
	double RAIN_VALUE_MULTIPLIER = 1.E8;// TODO 2016-01 number in source: Convert rain class value (1 to 8) to carrying capacity
	double SENSITIVITY = 5.;// TODO MS 2016-01 number in source sensitivity to rain
	public static final int UCS_WIDTH_Umeter = 1000;
	public static final Map<String, String[]> RASTER_PARAMETERS = new HashMap<String, String[]>() {
		{
			// Key Value: data_raster/name of raster, String list : landcover path, rain path, rain suffix, width raster, height raster, origin
			// longitude,origin latitude
			put(RASTER_PATH + "zoom1", new String[]{RASTER_PATH + "Zoom_001_12.2015/landcover.txt", "Zoom_001_12.2015/", "-Zoom-Rain.txt", "30", "30",
					"-16.", "16.2"});
			put(RASTER_PATH + "zoom2", new String[]{RASTER_PATH + "Zoom_002_12.2015/landcover.txt", "Zoom_002_12.2015/", "-Zoom-Rain.txt", "75", "45",
					"-15.45", "15.76"});
			put(RASTER_PATH + "zoom3", new String[]{RASTER_PATH + "Zoom_003_15_09.2016/landcover.txt", "Zoom_003_15_09.2016/", "-Zoom-Rain.txt", "3",
					"3", "-16.", "15.758572"});
			put(RASTER_PATH + "pe", new String[]{RASTER_PATH + "Zoom_PE_12.2015/landcover.txt", "Zoom_PE_12.2015/", "-Zoom-Rain.txt", "214", "110",
					"-16.", "15.758572"});
		}
		private static final long serialVersionUID = 1L;
	};
	public static final double vegetationCoverageRadius_Umeter = 250.; // TODO MS 2016.10 Junk value
	public static final double initialGerbilVitalEnergy_Ukcal = 38.3;// source : http://theses.vet-alfort.fr/telecharger.php?id=1335
	// source http://lvts.fr/download/other_universities/formation_exp%C3%A9rimentation_animale_lvl_1_paris_6_university/La%20physiologie%20digestive%20et%20l%E2%80%99alimentation%20des%20Rongeurs.pdf
	public static final double eatGainedEnergy_UKcal = 8.6;
	public static final double spawnConsumptionEnergy_Ukcal = 3.;// TODO MS 2016.10 Junk value
	public static final double fleeConsumptionEnergy_Ukcal = 2.;// TODO MS 2016.10 Junk value
	public static final double disperseConsumptionEnergy_Ukcal = 3.;// TODO MS 2016.10 Junk value
	public static final double mateConsumptionEnergy_Ukcal = 1.;// TODO MS 2016.10 Junk value
	public static final double eatConsumptionEnergy_Ukcal = .6;// TODO MS 2016.10 Junk value
	public static final double exitBurrowConsumptionEnergy_Ukcal = .1;// TODO MS 2016.10 Junk value
	public static final double sillGerbilVitaleEnergy_Ukcal = 18.;// TODO MS 2016.10 Junk value
	public static final double sillBarnOwlVitaleEnergy_Ukcal = 76.6;// TODO MS 2016.10 Junk value 
	public static final double initialBarnOwlVitalEnergy_Ukcal = 191.5;// TODO MS 2016.12 Junk value
	public static final double thermoregulationBarnOwl_UkcalPerHour = 3.125;// TODO MS 2016.12 Junk value
	public static final double huntRodentsConsumptionEnergy_Ukcal = 6.25;// TODO MS 2016.12 Junk value
	public static final double eatRodentGainedEnergy_UKcal = 37.5;// source : barn owl eats between 70 and 105 gram per day(MIKKOLA, H. (1983).- Owls of Europe. T
																  // et A.D. Poyrer, Calton. 397 p.), and
	  															  // gerbil weighs between 25 and 26 gram (Thomas and Hinton, 1920) on average 3.5
	public static final int hourRelease_Uhour = 19;
	public static final int bedTime_Uhour = 6;

			
}
