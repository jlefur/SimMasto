package data.constants;

import java.util.ArrayList;

/** Gathers all numbered variables since software specifications requires no numbers in the java sources
 * @author Le Fur 10.2014 */
public interface I_ConstantMusTransport extends I_ConstantTransportation {
	//
	// FILE NAMES //
	//
	// public static String CHRONO_FILENAME = "20170110-MusTransportEventsOfficiel.6c.jlf.csv";
	// public static String CHRONO_FILENAME ="20140723-SenegalMaille2km.2b.REFERENCE.jlf.csv";
//	public static String CHRONO_FILENAME = "20170116-MusTransportEventsOfficielEtDecenal.6e.jlf.csv";
//	public static String CHRONO_FILENAME = "20170117-MusTransportEventsOfficielEtDecenal.6g.jlf.csv";
//	public static String CHRONO_FILENAME = "20170213-MusTransportEventsOfficiel.8a.jlf.csv";
	public static String CHRONO_FILENAME = "20170414-MusTransportEventsOfficiel.9a_junk.jlf.csv";
	
	
	/** Population sizes of cities not specified in the chronogram */
	public static int DEFAULT_CITY_SIZE_Uindividual = 1950;
	public static int marketCrowdingFactor = 10;
	// Vieille version Nord
	// public static final ArrayList<Double> rasterLongitudeWest_LatitudeSouth_Udegree = new ArrayList<Double>(){
	// {add(-17.556-0.081271); add(14.279041-0.045529);} private static final long serialVersionUID = 1L;
	// {add(-17.530144); add(14.26490);} private static final long serialVersionUID = 1L;
	// };
	public static final ArrayList<Double> rasterLongitudeWest_LatitudeSouth_Udegree = new ArrayList<Double>() {
		// stands for 12�18'28.3"N 17�31'48.5"W
		{
			add(-17.530148);
			add(12.307859);
		}
		private static final long serialVersionUID = 1L;
	};
	// public static final double rasterLongitudeEast_Udegree = -12.076573;
	// public static final double rasterLatitudeNorth_Udegree = 16.73;
}
