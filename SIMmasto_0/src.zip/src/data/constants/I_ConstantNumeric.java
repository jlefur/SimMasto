/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt */
package data.constants;

import java.util.ArrayList;

/** Centralizes all shared numbered variables since software specifications requires no numbers in the java sources.<br>
 * protocols may overload it with their specific constants. Was formerly I_sim_constants
 * @author Q.Baduel, 2008, rev. Le Fur 07-09-11.2014, 10.2015
 * @see I_ConstantString */
public interface I_ConstantNumeric {

	// SIMULATION CONDITIONS //
	/** If pop size < threshold, FIS is not computed @see: C_InspectorGenetic#getFixationIndex */
	public final int FIS_COMPUTATION_THRESHOLD_Urodent = 30;// Below this population size, FIS is not computed (= 0.)

	// SPACE: GROUND AND PROJECTIONS //
	/** Size of one cell in the grid value layer (it must be checked that it is the same value that the scale given to the Continuous
	 * space within the definition of Raster display in the Repast Simphony GUI.. there is no known unit. */
	//TODO MS 09.2016 change variable of cell size, default value 15
	public static final ArrayList<Integer> cellSize = new ArrayList<Integer>(){
		{add(15);} private static final long serialVersionUID = 1L;
	};
	// RANDOM GENERATORS SEEDS //
	public static final int BOARDING_RANDOM_SEED = 1554563219; // 1554563209
	public static final int CULTURE_RANDOM_SEED = 254983425;
	public static final int DEATH_PROB_RANDOM_SEED = 1554563209;
	public static final int DESTINATION_RANDOM_SEED = 1122259370;// 1122259370
	public static final int DNA_RANDOM_SEED = 984863554;
	public static final int EPISTASIS_RANDOM_SEED = 654824589;
	public static final int GAMETE_RANDOM_SEED = 987654321;
	public static final int INITIALISATION_RANDOM_SEED = 1122259370;
	public static final int MOVEMENT_RANDOM_SEED = 564823654;
	public static final int OLFACTION_RECOGNITION_RANDOM_SEED = 564811123;
	public static final long GAUSSIAN_RANDOM_SEED = 321657567;

	// FILES & URLs //
	public static final int INTERVAL_ECRITURE_GENE_POP = 80;
	// csv file chronoEvents fields' order and values/ author pamboup
	public static final int DATE_COL = 0, X_COL = 1, Y_COL = 2, EVENT_COL = 3, VALUE1_COL = 4, VALUE2_COL = 5, CELL_ID_COL = 6,
			COMMENT_COL = 7;

	// DISPLAY & PRESENTATION
	public final int CIRCLE_ACCURACY_Upx = 32; // number of points used to draw the circle which
	public final int GUI_SPRITE_SIZE_Upx = 32;

	// GENETICS //
	// microsats //
	public final int NB_MICROSAT_GENES = 10;
	public double MEAN_GAUSS = 35;
	public double STD_GAUSS = 10;
	public double SPACE_BETWEEN_GENES = 4.3;
	// other genetics
	public static final double DEFAULT_MUT_RATE = 1E-9;// JLF; source talk Mathieu Gauthier, 04.11.2014
	public static final int SEX_GENE_Y = 0;
	public static final int SEX_GENE_X = 1;
	public static final int LOCUS_LETHAL_ALLELE = 0;
	public static final int STRAND_LETHAL_ALLELE = 0;

	// Living things (A_NDS) attributes
	public static final double DEFAULT_DEATH_PROBABILITY_UperDay = 1E-10;// quasi immortality: 1/(213 billion years)
	public static final int DEFAULT_AGE0_Utick = 0;
	// Animal attributes /
	public static final int BURROW_SYSTEM_AFFINITY = 10;
	public static final int NEST_AFFINITY = 11;
	public static int DANGEROUS_AREA_AFFINITY = 1	; // Value 2 For Chize (highway, houses, plugged fields)
	public static final double DANGEROUS_AREA_MORTALITY_RATE = .8;// induce a mortality when in dangerous area (=.8 for ploughing
																	// expertise from B.Gauffre, 01.2012)
}
