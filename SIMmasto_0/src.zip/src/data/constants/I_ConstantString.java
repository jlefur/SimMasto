/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt */
package data.constants;

import java.util.Set;
import java.util.TreeSet;

/** - Constant names concerning types names shared within all protocols<br>
 * - Strings as well as unnecessary numbers are meant to disappear from the source code (see also I_numeric_constants and other
 * data/I_???_constants.java) <br>
 * - The correspondence is centralized here for string parameters.<br>
 * - Almost all packages implement this interface.
 * @see I_ConstantNumeric
 * @author J.Le Fur 08.2014, rev. JLF 11.2014 */
public interface I_ConstantString {

	// SPATIAL PROJECTIONS NAMES
	// options: 1) ascii (provide a grid.csv), 2) any other string, image (/ provide e.g. one *.gif,.jpg,.bmp).
	public final String RASTER_MODE = "ascii";
	public final String GEOGRAPHY_NAME = "geography";// used in SIMmasto0.rs/context.xml
	public final String CONTINUOUS_SPACE_NAME = "space";// used in SIMmasto0.rs/context.xml
	public final String VALUE_LAYER_NAME = "valuegrid";// used in SIMmasto0.rs/context.xml
	public final String proj_gridvalue2 = "valuegrid2";// used in networked/graphed landscapes

	// CONSOLE OUTPUT
	public final boolean isError = true;
	public final boolean isNotError = false;
	// FILES & URLs //
	public final String CONSOLE_OUTPUT_FILE = "retour_console.txt";
	public final String CSV_PATH = "data_csv/";
	public final String RASTER_PATH = "data_raster/";
	public final String OUTPUT_PATH = "data_output/";
	public final String REPAST_PATH = "SIMmasto_0.rs/";
	public final String EVENT_VALUE2_FIELD_SEPARATOR = ":";// used when event value2 is a list
	public final String CSV_FIELD_SEPARATOR = ";";
	public final String NAMES_SEPARATOR = "_";// used when event value2 is a list

	// PROTOCOL NAMES - used in context creator
	public static final String BANDIA = "BANDIA";
	public static final String CAGES = "CAGES";
	public static final String CENTENAL = "CENTENAL";
	public static final String CENTENAL_OriginDestinationTransport = "CENTENAL_OriginDestinationTransport";
	public static final String DECENAL = "DECENAL";
	public static final String CHIZE = "CHIZE";
	public static final String ENCLOSURE = "ENCLOSURE";
	public static final String HYBRID_UNIFORM = "HYBRID_UNIFORM";
	public static final String MUS_TRANSPORT = "MUS_TRANSPORT";
	public static final String DODEL = "DODEL";
	public static final String VILLAGE = "VILLAGE";
	public static final String GERBIL_PROTOCOL = "GERBIL_PROTOCOL";

	// EVENT TYPES CONSTANTS - used in chrono events
	public static final String GERBIL_EVENT = "Gerbillus_nigeriae";
	public static final String OWL_EVENT = "owl";
	public static final String RAT = "Rattus rattus";
	public static final String MUS = "Mus musculus";
	public static final String DEPRECATED = "deprecated";
	public static final String CITY = "city";
	public static final String MARKET = "market";
	public static final String TOWN = "town";
	public static final String RAIL = "rail";
	public static final String RIVER = "river";
	public static final String ROAD = "road";
	public static final String GOOD_TRACK = "track2";
	public static final String TRACK = "track";
	public static final String GNT_WEAK = "GNT-WEAK";// GNT for GroundNut Trade
	public static final String GNT_MEDIUM = "GNT-MEDIUM";
	public static final String GNT_HEAVY = "GNT-HEAVY";
	public static final String BORDER = "border";
	public static final String SENEGAL = "Senegal";// ! not implemented JLF 09.2014
	public static final String POPULATION = "population";//
	public static final String TRUCK = "truck";// a truck event generates (a) human carrier(s) with truck
	public static final String TAXI = "taxi";// a taxi event generates (a) human carrier(s) with bush taxi
	public static final String TRAIN = "train";// a train event generates (a) human carrier(s) with train
	public static final String BOAT = "boat";// a boat event generates (a) human carrier(s) with boat
	//
	public static final String RAIN = "rain";// triggers a rain event

	// LIFE TRAITS CONSTANTS - used in genomes
	public static final String LITTER_SIZE = "litterSize";
	public static final String WEANING_AGE_Uday = "weaningAge_Uday";
	public static final String MATING_LATENCY_Uday = "matingLatency_Uday";
	public static final String GESTATION_LENGTH_Uday = "gestationLength_Uday";
	public static final String GROWTH_RATE_UgramPerDay = "growthRate_UgramPerDay";
	public static final String SEXUAL_MATURITY_Uday = "sexualMaturity_Uday";

	// TRAP CONSTANTS - used in CMR
	public static final String ADD_TRAP = "addTrap";
	public static final String CHECK_TRAP = "checkTrap";
	public static final String REMOVE_TRAP = "removeTrap";

	// GRAPH CONSTANTS
	public static final Set<String> GRAPH_TYPES = new TreeSet<String>() {
		{
			// add(xxx);
		}
		private static final long serialVersionUID = 1L;
	};
	/** @see #GROUND_TYPE_CODES */
	public static final Set<String> AREA_TYPES = new TreeSet<String>() {
		{
			// add(xxx);
		}
		private static final long serialVersionUID = 1L;
	};
}
