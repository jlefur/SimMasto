package presentation.display;

import thing.A_VisibleAgent;

/** Provides a display-able object (background facility map) to the GUI<br>
 * The bitmap is declared in presentation.display.C_Background.style_0.xml or equivalent
 * @author J.Le Fur, 08.2014 */
public class C_Background extends A_VisibleAgent {
	//
	// FIELDS
	//
	protected double scale;
	public int whereX, whereY;// TODO JLF 02.2016 should be doubLe (to enable a precise location).
	//
	// COSNTRUCTOR
	//
	public C_Background(double scale, int x_Ucell, int y_Ucell) {
		this.whereX = x_Ucell;
		this.whereY = y_Ucell;
		this.scale = scale;
		this.name = "background-" + this.myId;
	}
	//
	// METHOD
	//
	public double getScale() {// needed by GUI
		return scale;
	}
}
