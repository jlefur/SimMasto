package presentation.display;

import repast.simphony.render.RenderListener;
import repast.simphony.render.RendererListenerSupport;
import repast.simphony.visualization.*;

import javax.swing.*;

/** Un onglet ajout� � la simulation
 * @author A. Realini */
public class C_CustomPanelFactory implements IDisplay {

	/** Support du RendererListener qui rafraichit ce display */
	private RendererListenerSupport support;
	private C_Chart chart;

	/** Cr�e un nouveau display
	 * @param title : le titre du chart
	 * @param type : le type de chart (C_Chart.LINE/PIE3D/PIE2D/RING) */
	public C_CustomPanelFactory(String title, int type) {
		support = new RendererListenerSupport();
		chart = new C_Chart(title, type);
	}

	/** Cr�e un nouveau display en pr�cisant les noms des axes du graphique (pour les Line charts) */
	public C_CustomPanelFactory(String title, int type, String XLabel, String YLabel) {
		support = new RendererListenerSupport();
		chart = new C_Chart(title, type, XLabel, YLabel);
	}

	@Override
	// Appel�e juste apr�s le constructeur //
	public JPanel getPanel() {
		return chart.getChartPanel();
	}

	// @Override // A NE SURTOUT PAS SUPPRIMER //
	public void addRenderListener(RenderListener listener) {
		support.addListener(listener);
	}

	@Override
	// A NE SURTOUT PAS SUPPRIMER //
	public void render() {
		support.fireRenderFinished(this);
	}

	public C_Chart getChart() {
		return chart;
	}

	// OVERRIDE & UNUSED METHODS //

	public void init() {} // Called after getPanel()
	public void update() {}
	public void destroy() {}
	@Override
	public void setPause(boolean pause) {}
	public void resetHomeView() {}
	public void registerToolBar(JToolBar bar) {}
	public void addDisplayListener(DisplayListener listener) {}
	public void iconified() {}
	public void deIconified() {}
	public void closed() {}
	public void addProbeListener(ProbeListener listener) {}
	public void setLayout(Layout layout) {}
	public void setLayoutFrequency(LayoutFrequency frequency, int interval) {}
	public Layout getLayout() {
		return null;
	}
	public DisplayEditorLifecycle createEditor(JPanel panel) {
		return null;
	}
}
