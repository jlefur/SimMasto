package presentation.display;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import simmasto0.protocol.A_Protocol;
import thing.A_Animal;
import thing.A_Amniote;
import thing.A_NDS;
import thing.C_BarnOwl;
import thing.C_HumanCarrier;
import thing.C_Rodent;
import thing.C_RodentHouseMouse;
import thing.C_Vegetation;
import thing.I_SituatedThing;
import thing.dna.C_GenomeAcacia;
import thing.dna.C_GenomeBalanites;
import thing.dna.C_GenomeFabacea;
import thing.dna.C_GenomeMastoErythroleucus;
import thing.dna.C_GenomeMastoNatalensis;
import thing.dna.C_GenomeMastomys;
import thing.dna.C_GenomePoacea;
import thing.ground.C_BurrowSystem;
import thing.ground.C_Market;
import thing.ground.C_SoilCellSavanna;
import thing.ground.C_Trap;
import data.C_Parameters;

/** Gestionnaire d'images / Icons may be either gif image files or geonetric icons
 * @author A Realini, rev. JLF 10.2015 */
public class C_IconSelector implements data.constants.I_ConstantString {

	// Liste des noms d'images � utiliser dans la simulation Version DODEL//
	public static final String MOUSE_FEMALE_CHILD = "MouseYoungFemale";
	public static final String MOUSE_FEMALE_ADULT = "MouseAdultFemale";
	public static final String MOUSE_MALE_CHILD = "MouseYoungMale";
	public static final String MOUSE_MALE_ADULT = "MouseAdultMale";
	public static final String MOUSE_PREGNANT = "MousePregnant";
	public static final String DAY = "20170215-day";
	public static final String NIGHT = "20170215-night";
	public static final String DAWN = "20170215-dawn";
	public static final String TWILIGHT = "20170215-twilight";
	// Liste des noms d'images � utiliser dans la simulation Version CHIZE//
	public static final String VOLE_FEMALE_CHILD = "VoleYoungFemale";
	public static final String VOLE_FEMALE_ADULT = "VoleAdultFemale";
	public static final String VOLE_MALE_CHILD = "VoleYoungMale";
	public static final String VOLE_MALE_ADULT = "VoleAdultMale";
	public static final String VOLE_PREGNANT = "VolePregnant";
	// Liste des noms d'images � utiliser dans la simulation Version ENCLOS - CAGES//
	public static final String NATALENSIS = "natalensis";
	public static final String ERYTHROLEUCUS = "erythroleucus";
	public static final String HYBRID = "hybrid";
	public static final String LAZARUS = "lazarus";
	public static final String CAGE_PREGNANT = "cagePregnant";
	public static final String UNKNOWN = "unknown";
	// Liste des noms d'images � utiliser dans la simulation Version MUS_TRANSPORT//
	public static final String TAXI = "taxi";// taxi brousse or brush taxi
	// Liste des noms d'images � utiliser dans la simulation Version CENTENAL//
	public static final String BOAT = "boat";
	public static final String TRAIN = "train";
	public static final String TRUCK = "truck";
	public static final String CAR = "car";
	public static final String VEHICLE_LOADED = "loaded";
	public static final String VEHICLE_PARKED = "parked";
	public static final String RATTUS_MATURE = "rattusMature";
	public static final String RATTUS_PREGNANT = "rattusPregnant";
	public static final String MUS_PREGNANT = "musPregnant";
	public static final String MUS = "mus1";
	public static final String NEWBORN = "newBorn";
	public static final String MUSTDIE = "rattusMustDie";
	// Liste des noms d'images � utiliser dans la simulation Version BANDIA//
	public static final String LOADED_TRAP = "trapLoaded";
	public static final String EMPTY_TRAP = "trapEmpty";
	// Liste des noms d'images � utiliser dans la simulation Version GERBIL//
	public static final String GERBIL_ICON = "gnigeriae1";
	public static final String BARNOWLS_ICON = "20161020-barnOwls";

	// Vegatation icons
	public static final String SHRUBS_ICON = "20151112-shrub";
	public static final String CROPS_ICON = "20151112-crop";
	public static final String GRASSES_ICON = "20151112-grass";
	public static final String BARREN_ICON = "20151112-barren";
	public static final String TREES_ICON = "20151112-tree";
	// Liste des noms de v�g�tation du landcover Gerbille
	public static final String CROPS = "crops";
	public static final String GRASSES = "grasses";
	public static final String SHRUBS = "shrubs";
	public static final String BARREN = "barren";
	public static final String TREES = "tree";

	private static final String $PATH = "icons/"; // Chemin vers les images
	private static final String ext = ".gif"; // Extension des images

	/** Charge une image
	 * @param nomImage : le nom de l'image � charger */
	public BufferedImage loadImage(String nomImage) {
		BufferedImage img = null;
		try {
			img = ImageIO.read(new File($PATH + nomImage + ext));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return img;
	}
	/** Renvoie le nom de l'image � utiliser pour l'agent en param�tre */
	public String getNameOfImage(I_SituatedThing agent) {
		if (C_Parameters.PROTOCOL.equals("CHIZE")) return getNameOfImageChize(agent);
		else if (C_Parameters.PROTOCOL.equals("GERBIL_PROTOCOL")) return getNameOfImageGerbil(agent);
		else if (C_Parameters.PROTOCOL.equals("ENCLOSURE")) return getNameOfImageEnclosMbour(agent);
		else if (C_Parameters.PROTOCOL.equals("CAGES")) return getNameOfImageEnclosMbour(agent);
		else if (C_Parameters.PROTOCOL.equals("HYBRID_UNIFORM")) return getNameOfImageEnclosMbour(agent);
		else if (C_Parameters.PROTOCOL.contains("CENTENAL")) return getNameOfImageTransportRattus(agent);
		else if (C_Parameters.PROTOCOL.equals("DECENAL")) return getNameOfImageTransportRattus(agent);
		else if (C_Parameters.PROTOCOL.equals("MUS_TRANSPORT")) return getNameOfImageTransportMus(agent);
		else if (C_Parameters.PROTOCOL.equals("VILLAGE")) return getNameOfImageTransportRattus(agent);
		else if (C_Parameters.PROTOCOL.equals("DODEL")) return getNameOfImageDodel(agent);
		else if (C_Parameters.PROTOCOL.equals("BANDIA")) return getNameOfImageBandia(agent);
		else return getNameOfImageChize(agent);
	}

	public String getNameOfImageBandia(I_SituatedThing agent) {
		if (agent instanceof C_Trap) {
			if (((C_Trap) agent).getRodentList().size() > 0) return LOADED_TRAP;
			else return EMPTY_TRAP;
		}
		else if ((agent instanceof C_Rodent) && (((C_Rodent) agent).getGenome().getClass() == C_GenomeMastoErythroleucus.class)) return ERYTHROLEUCUS;
		else return UNKNOWN;
	}

	public String getNameOfImageTransportMus(I_SituatedThing agent) {
		if (agent instanceof C_RodentHouseMouse) {
			if (((C_RodentHouseMouse) agent).isPregnant()) return MUS_PREGNANT;
			else return MUS;
		}
		else return this.getNameOfImageTransportRattus(agent);
	}
	public String getNameOfImageTransportRattus(I_SituatedThing agent) {
		if (agent instanceof C_HumanCarrier) {
			String typeVehicle = ((C_HumanCarrier) agent).getVehicle().getType();
			if (((C_HumanCarrier) agent).isParked()) return VEHICLE_PARKED;
			else if (((C_HumanCarrier) agent).getVehicle().getLoad_Urodent() > 0) return VEHICLE_LOADED;
			else return typeVehicle;
		}
		else if (agent instanceof C_Rodent) {
			if (((C_Rodent) agent).isSexualMature()) {
				if (((C_Rodent) agent).isPregnant()) return RATTUS_PREGNANT;
				else return RATTUS_MATURE;
			}
			else return NEWBORN;
		}
		return UNKNOWN;
	}

	public String getNameOfImageChize(I_SituatedThing agent) {
		C_Rodent rodent = (C_Rodent) agent;
		if (!rodent.isSexualMature()) {
			if (rodent.isMale()) return VOLE_MALE_CHILD;
			else return VOLE_FEMALE_CHILD;
		}
		else if (rodent.isMale()) return VOLE_MALE_ADULT;
		else if (rodent.isPregnant()) return VOLE_PREGNANT;
		return VOLE_FEMALE_ADULT;
	}
	public String getNameOfImageDodel(I_SituatedThing agent) {

		if (agent instanceof C_IconNightDay) {
			if (A_Protocol.protocolCalendar.isDawn()) return DAWN;
			if (A_Protocol.protocolCalendar.isTwilight()) return TWILIGHT;
			else if (A_Protocol.protocolCalendar.isDayTime()) return DAY;
			else if (A_Protocol.protocolCalendar.isNightTime()) return NIGHT;
		}
		else if (agent instanceof C_Rodent) {
			C_Rodent rodent = (C_Rodent) agent;
			if (!rodent.isSexualMature()) {
				if (rodent.isMale()) return MOUSE_MALE_CHILD;
				else return MOUSE_FEMALE_CHILD;
			}
			else if (rodent.isMale()) return MOUSE_MALE_ADULT;
			else if (rodent.isPregnant()) return MOUSE_PREGNANT;
			return MOUSE_FEMALE_ADULT;
		}
		A_Protocol.event("C_IconSelector.getNameOfImageDodel()" + agent + " not displayable", isError);
		return null;
	}

	public String getNameOfImageGerbil(I_SituatedThing agent) {
		if (agent instanceof C_Vegetation) {
			if (((C_Vegetation) agent).getGenome() instanceof C_GenomeBalanites) return SHRUBS_ICON;
			if (((C_Vegetation) agent).getGenome() instanceof C_GenomePoacea) return GRASSES_ICON;
			if (((C_Vegetation) agent).getGenome() instanceof C_GenomeFabacea) return CROPS_ICON;
			if (((C_Vegetation) agent).getGenome() instanceof C_GenomeAcacia) return TREES_ICON;
		}
		if (agent instanceof C_BarnOwl) return BARNOWLS_ICON;
		return GERBIL_ICON;
	}

	/** Renvoie le nom de l'image � utiliser pour l'agent en param�tre */
	public String getNameOfImageEnclosMbour(I_SituatedThing agent) {
		C_Rodent rodent = (C_Rodent) agent;
		if (rodent.isPregnant()) return CAGE_PREGNANT;
		else if (rodent.getGenome().getClass() == C_GenomeMastoErythroleucus.class) return ERYTHROLEUCUS;
		else if (rodent.getGenome().getClass() == C_GenomeMastoNatalensis.class) return NATALENSIS;
		else if ((!rodent.getGenome().isHybrid()) && (rodent.getGenome().getClass() == C_GenomeMastomys.class)) return LAZARUS;
		else if (rodent.getGenome().isHybrid()) return HYBRID;
		else return UNKNOWN;
	}

	/** D�finit la couleur de l'agent en param�tre en fonction de son sexe, de son �ge, son �tat... (A utiliser avec l'affichage d'ellipses et non
	 * d'images)
	 * @return la nouvelle couleur de l'agent */
	public static Color getColor(I_SituatedThing agent) {
		if (C_Parameters.PROTOCOL.equals("CHIZE")) return getColorChize(agent);
		else if (C_Parameters.PROTOCOL.equals("GERBIL_PROTOCOL")) return getColorGerbil(agent);
		else if (C_Parameters.PROTOCOL.equals("ENCLOSURE")) return getColorMbour(agent);
		else if (C_Parameters.PROTOCOL.equals("CAGES")) return getColorMbour(agent);
		else if (C_Parameters.PROTOCOL.equals("HYBRID_UNIFORM")) return getColorMbour(agent);
		else if (C_Parameters.PROTOCOL.contains("CENTENAL")) return getColorTransportation(agent);
		else if (C_Parameters.PROTOCOL.equals("DECENAL")) return getColorTransportation(agent);
		else if (C_Parameters.PROTOCOL.equals("MUS_TRANSPORT")) return getColorTransportation(agent);
		else if (C_Parameters.PROTOCOL.equals("VILLAGE")) return getColorTransportation(agent);
		else if (C_Parameters.PROTOCOL.equals("BANDIA")) return getColorBandia(agent);
		else return getColorChize(agent);
	}

	public static Color getColorGerbil(I_SituatedThing agent) {
		Color rainColor = Color.black;
		if (agent instanceof C_SoilCellSavanna) {
			switch ((((C_SoilCellSavanna) agent)).getRainLevel()) {
				case 1 :
					rainColor = new Color(255, 255, 253);// >= 270 mm
					break;
				case 2 :
					rainColor = new Color(255, 255, 212);// 0 mm
					break;
				case 3 :
					rainColor = new Color(254, 254, 165);// 10 mm
					break;
				case 4 :
					rainColor = new Color(226, 254, 43);// 20-30 mm
					break;
				case 5 :
					rainColor = new Color(34, 254, 33);// 150-200
					break;
				case 6 :
					rainColor = new Color(2, 221, 221);// 210-260 mm
					break;
				case 7 :
					rainColor = new Color(35, 30, 252);// 40-80 mm
					break;
				case 8 :
					rainColor = new Color(190, 1, 254);// water or river
					break;
			}
		}
		/*
		 * if (agent instanceof C_SoilCellSavanna) { switch ((((C_SoilCellSavanna) agent)).getRain_Umm()) { case 0 : rainColor = new Color(0, 0, 0);//
		 * water or river break; case 1 : rainColor = new Color(34, 254, 33);// 90-140 mm break; case 2 : rainColor = new Color(226, 254, 43);// 40-80
		 * mm break; case 3 : rainColor = new Color(35, 30, 252);// 210-260 mm break; case 4 : rainColor = new Color(2, 221, 221);// 150-200 break;
		 * case 5 : rainColor = new Color(254, 254, 165);// 20-30 mm break; case 6 : rainColor = new Color(255, 255, 212);// 10 mm break; case 7 :
		 * rainColor = new Color(255, 255, 253);// 0 mm break; case 8: rainColor = new Color(190, 1, 254);// >= 270 mm break; default : rainColor =
		 * new Color(0, 0, 0); break; } }
		 */
		else if (agent instanceof C_Rodent) return getColorChize(agent);
		else if (agent instanceof C_BarnOwl) return new Color(0, 255, 0);
		else if (agent instanceof C_Vegetation) {
			if (((C_Vegetation) agent).getGenome() instanceof C_GenomeBalanites) return new Color(219, 149, 28);
			if (((C_Vegetation) agent).getGenome() instanceof C_GenomeFabacea) return new Color(40, 186, 70);
			if (((C_Vegetation) agent).getGenome() instanceof C_GenomePoacea) return new Color(140, 234, 159);
			if (((C_Vegetation) agent).getGenome() instanceof C_GenomeAcacia) return new Color(148, 178, 154);
		}
		return rainColor;
	}
	/** D�finit la couleur de l'agent en param�tre en fonction de son sexe et de son �ge (A utiliser avec l'affichage d'ellipses et non d'images)
	 * @return la nouvelle couleur de l'agent */
	public static Color getColorBandia(I_SituatedThing agent) {
		if (agent instanceof C_Trap) {
			if (((C_Trap) agent).getRodentList().size() > 0) return Color.black;
			else return Color.white;
		}
		else if (agent instanceof C_Rodent) return getColorChize(agent);
		else {
			System.err.println("C_SelecteurImage.getColorBandia() agent non reconnu: " + agent);
			return Color.green;
		}
	}

	public static Color getColorMbour(I_SituatedThing agent) {
		Color couleur = Color.white;
		if (((A_Animal) agent).getGenome() instanceof C_GenomeMastoNatalensis) {
			if (((C_Rodent) agent).isMale()) couleur = Color.cyan;
			else couleur = Color.pink;
		}
		else if (((A_Animal) agent).getGenome() instanceof C_GenomeMastoErythroleucus) {
			if (((C_Rodent) agent).isMale()) couleur = Color.blue;
			else couleur = Color.red;
		}
		else if (((A_Animal) agent).getGenome().isHybrid()) couleur = Color.yellow;
		else couleur = Color.white;
		if (((A_Amniote) agent).isPregnant()) couleur = Color.green;
		return couleur;
	}

	public static Color getColorTransportation(I_SituatedThing agent) {
		Color couleur = Color.white;
		if (agent instanceof C_HumanCarrier) {
			String typeVehicle = ((C_HumanCarrier) agent).getVehicle().getType();
			if (((C_HumanCarrier) agent).getVehicle().getLoad_Urodent() > 0) couleur = Color.red;
			else if (typeVehicle.equals(C_IconSelector.BOAT)) couleur = Color.yellow;
			else if (typeVehicle.equals(C_IconSelector.TRAIN)) couleur = Color.cyan;
			else if (typeVehicle.equals(C_IconSelector.TRUCK)) couleur = Color.blue;
			else if (typeVehicle.equals(C_IconSelector.TAXI)) couleur = Color.green;
		}
		else if (agent instanceof C_Rodent) {
			if (((C_Rodent) agent).isSexualMature()) couleur = Color.red;
			else couleur = Color.pink;
			if (((C_Rodent) agent).isPregnant()) couleur = Color.yellow;
		}
		else if (agent instanceof C_Market) {
			couleur = Color.pink;
		}
		if (agent instanceof A_NDS) if (((A_NDS) agent).isDead()) couleur = Color.black;
		return couleur;
	}
	/** D�finit la couleur de l'agent en param�tre en fonction de son sexe et de son �ge (A utiliser avec l'affichage d'ellipses et non d'images)
	 * @return la nouvelle couleur de l'agent */
	public static Color getColorChize(I_SituatedThing agent) {
		Color couleur = Color.gray;
		if (agent instanceof C_Rodent) {
			C_Rodent rodent = (C_Rodent) agent;
			if (rodent.isHasToDisperse()) return Color.white;
			if (!rodent.preMature && !rodent.isSexualMature()) return Color.gray;
			if (rodent.isPregnant()) return Color.yellow;
			if (rodent.isSexualMature()) if (rodent.isMale()) couleur = Color.blue;
			else couleur = Color.red;
			if (!rodent.isSexualMature()) if (rodent.isMale()) couleur = Color.cyan;
			else couleur = Color.pink;
		}
		else if (agent instanceof C_BurrowSystem) {
			if (((C_BurrowSystem) agent).getLoad_Urodent() > 4) couleur = Color.black;
			else couleur = Color.green;
		}
		return couleur;
	}
}