package presentation.display;

import java.awt.Dimension;
import java.awt.Font;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.dial.DialCap;
import org.jfree.chart.plot.dial.DialPlot;
import org.jfree.chart.plot.dial.DialPointer;
import org.jfree.chart.plot.dial.DialTextAnnotation;
import org.jfree.chart.plot.dial.StandardDialFrame;
import org.jfree.chart.plot.dial.StandardDialScale;
import org.jfree.data.general.DefaultValueDataset;

/** @author Audrey Realini 2011 */
public class C_Meter {
	private DefaultValueDataset data;
	private StandardDialScale scale;
	private ChartPanel pan;
	private int tailleInterval;
	private boolean multiplicateur;
	private DialTextAnnotation compteTours;
	public static final int DEFAULT_WIDTH = 20;

	/** Cr�e un meter
	 * @param title : Le nom du meter
	 * @param multiplicateur : Active ou non l'indice (le multiplicateur) au centre du meter
	 * @param interval : La valeur max du meter */
	public C_Meter(String title, boolean multiplicateur, int interval) {
		this.multiplicateur = multiplicateur;

		DialPlot plot = new DialPlot();
		data = new DefaultValueDataset(0); // Valeur de d�part //
		plot.setDataset(data);

		StandardDialFrame df = new StandardDialFrame(); // NE PAS OUBLIER ! //
		plot.setDialFrame(df);
		df.setVisible(true);

		// R�glages ticks et intervalles //
		scale = new StandardDialScale();
		scale.setLowerBound(0); // Valeur minimum //
		scale.setTickRadius(0.9); // Position des ticks par rapport au centre //
		scale.setTickLabelOffset(0.2); // Position des chiffres par rapport au centre (TENIR COMPTE
										// DU PARAM PREC) //
		scale.setMajorTickIncrement(interval / 10); // Interval entre 2 traits //

		if (multiplicateur) {
			scale.setUpperBound(interval - 0.01); // Valeur maximum // On enl�ve 0.01 pour ne pas
													// avoir le dernier chiffre affich�
			scale.setStartAngle(-90); // Position de la valeur minimum //
			scale.setExtent(-360); // Position de la valeur maximum //
			tailleInterval = ((Integer) interval).toString().length();
			compteTours = new DialTextAnnotation("0");
			compteTours.setFont(new Font("Arial", Font.BOLD, 30));
			plot.addLayer(compteTours);
		}
		else {
			scale.setUpperBound(interval); // Valeur maximum //
			scale.setStartAngle(-120); // Position de la valeur minimum //
			scale.setExtent(-300); // Position de la valeur maximum //
		}

		plot.addScale(0, scale); // scale est ajout� � l'index 0

		// R�glages aiguille //
		DialPointer pointer = new DialPointer.Pin();
		plot.addPointer(pointer);
		// Correspond au rond au centre du meteur (l� o� il y a l'aiguille) //
		DialCap cap = new DialCap();
		cap.setRadius(0.1);
		plot.setCap(cap);

		JFreeChart chart = new JFreeChart(plot);
		chart.setTitle(title);
		pan = new ChartPanel(chart);
		pan.setPreferredSize(new Dimension(100, 100));
		pan.setMaximumSize(pan.getPreferredSize());
	}

	public C_Meter(String title, boolean multiplicateur, int min, int max) {
		this(title, multiplicateur, max - min);
		scale.setLowerBound(min); // Valeur minimum //
		scale.setMajorTickIncrement((max - min) / 10); // Interval entre 2 traits //

		if (multiplicateur) scale.setUpperBound(max - 0.01);
		else scale.setUpperBound(max);
	}

	public void setData(int value) {
		data.setValue(value);
		if (multiplicateur) gestionMultiplicateur(value);
	}

	public void setData(double value) {
		data.setValue(value);
		if (multiplicateur) gestionMultiplicateur((int) value);
	}

	/** Met � jour le multiplicateur au centre du compteur
	 * @param value : la valeur enti�re de la donn�e mise � jour avec setData() */
	private void gestionMultiplicateur(Integer value) {
		if (value.toString().length() >= tailleInterval) compteTours
				.setLabel(value / (int) (Math.pow(10, tailleInterval - 1)) + ""); // supprime les
																					// n-1
																					// derniers
																					// chiffres
		else compteTours.setLabel("0");
	}

	public ChartPanel getPan() {
		return pan;
	}
}
