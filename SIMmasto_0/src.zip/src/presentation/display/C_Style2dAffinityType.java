package presentation.display;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

import repast.simphony.valueLayer.ValueLayer;
import repast.simphony.visualizationOGL2D.ValueLayerStyleOGL;
import simmasto0.C_Landscape;
import data.C_Parameters;
import data.constants.I_ConstantNumeric;

public class C_Style2dAffinityType implements ValueLayerStyleOGL, I_ConstantNumeric {
	protected ValueLayer layer;// the layer to represent

	Map<Integer, Color> colorMap;// the colormap is used to associate a color at each value of the layer
	public C_Style2dAffinityType() {
		// we try to get back the colormodel which should be read in the same time as the raster
		colorMap = new HashMap<Integer, Color>();
		colorMap = C_Landscape.getColormap();
		// if there is no colormap we create one
		if (colorMap == null) {
			System.out.print("C_Style2dAffinityType(): colormap not found; creating colormap");
			colorMap = new HashMap<Integer, Color>();
			if (C_Parameters.PROTOCOL.equals("CHIZE")) {
				colorMap = colorMapChizeGrid(colorMap);
				System.out.print(" Chize");
			}
			else if (C_Parameters.PROTOCOL.contains("CENTENAL")) {
				colorMap = colorMapCentenalGrid(colorMap);
				System.out.print(" Centenal");
			}
			else if (C_Parameters.PROTOCOL.equals("DECENAL")) {
				colorMap = colorMapDecenalGrid(colorMap);
				System.out.print(" Decenal");
			}
			else if (C_Parameters.PROTOCOL.equals("MUS_TRANSPORT")) {
				colorMap = colorMapDecenalGrid(colorMap);
				System.out.print(" Chize");
			}
			else if (C_Parameters.PROTOCOL.equals("DODEL")) {
				colorMap = colorMapAfricanVillage(colorMap);
				System.out.print(" African village");
			}
			else if (C_Parameters.PROTOCOL.equals("BANDIA")) {
				colorMap = colorMapBandia(colorMap);
				System.out.print(" Bandia");
			}
			else if (C_Parameters.PROTOCOL.equals("GERBIL_PROTOCOL")) {
				colorMap = colorMapGerbilLandcover(colorMap);
				System.out.print(" Gerbil landcover");
			}
			else {
				colorMap = colorMapChizeGrid(colorMap);
				System.out.print(" Chize");
			}
			System.out.println(": " + colorMap.size() + " colors identified");
			/** Elaborating a random colored map colorMap = colorMapPattern55(colorMap); // we associate at each index between 0 and 255 a random color
			 * // ( we can equally decide to build our own colormap with specific // value. for (int i = 0; i < 256; i++) { colorMap.put(i, new Color(
			 * (int) (C_ContextCreator.randomGeneratorForDisplay.nextDouble() * 255), (int) (C_ContextCreator.randomGeneratorForDisplay.nextDouble() *
			 * 255), (int) (C_ContextCreator.randomGeneratorForDisplay.nextDouble() * 255))); } */
		}
		else {
			// colorMap = colorMapChizeGrid(colorMap);
			// System.out.println(colorMap);
		}
	}
	@Override
	public float getCellSize() {
		// TODO MS 10.2016 change getting cell size
		return cellSize.get(0);
	}
	public Map<Integer, Color> colorMapCentenalGrid(Map<Integer, Color> colorMap) {
		colorMap = new HashMap<Integer, Color>();
		// R G B red green blue
		colorMap.put(-1, new Color(29, 29, 165)); // �Border, Ocean, and Abroad
		colorMap.put(0, new Color(29, 29, 165)); // �Border, Ocean, and Abroad
		colorMap.put(1, new Color(155, 155, 155)); // ROAD (black)
		colorMap.put(2, new Color(255, 204, 153)); // Ferlo
		colorMap.put(3, new Color(255, 255, 50)); // Grande c�te and delta
		colorMap.put(4, new Color(255, 245, 24)); // Soudanien
		colorMap.put(5, new Color(242, 226, 9)); // Sine
		colorMap.put(6, new Color(237, 180, 23)); // Terres neuves and zone cotonni�re
		colorMap.put(7, new Color(255, 0, 0)); // CITY (red)
		colorMap.put(9, new Color(197, 216, 21)); // Haute Casamance and S�n�gal Oriental
		colorMap.put(10, new Color(245, 245, 150)); // Niayes
		colorMap.put(11, new Color(242, 255, 99)); // Saloum
		colorMap.put(12, new Color(17, 178, 151)); // Basse-Casamance
		colorMap.put(13, new Color(103, 200, 255)); // RIVER
		return colorMap;
	}
	public Map<Integer, Color> colorMapChizeGrid(Map<Integer, Color> colorMap) {
		colorMap = new HashMap<Integer, Color>();
		colorMap.put(0, new Color(8, 99, 120));
		colorMap.put(1, new Color(204, 200, 206));
		colorMap.put(2, new Color(153, 102, 51));
		colorMap.put(3, new Color(173, 144, 96));
		colorMap.put(4, new Color(255, 255, 0));// formerly : 145, 145, 104
		colorMap.put(5, new Color(250, 197, 0));// formerly : 0, 102, 51;
		colorMap.put(6, new Color(211, 238, 207));
		colorMap.put(7, new Color(65, 138, 0));
		colorMap.put(8, new Color(51, 153, 153));
		colorMap.put(9, new Color(0, 199, 102));
		colorMap.put(10, new Color(0, 0, 0));
		return colorMap;
	}
	public Map<Integer, Color> colorMapGerbilLandcover(Map<Integer, Color> colorMap) {
		colorMap = new HashMap<Integer, Color>();
		colorMap.put(0, new Color(115, 178, 255));// water for rain
		colorMap.put(1, new Color(255, 255, 253));// / 0 mm
		colorMap.put(2, new Color(255, 255, 212));// 10 mm
		colorMap.put(3, new Color(254, 254, 165));// 20-30 mm
		colorMap.put(4, new Color(226, 254, 43));// 40-80 mm
		colorMap.put(5, new Color(34, 254, 33));// 90-140 mm
		colorMap.put(6, new Color(2, 221, 221));// 150-200 mm
		colorMap.put(7, new Color(35, 30, 252));// 210-260 mm
		colorMap.put(8, new Color(190, 1, 254));// >= 270 mm
		colorMap.put(17, new Color(115, 178, 255));// water for lancover
		colorMap.put(18, new Color(255, 130, 80));// Trees & Shrubs
		colorMap.put(36, new Color(160, 200, 160));// trees & Crops
		colorMap.put(37, new Color(160, 82, 45));// Shrubs
		colorMap.put(38, new Color(225, 200, 50));// Shrubs & Grasses
		colorMap.put(39, new Color(160, 200, 160));// Shrubs & Crops
		colorMap.put(40, new Color(230, 200, 140));// Shrubs & Barren
		colorMap.put(41, new Color(238, 238, 000));// Grasses
		colorMap.put(42, new Color(160, 200, 160));// Grasses & crops
		colorMap.put(43, new Color(238, 238, 000));// Grasses & Barren
		colorMap.put(44, new Color(200, 160, 160));// Crops
		colorMap.put(45, new Color(238, 236, 180));// Barren

		return colorMap;
	}
	public Map<Integer, Color> colorMapDecenalGrid(Map<Integer, Color> colorMap) {
		colorMap = new HashMap<Integer, Color>();
		colorMap.put(0, new Color(8, 99, 120));
		colorMap.put(1, new Color(204, 200, 206));
		colorMap.put(2, new Color(153, 102, 51));
		colorMap.put(3, new Color(173, 144, 96));
		colorMap.put(4, new Color(255, 255, 0));
		colorMap.put(5, new Color(250, 197, 0));
		colorMap.put(6, new Color(211, 238, 207));
		colorMap.put(7, new Color(65, 138, 0));
		colorMap.put(8, new Color(51, 153, 153));
		colorMap.put(9, new Color(0, 199, 102));
		colorMap.put(10, new Color(214, 163, 60));
		colorMap.put(13, new Color(0, 0, 0));
		return colorMap;
	}
	public Map<Integer, Color> colorMapAfricanVillage(Map<Integer, Color> colorMap) {
		colorMap = new HashMap<Integer, Color>();
		colorMap.put(0, new Color(94, 8, 7)); // road
		colorMap.put(1, new Color(162, 6, 4)); // road
		colorMap.put(2, new Color(234, 3, 1));// street
		colorMap.put(3, new Color(255, 71, 0));// brown
		colorMap.put(4, new Color(255, 131, 0)); // tree
		colorMap.put(5, new Color(255, 145, 0));
		colorMap.put(6, new Color(255, 174, 0));// concession
		colorMap.put(7, new Color(255, 200, 0));
		colorMap.put(8, new Color(255, 228, 0));// room brown:(153, 102, 51)
		colorMap.put(9, new Color(255, 241, 0));// market
		return colorMap;
	}
	public Map<Integer, Color> colorMapAfricanVillage0(Map<Integer, Color> colorMap) {
		colorMap = new HashMap<Integer, Color>();
		colorMap.put(0, new Color(0, 0, 0)); // road
		colorMap.put(1, new Color(102, 102, 102)); // road
		colorMap.put(2, new Color(204, 153, 51));// street
		colorMap.put(3, new Color(153, 102, 51));// brown
		colorMap.put(4, new Color(0, 153, 51)); // tree
		colorMap.put(5, new Color(104, 102, 51));
		colorMap.put(6, new Color(204, 102, 51));// concession
		colorMap.put(7, new Color(200, 200, 200));
		colorMap.put(8, new Color(255, 255, 255));// room brown:(153, 102, 51)
		colorMap.put(9, new Color(102, 51, 51));// market
		return colorMap;
	}
	public Map<Integer, Color> colorMapBandia(Map<Integer, Color> colorMap) {
		colorMap = new HashMap<Integer, Color>();
		colorMap.put(0, new Color(90, 97, 117));
		colorMap.put(1, new Color(232, 249, 250));
		colorMap.put(4, new Color(177, 162, 164));
		colorMap.put(5, new Color(101, 89, 89));
		colorMap.put(6, new Color(51, 153, 102)); // homogeneous field
		return colorMap;
	}
	@Override
	public Color getColor(double... coordinates) {
		return colorMap.get((int) layer.get(coordinates));
	}
	@Override
	public void init(ValueLayer layer) {
		this.layer = layer;
	}
}
