package presentation.display;

import java.awt.Color;
import java.awt.Font;

import repast.simphony.visualizationOGL2D.StyleOGL2D;
import saf.v3d.ShapeFactory2D;
import saf.v3d.scene.Position;
import saf.v3d.scene.VSpatial;
import thing.A_Amniote;
import thing.A_VisibleAgent;
import thing.C_RodentGerbil;
import thing.C_Vegetation;
import thing.I_SituatedThing;
import thing.ground.C_BurrowSystem;
import data.C_Parameters;
import data.constants.I_ConstantString;

/** Style des agents "animaux". D�finit une ic�ne ou une ellipse pour chaque agent au lancement de la simulation en fonction de son sexe et la fait
 * varier suivant son �ge.
 * @author A Realini 2011 */
public class C_StyleAgent implements StyleOGL2D<I_SituatedThing>, I_ConstantString {
	private float IMAGE_SCALE = 0.20f; // Taille d'une image initiale .15
	// Ellipse scales (nb: 50x50-> .3)
	private float ELLIPSE_SCALE = 1.5f;
	private final float CIRCLE_RADIUS = 5; // Rayon de l'ellipse
	private final int CIRCLE_SLICES = 10; // Nombres d�ar�tes de l�ellipse (joue sur le rendu : sera plus ou moins rond)
	private C_IconSelector selectImg;
	private ShapeFactory2D factory;
	private boolean IMAGE = false;

	/** Initialise un gestionnaire d'images et enregistre les images qui seront utilis�es au cours de la simulation dans le factory */
	public void init(ShapeFactory2D factory) {
		if (C_Parameters.PROTOCOL.equals(CHIZE)) initChize(factory);
		else if (C_Parameters.PROTOCOL.equals(ENCLOSURE)) initEnclosMbour(factory);
		else if (C_Parameters.PROTOCOL.equals(DODEL)) initDodel(factory);
		else if (C_Parameters.PROTOCOL.equals(CAGES)) initEnclosMbour(factory);
		else if (C_Parameters.PROTOCOL.equals(HYBRID_UNIFORM)) initEnclosMbour(factory);
		else if (C_Parameters.PROTOCOL.contains(CENTENAL)) initCentenal(factory);
		else if (C_Parameters.PROTOCOL.equals(DECENAL)) initDecenal(factory);
		else if (C_Parameters.PROTOCOL.equals(MUS_TRANSPORT)) initMusTransport(factory);
		else if (C_Parameters.PROTOCOL.equals(GERBIL_PROTOCOL)) initGerbil(factory);
		else if (C_Parameters.PROTOCOL.equals(BANDIA)) initBandia(factory);
	}

	public void initChize(ShapeFactory2D factory) {
		this.ELLIPSE_SCALE = .4f;
		this.IMAGE = false;
		this.factory = factory;
		selectImg = new C_IconSelector();
		if (IMAGE) {
			factory.registerImage(C_IconSelector.VOLE_FEMALE_CHILD, selectImg.loadImage(C_IconSelector.VOLE_FEMALE_CHILD));
			factory.registerImage(C_IconSelector.VOLE_FEMALE_ADULT, selectImg.loadImage(C_IconSelector.VOLE_FEMALE_ADULT));
			factory.registerImage(C_IconSelector.VOLE_MALE_CHILD, selectImg.loadImage(C_IconSelector.VOLE_MALE_CHILD));
			factory.registerImage(C_IconSelector.VOLE_PREGNANT, selectImg.loadImage(C_IconSelector.VOLE_PREGNANT));
			factory.registerImage(C_IconSelector.VOLE_MALE_ADULT, selectImg.loadImage(C_IconSelector.VOLE_MALE_ADULT));
		}
	}
	public void initDodel(ShapeFactory2D factory) {
		this.ELLIPSE_SCALE = .4f;
		this.IMAGE = true;
		this.IMAGE_SCALE = .2f;
		this.factory = factory;
		selectImg = new C_IconSelector();
		if (IMAGE) {
			factory.registerImage(C_IconSelector.MOUSE_FEMALE_CHILD, selectImg.loadImage(C_IconSelector.MOUSE_FEMALE_CHILD));
			factory.registerImage(C_IconSelector.MOUSE_FEMALE_ADULT, selectImg.loadImage(C_IconSelector.MOUSE_FEMALE_ADULT));
			factory.registerImage(C_IconSelector.MOUSE_MALE_CHILD, selectImg.loadImage(C_IconSelector.MOUSE_MALE_CHILD));
			factory.registerImage(C_IconSelector.MOUSE_PREGNANT, selectImg.loadImage(C_IconSelector.MOUSE_PREGNANT));
			factory.registerImage(C_IconSelector.MOUSE_MALE_ADULT, selectImg.loadImage(C_IconSelector.MOUSE_MALE_ADULT));
		}
		factory.registerImage(C_IconSelector.DAY, selectImg.loadImage(C_IconSelector.DAY));
		factory.registerImage(C_IconSelector.NIGHT, selectImg.loadImage(C_IconSelector.NIGHT));
		factory.registerImage(C_IconSelector.DAWN, selectImg.loadImage(C_IconSelector.DAWN));
		factory.registerImage(C_IconSelector.TWILIGHT, selectImg.loadImage(C_IconSelector.TWILIGHT));
	}
	public void initGerbil(ShapeFactory2D factory) {
		this.ELLIPSE_SCALE = 1.f;
		IMAGE_SCALE = .2f;
		this.IMAGE = true;
		this.factory = factory;
		selectImg = new C_IconSelector();
		if (IMAGE) {
			factory.registerImage(C_IconSelector.GERBIL_ICON, selectImg.loadImage(C_IconSelector.GERBIL_ICON));
			factory.registerImage(C_IconSelector.BARNOWLS_ICON, selectImg.loadImage(C_IconSelector.BARNOWLS_ICON));
			factory.registerImage(C_IconSelector.SHRUBS_ICON, selectImg.loadImage(C_IconSelector.SHRUBS_ICON));
			factory.registerImage(C_IconSelector.TREES_ICON, selectImg.loadImage(C_IconSelector.TREES_ICON));
			factory.registerImage(C_IconSelector.GRASSES_ICON, selectImg.loadImage(C_IconSelector.GRASSES_ICON));
			factory.registerImage(C_IconSelector.BARREN_ICON, selectImg.loadImage(C_IconSelector.BARREN_ICON));
			factory.registerImage(C_IconSelector.CROPS_ICON, selectImg.loadImage(C_IconSelector.CROPS_ICON));
		}
	}
	public void initCentenal(ShapeFactory2D factory) {
		this.ELLIPSE_SCALE = .8f;
		IMAGE_SCALE = 0.2f;
		this.IMAGE = true;
		this.factory = factory;
		selectImg = new C_IconSelector();
		if (IMAGE) {
			factory.registerImage(C_IconSelector.BOAT, selectImg.loadImage(C_IconSelector.BOAT));
			factory.registerImage(C_IconSelector.TRAIN, selectImg.loadImage(C_IconSelector.TRAIN));
			factory.registerImage(C_IconSelector.TRUCK, selectImg.loadImage(C_IconSelector.TRUCK));
			factory.registerImage(C_IconSelector.CAR, selectImg.loadImage(C_IconSelector.CAR));
			factory.registerImage(C_IconSelector.RATTUS_MATURE, selectImg.loadImage(C_IconSelector.RATTUS_MATURE));
			factory.registerImage(C_IconSelector.NEWBORN, selectImg.loadImage(C_IconSelector.NEWBORN));
			factory.registerImage(C_IconSelector.RATTUS_PREGNANT, selectImg.loadImage(C_IconSelector.RATTUS_PREGNANT));
			factory.registerImage(C_IconSelector.VEHICLE_LOADED, selectImg.loadImage(C_IconSelector.VEHICLE_LOADED));
			factory.registerImage(C_IconSelector.VEHICLE_PARKED, selectImg.loadImage(C_IconSelector.VEHICLE_PARKED));
		}
	}
	public void initMusTransport(ShapeFactory2D factory) {
		this.ELLIPSE_SCALE = 3.f;
		IMAGE_SCALE = .7f;
		this.IMAGE = true;
		this.factory = factory;
		selectImg = new C_IconSelector();
		if (IMAGE) {
			factory.registerImage(C_IconSelector.BOAT, selectImg.loadImage(C_IconSelector.BOAT));
			factory.registerImage(C_IconSelector.TRAIN, selectImg.loadImage(C_IconSelector.TRAIN));
			factory.registerImage(C_IconSelector.TRUCK, selectImg.loadImage(C_IconSelector.TRUCK));
			factory.registerImage(C_IconSelector.TAXI, selectImg.loadImage(C_IconSelector.TAXI));
			factory.registerImage(C_IconSelector.MUS, selectImg.loadImage(C_IconSelector.MUS));
			factory.registerImage(C_IconSelector.RATTUS_MATURE, selectImg.loadImage(C_IconSelector.RATTUS_MATURE));
			factory.registerImage(C_IconSelector.NEWBORN, selectImg.loadImage(C_IconSelector.NEWBORN));
			factory.registerImage(C_IconSelector.RATTUS_PREGNANT, selectImg.loadImage(C_IconSelector.RATTUS_PREGNANT));
			factory.registerImage(C_IconSelector.MUS_PREGNANT, selectImg.loadImage(C_IconSelector.MUS_PREGNANT));
			factory.registerImage(C_IconSelector.VEHICLE_LOADED, selectImg.loadImage(C_IconSelector.VEHICLE_LOADED));
			factory.registerImage(C_IconSelector.VEHICLE_PARKED, selectImg.loadImage(C_IconSelector.VEHICLE_PARKED));
			factory.registerImage(C_IconSelector.MUSTDIE, selectImg.loadImage(C_IconSelector.MUSTDIE));
		}
	}
	public void initDecenal(ShapeFactory2D factory) {
		this.ELLIPSE_SCALE = .6f;
		IMAGE_SCALE = 0.4f;
		this.IMAGE = true;
		this.factory = factory;
		selectImg = new C_IconSelector();
		if (IMAGE) {
			factory.registerImage(C_IconSelector.BOAT, selectImg.loadImage(C_IconSelector.BOAT));
			factory.registerImage(C_IconSelector.TRAIN, selectImg.loadImage(C_IconSelector.TRAIN));
			factory.registerImage(C_IconSelector.TRUCK, selectImg.loadImage(C_IconSelector.TRUCK));
			factory.registerImage(C_IconSelector.TAXI, selectImg.loadImage(C_IconSelector.TAXI));
			factory.registerImage(C_IconSelector.RATTUS_MATURE, selectImg.loadImage(C_IconSelector.RATTUS_MATURE));
			factory.registerImage(C_IconSelector.NEWBORN, selectImg.loadImage(C_IconSelector.NEWBORN));
			factory.registerImage(C_IconSelector.VEHICLE_LOADED, selectImg.loadImage(C_IconSelector.VEHICLE_LOADED));
			factory.registerImage(C_IconSelector.VEHICLE_PARKED, selectImg.loadImage(C_IconSelector.VEHICLE_PARKED));
		}
	}
	public void initEnclosMbour(ShapeFactory2D factory) {
		this.IMAGE_SCALE = .15f;
		this.ELLIPSE_SCALE = 1.5f;
		this.IMAGE = false;
		this.factory = factory;
		selectImg = new C_IconSelector();
		if (IMAGE) {
			factory.registerImage(C_IconSelector.ERYTHROLEUCUS, selectImg.loadImage(C_IconSelector.ERYTHROLEUCUS));
			factory.registerImage(C_IconSelector.NATALENSIS, selectImg.loadImage(C_IconSelector.NATALENSIS));
			factory.registerImage(C_IconSelector.LAZARUS, selectImg.loadImage(C_IconSelector.LAZARUS));
			factory.registerImage(C_IconSelector.HYBRID, selectImg.loadImage(C_IconSelector.HYBRID));
			factory.registerImage(C_IconSelector.CAGE_PREGNANT, selectImg.loadImage(C_IconSelector.CAGE_PREGNANT));
			factory.registerImage(C_IconSelector.UNKNOWN, selectImg.loadImage(C_IconSelector.UNKNOWN));
		}
	}

	public void initBandia(ShapeFactory2D factory) {
		this.ELLIPSE_SCALE = 2.f;
		this.IMAGE = false;
		this.factory = factory;
		selectImg = new C_IconSelector();
		if (IMAGE) {
			factory.registerImage(C_IconSelector.ERYTHROLEUCUS, selectImg.loadImage(C_IconSelector.ERYTHROLEUCUS));
			factory.registerImage(C_IconSelector.LOADED_TRAP, selectImg.loadImage(C_IconSelector.LOADED_TRAP));
			factory.registerImage(C_IconSelector.EMPTY_TRAP, selectImg.loadImage(C_IconSelector.EMPTY_TRAP));
		}
	}

	/** Attribue une nouvelle "image" � un agent ou la modifie si besoin est, sinon renvoie le spatial en param�tre sans le modifier.
	 * @param agent : l'agent � qui appartient l'ic�ne
	 * @param spatial : repr�sentation de l'agent (image ou forme g�om�trique) */
	@Override
	public VSpatial getVSpatial(I_SituatedThing agent, VSpatial spatial) {
		if (((A_VisibleAgent) agent).hasToSwitchFace || spatial == null) {
			if (IMAGE) spatial = factory.getNamedSpatial(selectImg.getNameOfImage(agent));
			else spatial = factory.createCircle(CIRCLE_RADIUS, CIRCLE_SLICES);
			((A_VisibleAgent) agent).hasToSwitchFace = false;
		}
		return spatial;
	}

	@Override
	public Color getColor(I_SituatedThing agent) {
		if (IMAGE) return Color.white; // the color is not important
		else return C_IconSelector.getColor(agent);
	}

	@Override
	/** getscale modified only for vegetation, rev. M.Sall 03.2016 */
	public float getScale(I_SituatedThing object) {
		if (IMAGE) {// TODO number in source 03-2016
			if (object instanceof C_Vegetation) return (float) (((C_Vegetation) object).getBiomass_Ugram() * .00002);
			// TODO MS 01-2017 change scale of rodent image when her current soil cell is a burrow
			if ((object instanceof C_RodentGerbil) && (((C_RodentGerbil) object).getCurrentSoilCell() instanceof C_BurrowSystem)) {
				return .05f;
			}
			return IMAGE_SCALE;
		}
		else {
			if ((object instanceof A_Amniote) && (((A_Amniote) object).isPregnant())) return ELLIPSE_SCALE * 2;
			// TODO MS 2016.03 number in source
			else if (object instanceof C_Vegetation) return (float) (((C_Vegetation) object).getBiomass_Ugram() * .00005);
		}
		return ELLIPSE_SCALE;
	}
	// OVERRIDE & UNUSED METHODS //
	public float getRotation(I_SituatedThing object) {
		return 0;
	}
	public int getBorderSize(I_SituatedThing object) {
		return 0;
	}
	public Color getBorderColor(I_SituatedThing object) {
		return null;
	}
	public String getLabel(I_SituatedThing object) {
		return object.toString();
	}
	public Font getLabelFont(I_SituatedThing object) {
		return null;
	}
	public float getLabelXOffset(I_SituatedThing object) {
		return 0;
	}
	public float getLabelYOffset(I_SituatedThing object) {
		return 0;
	}
	public Position getLabelPosition(I_SituatedThing object) {
		return null;
	}
	public Color getLabelColor(I_SituatedThing object) {
		return null;
	}
}
