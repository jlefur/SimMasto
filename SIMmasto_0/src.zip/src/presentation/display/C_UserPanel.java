package presentation.display;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.ScrollPaneConstants;

import presentation.epiphyte.C_InspectorColonialRodents;
import presentation.epiphyte.C_InspectorPopulation;
import presentation.epiphyte.C_InspectorTransportation;
import repast.simphony.engine.environment.RunState;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.userpanel.ui.UserPanelCreator;
import simmasto0.C_ContextCreator;
import simmasto0.protocol.A_Protocol;
import bsh.util.JConsole;

/** Tableau de bord de la simulation. Contient la date de la simulation (� chaque tick), des m�teurs et un retour de la console.
 * @author A Realini, rev. Le Fur feb., jul. 2013 */
public class C_UserPanel extends JPanel implements UserPanelCreator {
	private static final long serialVersionUID = 1L;
	private static C_InspectorColonialRodents burrowInspector = null;
	private static C_InspectorTransportation transportationInspector = null;
	private final int VAL_MAX_SIZE_POP = 1000;
	private int width = 317;
	private C_Chart sexRatio;
	private C_InspectorPopulation inspector;
	/** Val max du meter de la richesse all�lique */
	// private final int VAL_MAX_MOY_ALL = 60;
	// private final int VAL_MAX_BURROWS = 100;
	// private final int VAL_MAX_FIS = 100;
	// private final int VAL_MAX_DISPERSAL = 70;
	// private final int VAL_MAX_AFFINITY_WITH_AREA = 4000;
	private final int VAL_MAX_PERCENT = 100;

	public static final String METER_POP = "Population";
	// public static final String METER_ALL = "Allelic richness";
	// public static final String METER_TUN = "Terriers";
	// public static final String METER_FIS = "Fixation Index (x100)";
	// public static final String METER_DIS = "Fem. mean dispersal";
	// public static final String METER_AFFINITY = "mean affinity with area";
	public static String METER_RIGHT_TITLE;
	private Font font;
	private JLabel dateLab;
	public static JConsole console = null;
	private C_Meter meterPop;
	/** meterAffinity, meterLoaded, meterWanderers; */
	private C_Meter meterRight;

	private BufferedImage img = null;

	public C_UserPanel() {
		RunState.getInstance().getMasterContext().add(this);
		init();
	}

	/** Initialise les composants du tableau de bord */
	private void init() {
		if (burrowInspector != null) METER_RIGHT_TITLE = "% of wandering rodents";
		else if (transportationInspector != null) METER_RIGHT_TITLE = "N cities";
		else METER_RIGHT_TITLE = "Objects";

		font = new Font("SansSerif", 50, 25);
		setLayout(new BorderLayout());
		this.setAutoscrolls(false);
		// gestion de l'image centrale (JLF - june 2011)
		try {
			img = ImageIO.read(new File("icons/campagnoldeschamps.jpg"));
		} catch (IOException e) {}
		JLabel image = new JLabel();
		image.setIcon(new ImageIcon(img));
		image.setPreferredSize(new Dimension(width, 100));
		image.setMaximumSize(image.getPreferredSize());
		// add(image, BorderLayout.NORTH);

		// GESTION DE LA DATE //

		dateLab = new JLabel();
		dateLab.setFont(font);
		// dateLab.setText(C_ContextCreator.protocol.getStringLongDate());
		dateLab.setText(C_ContextCreator.protocol.getStringHourDate());
		// dateLab.setSize(200, 40);
		add(dateLab, BorderLayout.NORTH);

		// GESTION DES COMPTEURS //

		meterPop = new C_Meter(METER_POP, true, VAL_MAX_SIZE_POP);
		meterPop.getPan().setMaximumSize(new Dimension(width * 4 / 11, width * 3 / 11));
		add(meterPop.getPan(), BorderLayout.WEST);
		if (transportationInspector != null) meterRight = new C_Meter(METER_RIGHT_TITLE, true, VAL_MAX_SIZE_POP);
		else if (burrowInspector != null) meterRight = new C_Meter(METER_RIGHT_TITLE, false, VAL_MAX_PERCENT);
		else meterRight = new C_Meter(METER_RIGHT_TITLE, true, 100);
		meterRight.getPan().setMaximumSize(new Dimension(width * 4 / 11, width * 3 / 11));
		add(meterRight.getPan(), BorderLayout.EAST);
		// meterAffinity = new C_Meter(METER_AFFINITY, false,
		// VAL_MAX_AFFINITY_WITH_AREA);// meanAffinityWithArea)
		// add(meterAffinity.getPan(), BorderLayout.EAST);
		// meterDis = new C_Meter(METER_DIS, false, VAL_MAX_DISPERSAL);
		// add(meterDis.getPan(), BorderLayout.EAST);
		// meterAll = new C_Meter(METER_ALL, false, VAL_MAX_MOY_ALL);
		// add(meterAll.getPan(), BorderLayout.EAST);
		// meterFIS = new C_Meter(METER_FIS, false, -100, 100);
		// add(meterFIS.getPan(), BorderLayout.EAST);

		//
		sexRatio = new C_Chart("sex-ratio", C_Chart.PIE2D);
		sexRatio.addData("Females", 1, null);
		sexRatio.addData("Males", 1, null);
		sexRatio.addData("Birth", 1, null);
		sexRatio.addData("Death", 1, null);
		sexRatio.getChartPanel().setPreferredSize(new Dimension(width * 4 / 11, width * 3 / 11));
		add(sexRatio.getChartPanel(), BorderLayout.CENTER);

		// GESTION DE LA CONSOLE //

		console = new JConsole();
		console.createHorizontalScrollBar();
		console.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		console.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		console.setVisible(true);
		console.setFont(new Font("serif", Font.PLAIN, 9));
		console.setPreferredSize(new Dimension(width, 370));// permet de garder les compteurs � leur taille normale
		System.setOut(console.getOut()); // redirect output to GUI console
		add(console, BorderLayout.SOUTH);
	}

	/** Met � jour les donn�es des compteurs */
	public void MAJ_Meters() {
		inspector = A_Protocol.inspector;
		meterPop.setData(C_InspectorPopulation.rodentList.size());
		if (burrowInspector != null) meterRight.setData(burrowInspector.getWanderingRodents_Upercent() * 100);
		else if (transportationInspector != null) {
			meterRight.setData(transportationInspector.getCityList().size());
			// meterWandering.setData(transportationInspector.getGlobalRodentLoad());
		}
		else meterRight.setData(RunState.getInstance().getMasterContext().size());
		sexRatio.setData("Females", C_InspectorPopulation.getNbFemales(), null);
		sexRatio.setData("Males", C_InspectorPopulation.getNbMales(), null);
		sexRatio.setData("Birth", inspector.getNbBirth(), null);
		sexRatio.setData("Death", inspector.getNbDeath(), null);
		// meterAll.setData(geneticInspector.getRichAllMoyenne());
		// meterAffinity.setData(inspector.getMeanAffinityWithArea()*1000);
		// meterDis.setData(inspector.getMeanFemaleDispersal());
		// meterFIS.setData(100 * geneticInspector.getFixationIndex());
	}

	@ScheduledMethod(start = 0, interval = 1, shuffle = false, priority = 0)
	public void step() {
		// dateLab.setText(C_ContextCreator.protocol.getStringLongDate());
		dateLab.setText(C_ContextCreator.protocol.getStringHourDate());
		MAJ_Meters();
	}
	/** M�thode utilis�e par le UserPanelCreator pour afficher le tableau de bord dans le userPanel */
	public JPanel createPanel() {
		return this;
	}
	public static void addBurrowInspector(C_InspectorColonialRodents inspector) {
		burrowInspector = inspector;
	}
	public static void addTransportationInspector(C_InspectorTransportation inspector) {
		transportationInspector = inspector;
	}
	@Override
	public String toString() {
		return "SimMasto panel";
	}
}
