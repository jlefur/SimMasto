package presentation.epiphyte;

import java.util.Iterator;
import java.util.TreeSet;

import presentation.dataOutput.C_FileWriter;
import repast.simphony.essentials.RepastEssentials;
import simmasto0.C_ContextCreator;
import simmasto0.protocol.C_ProtocolCage;
import thing.C_Rodent;
import thing.C_RodentCaged;
import thing.I_SituatedThing;
import thing.dna.C_GenomeMastoErythroleucus;
import thing.dna.C_GenomeMastoNatalensis;
import thing.dna.C_GenomeMastomys;
import data.C_Parameters;

/** From case study number 2 - MBour M2 A.Comte
 * @author J.Le Fur & A. Comte 03/2012, J.Le Fur 01.2013 */
public class C_InspectorHybrid extends A_Inspector {
	protected TreeSet<C_Rodent> hybridList;
	protected Integer nbEry = 0;
	protected Integer nbNat = 0;
	protected Integer nbHybrids = 0;
	protected Integer nbLazarus = 0;
	protected Double hybridsRate = 0.;
	protected int pbUnbalancedGene = 0;
	protected int pbSynteny = 0;
	protected int pbMatching = 0;
	protected int pbGeneNotFound = 0;
	protected int pbEpistasie = 0;
	protected int pbHaldane = 0;
	/** Writer of an outer csv file */
	private C_FileWriter dataSaverHybridsGeneral;
	private C_FileWriter dataSaverHybridsCages;
	private C_FileWriter dataSaverHybridsDiploidNumber;

	public C_InspectorHybrid() {
		super();
		indicatorsHeader = "Tick;Nb hybrids";
		hybridList = new TreeSet<C_Rodent>();
		dataSaverHybridsGeneral = new C_FileWriter("HybGeneralIndicators.csv", true);
		dataSaverHybridsGeneral
				.writeln("Tick;TaillePop;NbEry;NbNat;NbLaz;NbHyb;HybridsRate;pbUnbalancedGene;pbSynteny;pbGeneNotFound;pbEspistasie;pbMatching;pbHaldane");
		dataSaverHybridsCages = new C_FileWriter("MbourCages.csv", true);
		dataSaverHybridsCages.writeln("Tick;Line;Cages");
		dataSaverHybridsDiploidNumber = new C_FileWriter("DiploidNumber.csv", true);
		dataSaverHybridsDiploidNumber.writeln("Tick;8;9;10;11;12;13;14");
	}

	@Override
	public void step_Utick() {
		TreeSet<C_Rodent> rodentList = C_InspectorPopulation.rodentList;
		super.step_Utick();// compute in cascade and store indicators values
		if (rodentList.isEmpty()) // // close private files
		{
			dataSaverHybridsGeneral.writeln(RepastEssentials.GetTickCount() + ";0;0;0;0;0;0;0;0;0;0;0;0");
			dataSaverHybridsGeneral.closeFile();
			dataSaverHybridsCages.closeFile();
			dataSaverHybridsDiploidNumber.closeFile();
		}
		else { // save private files
			writeDataToFileGeneral();
			writeDataToFileDiploidNumber();
			if (C_Parameters.PROTOCOL.equals("CAGES")) writeDataToFileCages();
		}
		// reset the indicators accounting for problem at zygote formation
		pbUnbalancedGene = 0;
		pbSynteny = 0;
		pbGeneNotFound = 0;
		pbEpistasie = 0;
		pbMatching = 0;
		pbHaldane = 0;
	}
	@Override
	/** stores the current state of indicators in the field including the super ones 
	 * has to be conform with indicatorsHeader / JLF 01.2013*/
	public String indicatorsStoreValues() {
		indicatorsValues = RepastEssentials.GetTickCount() + CSV_FIELD_SEPARATOR + hybridList.size();
		return (indicatorsValues);
	}
	@Override
	public void indicatorsCompute() {
		TreeSet<C_Rodent> listRodents = C_InspectorPopulation.rodentList;
		nbEry = 0;
		nbNat = 0;
		nbLazarus = 0;
		nbHybrids = 0;
		hybridList.clear();
		Iterator<C_Rodent> rodents = listRodents.iterator();

		while (rodents.hasNext()) {
			C_Rodent rodent = rodents.next();
			if (rodent.getGenome() instanceof C_GenomeMastoErythroleucus) nbEry++;
			else if (rodent.getGenome() instanceof C_GenomeMastoNatalensis) nbNat++;
			else if (rodent.getGenome().isHybrid()) {
				nbHybrids++;
				this.hybridList.add(rodent);
			}
			else if (rodent.getGenome() instanceof C_GenomeMastomys) if (!rodent.getGenome().isHybrid()) nbLazarus++;
			else System.err.println("C_InspectorHybrid.computeRodentIndicators(): neither an ery or nat or masto: " + rodent);
		}
		this.hybridsRate = (double) this.nbHybrids / (double) listRodents.size();
	}

	/** Writes data in the hybrids indicators csv output file */
	private void writeDataToFileGeneral() {
		dataSaverHybridsGeneral.writeln(RepastEssentials.GetTickCount() + CSV_FIELD_SEPARATOR + C_InspectorPopulation.rodentList.size() + CSV_FIELD_SEPARATOR + nbEry + CSV_FIELD_SEPARATOR + nbNat
				+ CSV_FIELD_SEPARATOR + nbLazarus + CSV_FIELD_SEPARATOR + nbHybrids + CSV_FIELD_SEPARATOR + hybridsRate + CSV_FIELD_SEPARATOR + pbUnbalancedGene + CSV_FIELD_SEPARATOR + pbSynteny + CSV_FIELD_SEPARATOR + pbGeneNotFound + CSV_FIELD_SEPARATOR
				+ pbEpistasie + CSV_FIELD_SEPARATOR + pbMatching + CSV_FIELD_SEPARATOR + pbHaldane);
	}
	/** Writes data in the DiploidNumber csv output file */
	private void writeDataToFileDiploidNumber() {
		int nb8 = 0, nb9 = 0, nb10 = 0, nb11 = 0, nb12 = 0, nb13 = 0, nb14 = 0;
		for (C_Rodent rodent : C_InspectorPopulation.rodentList) {
			switch (rodent.getGenome().getDiploidNumber()) {
				case 8 :
					nb8++;
					break;
				case 9 :
					nb9++;
					break;
				case 10 :
					nb10++;
					break;
				case 11 :
					nb11++;
					break;
				case 12 :
					nb12++;
					break;
				case 13 :
					nb13++;
					break;
				case 14 :
					nb14++;
					break;
				default :
					break;
			}
		}
		dataSaverHybridsDiploidNumber.writeln(RepastEssentials.GetTickCount() + CSV_FIELD_SEPARATOR + nb8 + CSV_FIELD_SEPARATOR + nb9 + CSV_FIELD_SEPARATOR + nb10 + CSV_FIELD_SEPARATOR + nb11 + CSV_FIELD_SEPARATOR + nb12 + CSV_FIELD_SEPARATOR
				+ nb13 + CSV_FIELD_SEPARATOR + nb14);
	}

	/** Writes data in the cage report csv output file */
	private void writeDataToFileCages() {
		C_ProtocolCage cageProtocol = (C_ProtocolCage) C_ContextCreator.protocol;
		int nbBirth = 0;
		// test if there are any birth before writing the matrix
		nbBirth = 0;
		for (int i = 0; i < cageProtocol.getNB_CAGES_LINES(); i++) {
			for (int j = 0; j < cageProtocol.getNB_CAGES_COLUMNS(); j++) {
				for (I_SituatedThing rodent : cageProtocol.getCagesMatrix()[i][j].getRodentList()) {
					C_RodentCaged encagedRodent = (C_RodentCaged) rodent;
					if (encagedRodent.getAge_Uday() == 0) nbBirth++;
				}
			}
		}
		if (nbBirth != 0) {
			// writes the matrix in the file
			for (int i = 0; i < cageProtocol.getNB_CAGES_LINES(); i++) {
				dataSaverHybridsCages.write(RepastEssentials.GetTickCount() + CSV_FIELD_SEPARATOR + i + CSV_FIELD_SEPARATOR);
				for (int j = 0; j < cageProtocol.getNB_CAGES_COLUMNS(); j++) {
					nbBirth = 0;
					for (I_SituatedThing rodent : cageProtocol.getCagesMatrix()[i][j].getRodentList()) {
						C_RodentCaged encagedRodent = (C_RodentCaged) rodent;
						if (encagedRodent.getAge_Uday() == 0.) nbBirth++;
					}
					dataSaverHybridsCages.write(nbBirth + CSV_FIELD_SEPARATOR);
				}
				dataSaverHybridsCages.writeln("");
			}
			dataSaverHybridsCages.writeln("");
			dataSaverHybridsCages.writeln(" ");
		}
	}
	// close private files
	public void closeSimulation() {
		dataSaverHybridsGeneral.closeFile();
		dataSaverHybridsCages.closeFile();
		dataSaverHybridsDiploidNumber.closeFile();
	}
	//
	// SETTERS & GETTERS
	//
	public void incrPbUnbalancedGene() {
		pbUnbalancedGene++;
	}
	public void incrPbSynteny() {
		pbSynteny++;
	}
	public void incrPbGeneNotFound() {
		pbGeneNotFound++;
	}
	public void incrPbEpistasie() {
		pbEpistasie++;
	}
	public void incrPbMatching() {
		pbMatching++;
	}
	public void incrPbHaldane() {
		pbHaldane++;
	}
	public TreeSet<C_Rodent> getHybridList() {
		return hybridList;
	}
	public Integer getNbHybrids() {
		return nbHybrids;
	}
	public Double getHybridsRate() {
		return hybridsRate;
	}
	public Integer getNbEry() {
		return nbEry;
	}
	public Integer getNbNat() {
		return nbNat;
	}
	public Integer getNbLazarus() {
		return nbLazarus;
	}
	public int getPbUnbalancedGene() {
		return pbUnbalancedGene;
	}
	public int getPbAutostopNotFound() {
		return pbSynteny;
	}
	public int getPbGeneNotFound() {
		return pbGeneNotFound;
	}
}