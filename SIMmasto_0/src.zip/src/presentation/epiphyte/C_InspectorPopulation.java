/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt */
package presentation.epiphyte;

import java.util.Iterator;
import java.util.TreeSet;
import simmasto0.protocol.A_Protocol;
import thing.C_Rodent;
import thing.I_SituatedThing;

/** Data inspector: retrieves informations e.g. population sizes and manages lists.
 * @author A Realini 05.2011 / J.Le Fur 09.2011, 07.2012, 01.2013 */
public class C_InspectorPopulation extends A_Inspector {
	//
	// FIELDS
	//
	public static TreeSet<C_Rodent> rodentList = new TreeSet<C_Rodent>();
	protected static TreeSet<C_Rodent> rodentBirthList = new TreeSet<C_Rodent>();
	protected static int nbMales = 0, nbFemales = 0;
	protected int nbDeath = 0; // nbDeath is retrieved from the A_Protocol removeDeadRodents() procedure / JLF 02.2013
	protected int nbBirth = 0;
	protected int dispersedRodents = 0;
	protected double sexRatio = 0., deathRatio = 0., birthRatio = 0.;
	protected double maxDispersal = 0., maxFemaleDispersal = 0., maxMaleDispersal = 0., meanFemaleDispersal = 0.,
			meanMaleDispersal = 0.;
	//
	// CONSTRUCTOR
	//
	public C_InspectorPopulation() {
		super();
		rodentList.clear();
		rodentBirthList.clear();
		indicatorsHeader = indicatorsHeader
				+ ";PopSize;SexRatio;meanFemaleDispersal;meanMaleDispersal;maxFemaleDispersal;maxMaleDispersal;dispersedRodents;nbBirth;nbDeath";
	}
	//
	// METHODS
	//
	public void indicatorsCompute() {
		// Population size equal living, just birth and 'dead during this tick' rodents
		double rodentPopSize = (double) (C_InspectorPopulation.rodentList.size() + C_InspectorPopulation.rodentBirthList.size() + this.nbDeath);
		if (rodentPopSize > 0) {
			nbMales = 0;
			nbFemales = 0;
			int nbDispersedMales = 0;
			int nbDispersedFemales = 0;
			dispersedRodents = 0;
			maxDispersal = 0.;
			maxFemaleDispersal = 0.;
			maxMaleDispersal = 0.;
			meanFemaleDispersal = 0.;
			meanMaleDispersal = 0.;
			deathRatio = (double) nbDeath / rodentPopSize;
			birthRatio = (double) rodentBirthList.size() / rodentPopSize;
			nbBirth = rodentBirthList.size();
			// Transfer newborns to rodents list
			for (C_Rodent newBorn : rodentBirthList)
				rodentList.add(newBorn);
			rodentBirthList.clear();
			// Scan the rodents'list to compute indicators
			Iterator<C_Rodent> rodents = rodentList.iterator();
			while (rodents.hasNext()) {
				C_Rodent rodent = rodents.next();
				// double dispersalDistance = rodent.getCurrentDispersalDistance_Umeter();
				double dispersalDistance = rodent.getMaxDispersalDistance_Umeter();
				if (dispersalDistance > maxDispersal) maxDispersal = dispersalDistance;
				if (rodent.isMale()) {
					nbMales++;
					if (rodent.getMaxDispersalDistance_Umeter() > rodent.getSensing_Umeter()) {
						meanMaleDispersal += dispersalDistance;
						nbDispersedMales++;
						if (dispersalDistance > maxMaleDispersal) maxMaleDispersal = dispersalDistance;
					}
				}
				else if (rodent.isFemale()) {
					nbFemales++;
					if (rodent.getMaxDispersalDistance_Umeter() > rodent.getSensing_Umeter()) {
						meanFemaleDispersal += dispersalDistance;
						nbDispersedFemales++;
						if (dispersalDistance > maxFemaleDispersal) maxFemaleDispersal = dispersalDistance;
					}
				}
				else System.err.println("C_InspectorPopulation.computeRodentIndicators(): neither male or female; hybrid = "
						+ rodent.getGenome().isHybrid());

			}
			meanMaleDispersal = meanMaleDispersal / (double) nbDispersedMales;
			meanFemaleDispersal = meanFemaleDispersal / (double) nbDispersedFemales;
			dispersedRodents = nbDispersedFemales + nbDispersedMales;
			/** Compute sex ratio (Males/Females). simulation will stop if there are no more females */
			if (nbFemales > 0) sexRatio = (double) nbMales / (double) nbFemales;
			/*
			 * else { System.err.println(RepastEssentials.GetTickCount() + " No females: unable to compute sex ratio -> = -1");
			 * sexRatio = -1; }
			 */
		}
	}
	@Override
	/** stores the current state of indicators in the field including the super ones / JLF 01.2013*/
	public String indicatorsStoreValues() {
		indicatorsValues = super.indicatorsStoreValues() + CSV_FIELD_SEPARATOR + rodentList.size() + CSV_FIELD_SEPARATOR + sexRatio
				+ CSV_FIELD_SEPARATOR + meanFemaleDispersal + CSV_FIELD_SEPARATOR + meanMaleDispersal + CSV_FIELD_SEPARATOR
				+ maxFemaleDispersal + CSV_FIELD_SEPARATOR + maxMaleDispersal + CSV_FIELD_SEPARATOR
				+ dispersedRodents + CSV_FIELD_SEPARATOR + nbBirth + CSV_FIELD_SEPARATOR
				+ nbDeath;
		return indicatorsValues;
	}
	//
	// SETTERS & GETTERS
	//
	public void addRodentToList(C_Rodent rodent) {
		if (!rodentList.add(rodent)) System.err.println("C_InspectorPopulation.addRodentToList: could not add " + rodent);
	}
	@Override
	public void discardDeadThing(I_SituatedThing thing) {
		if ((thing instanceof C_Rodent) && !rodentList.remove(thing)) A_Protocol.event(
				"C_InspectorPopulation.discardDeadThing: could not remove " + thing, isError);
	}
	public static void addRodentToBirthList(C_Rodent rodent) {
		if (!rodentBirthList.add(rodent)) System.err.println("C_InspectorPopulation.addRodentToBirthList: could not add " + rodent);
	}
	public void setNbDeath_Urodent(int nbDeath) {
		this.nbDeath = nbDeath;
	}
	public double getDeathRatio() {
		return deathRatio;
	}
	public double getBirthRatio() {
		return birthRatio;
	}
	public int getNbDeath() {
		return nbDeath;
	}
	public int getNbBirth() {
		return nbBirth;
	}
	public static int getNbFemales() {
		return nbFemales;
	}
	public static int getNbMales() {
		return nbMales;
	}
	public static int getNbRodents() {
		return C_InspectorPopulation.rodentList.size();
	}
	public double getMaxFemaleDispersal() {
		return maxFemaleDispersal;
	}
	public double getMaxMaleDispersal() {
		return maxMaleDispersal;
	}
	public double getMeanFemaleDispersal() {
		return meanFemaleDispersal;
	}
	public double getMeanMaleDispersal() {
		return meanMaleDispersal;
	}
}
