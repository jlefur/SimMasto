package presentation.epiphyte;

import java.util.TreeSet;

import presentation.dataOutput.C_FileWriter;
import data.constants.I_ConstantGerbil;
import simmasto0.protocol.A_Protocol;
import thing.C_Vegetation;
import thing.dna.C_GenomeBalanites;
import thing.dna.C_GenomeFabacea;
import thing.dna.C_GenomePoacea;

/** Data inspector: retrieves informations e.g. la liste des v�g�tations.
 * @author M SALL 02.2016 */
public class C_InspectorVegetation extends A_Inspector implements I_ConstantGerbil {
	//
	// FIELD
	//
	private TreeSet<C_Vegetation> vegetationList = new TreeSet<C_Vegetation>();
	private double cropBiomass;
	private double shrubBiomass;
	private double grassBiomass;
	private C_FileWriter biomassCollector;
	private double rainFallMean;
	//
	// CONSTRUCTOR
	//
	public C_InspectorVegetation() {
		super();
		vegetationList.clear();
		biomassCollector = new C_FileWriter("outputData/GERBIL/dataOutputBiomass.csv", true);
		biomassCollector.writeln("DATE;Shrubs Biomass;Crops Biomass;Grasses Biomass;Average Precipitation");
	}
	//
	// GETTER
	//
	public TreeSet<C_Vegetation> getVegetationList() {
		return vegetationList;
	}
	public double getShrubBiomass() {
		shrubBiomass = .0;
		for (C_Vegetation one_Vegetation : vegetationList) {
			if (one_Vegetation.getGenome() instanceof C_GenomeBalanites) shrubBiomass += one_Vegetation.getBiomass_Ugram();
		}
		return shrubBiomass;
	}
	public double getGrassBiomass() {
		grassBiomass = .0;
		for (C_Vegetation one_Vegetation : vegetationList) {
			if (one_Vegetation.getGenome() instanceof C_GenomePoacea) grassBiomass += one_Vegetation.getBiomass_Ugram();
		}
		return grassBiomass;
	}
	public double getCropBiomass() {
		cropBiomass = .0;
		for (C_Vegetation one_Vegetation : vegetationList) {
			if (one_Vegetation.getGenome() instanceof C_GenomeFabacea) cropBiomass += one_Vegetation.getBiomass_Ugram();
		}
		return cropBiomass;
	}
	public double getRainFallMean() {
		return rainFallMean;
	}
	public void setRainFallMean(double rainFallMean) {
		this.rainFallMean = rainFallMean;
	}
	//
	// METHOD
	//
	public void dataOutPutBiomass(double overagePrecipitation) {
		String oneLineCollection = A_Protocol.protocolCalendar.stringShortDate() + ";" + this.getShrubBiomass() + ";" + this.getCropBiomass() + ";"
				+ this.getGrassBiomass() + ";" + overagePrecipitation;
		this.biomassCollector.writeln(oneLineCollection);
	}
	public void addVegetationToList(C_Vegetation oneVegetation) {
		if (!this.vegetationList.add(oneVegetation)) System.out.println("C_InspectorVegetation.addVegetationToList() : : could not add"
				+ oneVegetation);
	}
}
