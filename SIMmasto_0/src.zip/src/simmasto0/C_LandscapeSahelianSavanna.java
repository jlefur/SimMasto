package simmasto0;

import repast.simphony.context.Context;
import repast.simphony.valueLayer.GridValueLayer;
import thing.ground.C_SoilCellSavanna;

public class C_LandscapeSahelianSavanna extends C_Landscape {
	// TODO MS 2016-02 show rain in the valueLayer
	protected GridValueLayer rainGridValueLayer;
	// GETTER & SETTER
	public GridValueLayer getRainGridValueLayer() {
		return rainGridValueLayer;
	}
	public void setRainGridValueLayer(double rainValue,int i,int j) {
		this.rainGridValueLayer.set(rainValue,i,j);
	}
	//
	// CONSTRUCTOR
	//
	public C_LandscapeSahelianSavanna(Context<Object> context, String url, String gridValueName, String continuousSpaceName) {
		super(context, url, gridValueName, continuousSpaceName);
		context.addValueLayer(this.rainGridValueLayer);
		System.out.println("C_LandscapeSahelianSavanna(): sahelian savanna initialized");
	}
	//
	// METHOD
	//
	/** Initialize both (!) gridValueLayer and C_SoilCellSavanna matrices with the value read in the raster */
	@Override
	protected void createGround(int[][] matriceLue) {
		this.rainGridValueLayer = new GridValueLayer(proj_gridvalue2, true, new repast.simphony.space.grid.WrapAroundBorders(),
				this.dimension_Ucell.width, this.dimension_Ucell.height);
		for (int i = 0; i < this.dimension_Ucell.width; i++) {
			System.out.println();
			for (int j = 0; j < this.dimension_Ucell.height; j++) {
				if (matriceLue[i][j] <= 9) {
					System.out.print("0" + matriceLue[i][j] + ";");
				}
				else {
					System.out.print(matriceLue[i][j] + ";");
				}
				gridValueLayer.set(matriceLue[i][j], i, j);
				rainGridValueLayer.set(matriceLue[i][j], i, j);
				grid[i][j] = new C_SoilCellSavanna(matriceLue[i][j], i, j);// TODO JLF 2015.11 number in source affinity=7
			}
		}
		System.out.println();
	}
}
