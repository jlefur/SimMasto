/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt */
package simmasto0.protocol;
import java.awt.Dimension;
import java.util.Calendar;
import java.util.Date;
import java.util.List; // TODO PAM de JLF 2017.02 pourquoi pas un treeset ?
import java.util.TimeZone;
import java.util.TreeSet;

import presentation.dataOutput.C_FileWriter;
import presentation.display.C_Background;
import presentation.epiphyte.A_Inspector;
import presentation.epiphyte.C_InspectorPopulation;
import presentation.epiphyte.I_Inspector;
import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunState;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.essentials.RepastEssentials;
import simmasto0.C_Calendar;
import simmasto0.C_ContextCreator;
import simmasto0.C_Landscape;
import simmasto0.util.C_sound;
import thing.A_NDS;
import thing.A_VisibleAgent;
import thing.C_Rodent;
import thing.I_SituatedThing;
import thing.dna.C_GenomeAmniota;
import thing.ground.I_Container;

import com.vividsolutions.jts.geom.Coordinate;

import data.C_Chronogram;
import data.C_Event;
import data.C_Parameters;
import data.constants.I_ConstantString;
/** Master class for the various simmasto0.protocol of the SimMasto platform
 * @author Jean Le Fur & Pape Adama Mboup 07.2012, rev. JLF 02.2013, 08.2014, 10.2014 */
public abstract class A_Protocol implements I_Protocol, I_ConstantString {
	//
	// FIELDS
	//
	public static C_InspectorPopulation inspector = null;
	// TODO JLF 08.2014, 03.2015 Multiscale contexts: several protocols with their own calendar should run concurrently.
	// The field should thus not be static
	public static C_Calendar protocolCalendar = null;
	public C_Landscape landscape = null;// TODO JLF 2015.12 ->I_container landscape
	protected Context<Object> context = null;
	protected TreeSet<A_Inspector> inspectorList = null;
	protected C_FileWriter indicatorsFile = null; // TODO JLF 10.2014 output file must be managed by inspectors (epiphyte system)
	protected static Boolean breedingSeason = null;// TODO JLF 10.2014 put in other place ? (specific to species/environment)
	protected C_Chronogram chronogram = null;// Contains the whole chrono from the csv file
	protected C_Background facilityMap = null;// used for displaying a bitmap over the grid
	//
	// CONSTRUCTOR
	//
	public A_Protocol(Context<Object> ctxt) {
		this.context = ctxt;
		A_Protocol.protocolCalendar = new C_Calendar();
		initCalendar();// sets the date for the beginning of the simulation
		System.out.println("A_Protocol.constructor(): simulation starts at " + protocolCalendar.stringLongDate());
		readUserParameters();
		this.inspectorList = new TreeSet<A_Inspector>();
		this.indicatorsFile = new C_FileWriter("Indicateurs.csv", true);
		/** Initialization of the ground manager Author: LeFur 07.2012, rev Mboup 2013, Diakhate 2014 */
		System.out.println("A_Protocol() raster: " + C_Parameters.RASTER_URL);
		this.initLandscape(ctxt);
		System.out.println("A_Protocol(); identifying land plots ...");
		this.landscape.identifyAffinityLandPlots(ctxt);// INITIALIZE THE GROUNDED ITEMS
		A_VisibleAgent.init(this.landscape);
		System.out.println("A_Protocol(): Initialized visible AGENT class with their landscape ");
		A_Protocol.inspector = new C_InspectorPopulation();
		this.inspectorList.add(inspector);
		A_Protocol.breedingSeason = false;// TODO JLF 03.2015 misplaced
	}
	//
	// METHODS
	//
	/** The contact structure (term coined from S.E.Page: Diversity and Complexity) */
	protected void initLandscape(Context<Object> context) {
		this.setLandscape(new C_Landscape(context, C_Parameters.RASTER_URL, VALUE_LAYER_NAME, CONTINUOUS_SPACE_NAME));
	}
	/** In short: make this method first inherit its daughters at startup, then proceed to super (which is not the case within the
	 * constructor (super must be first there)<br>
	 * Longer: Triggered by the context creator at the beginning of the simulation and after constructing the protocol<br>
	 * The procedure can be realized only after all the CASCADING INSPECTORS and headers have been defined in the subclass hierarchy
	 * i.e., contains procedure that cannot be put in the constructor to avoid the overload when subclasses use super in their
	 * constructor */
	public void initProtocol() {
		System.out.println("A_Protocol.initProtocol(): " + C_ContextCreator.INSPECTOR_NUMBER + " inspectors defined: ");
		recordHeadersInFile();
		if (C_Parameters.DISPLAY_MAP) {
			contextualizeNewAgentInGrid(facilityMap, facilityMap.whereX, facilityMap.whereY);
			this.landscape.getContinuousSpace().moveByDisplacement(facilityMap, -.4, -.4);
		}// slightly adjust background position
	}
	/** The clock of the simulation (live and let die): get each A_NDS a tick<br>
	 * Check sizes of the rodents'list, manage time stuff, proceed to all NDSs' step, updates indicators, remove dead agents<br>
	 * Version Author J.Le Fur 2012, rev. 02.2013, 08.2014, 07.2015, 12.2015, 05.2016 */
	@ScheduledMethod(start = 0, interval = 1, shuffle = false)
	public void step_Utick() {
		if (chronogram != null) updateUniverseFromChrono(); // Manage chrono events if this protocol uses a chrono event file.
		manageTimeLandmarks();
		// checkRodentLists();// TODO JLF Slow simulation however, useful for some undetected ;-) bugs
		// Tip: Object[] contextContent = RunState.getInstance().getMasterContext().toArray();
		// LIVE AND LET DIE //
		removeDeadThings();// Kind of garbage collector for things tagged dead
		// Use a treeSet to ensure that NDS are always triggered in the same order
		TreeSet<A_NDS> ndsInContext = new TreeSet<A_NDS>();
		for (Object contextObject : this.context)
			if (contextObject instanceof A_NDS) ndsInContext.add((A_NDS) contextObject);
		for (A_NDS oneNds : ndsInContext) {
			oneNds.step_Utick();
		}
		inspector.step_Utick();
		recordIndicatorsInFile(); // Manage indicators file
		if (isSimulationEnd()) haltSimulation(); // and close files
	}
	/** Update the universe according to oneEventLine from Events <br />
	 * @param event from dataChrono */
	protected void manageOneEvent(C_Event event) {}
	/** Manage time, breeding season, agricultural changes Version Authors JEL2011, AR2011, rev. LeFur
	 * 2011,2012,04.2014,08.2014,09.2014 */
	public void manageTimeLandmarks() {
		int currentYear = protocolCalendar.get(Calendar.YEAR);
		protocolCalendar.incrementDate();
		// Beep if start or end of reproduction season
		if (breedingSeason != checkBreedingSeason()) if (C_Parameters.VERBOSE) System.out
				.println("A_Protocol.manageTimeLandmarks() start/end of breeding season");;
		this.readUserParameters();
		if (protocolCalendar.get(Calendar.YEAR) != currentYear) {
			this.landscape.resetCellsColor();
			// if (C_Parameters.VERBOSE) C_sound.sound("tip.wav");
		}
	}
	/** Update the environment with every events (chrono) occurred at the current date.<br>
	 * Triggers event management for each new event and all event types that occurred
	 * @see #manageOneEvent
	 * @see #manageReadEventTypes */
	protected void updateUniverseFromChrono() {
		// Chronogram tests dates, retrieves genuine events, processes the string stuff, fills in a TreeSet of C_Event.
		List<C_Event> readEvents = chronogram.retrieveCurrentEvents(protocolCalendar.getTime());
		if (readEvents != null) {
			TreeSet<String> eventTypes = new TreeSet<String>();
			int nbEvents = 0;
			Date date = readEvents.get(0).when_Ucalendar;
			for (C_Event oneEvent : readEvents) {
				if (!date.equals(oneEvent.when_Ucalendar)) {
					manageReadEventTypes(eventTypes);
					date = oneEvent.when_Ucalendar;
					eventTypes.clear();
				}
				// oneEvent.type can change after passing through manageOneEvent()
				// that's why "manageOneEvent(oneEvent);" is before "eventTypes.add(oneEvent.type);"
				manageOneEvent(oneEvent); // TODO PAM 08/12/15 touch�: lignes permut�es
				eventTypes.add(oneEvent.type);
				nbEvents++;
			}
			manageReadEventTypes(eventTypes);
			// print only if events occurred
			if (nbEvents > 0) {
				A_Protocol.event(nbEvents + " " + " event(s) read of type(s) " + eventTypes, isNotError);
				this.landscape.resetCellsColor();
			}
		}
	}
	/** This method must be redefined in daughter protocols */
	protected void manageReadEventTypes(TreeSet<String> eventTypes) {}
	/** Breeding season declaration : also manages situation where REPRO_START_Umonth > REPRO_END_Umonth */
	private boolean checkBreedingSeason() {
		if (C_Parameters.REPRO_START_Umonth < C_Parameters.REPRO_END_Umonth) {
			if (protocolCalendar.get(Calendar.MONTH) >= C_Parameters.REPRO_START_Umonth
					&& protocolCalendar.get(Calendar.MONTH) <= C_Parameters.REPRO_END_Umonth) return (breedingSeason = true);
		}
		// TODO MS 12.2016 comment to escape case when value of begin or end reproduction are null
		// else {
		// if ((protocolCalendar.get(Calendar.MONTH) >= C_Parameters.REPRO_START_Umonth && protocolCalendar.get(Calendar.MONTH) >=
		// C_Parameters.REPRO_END_Umonth)
		// || (protocolCalendar.get(Calendar.MONTH) <= C_Parameters.REPRO_START_Umonth && protocolCalendar
		// .get(Calendar.MONTH) <= C_Parameters.REPRO_END_Umonth)) return (breedingSeason = true);
		// }
		return (breedingSeason = false);
	}
	/** Declares a new object in the context and positions it within the raster ground
	 * @see #contextualizeNewAgentInCell */
	protected void contextualizeNewAgentInGrid(I_SituatedThing thing, int line_Ucell, int col_Ucell) {
		I_Container cell = this.landscape.getGrid()[line_Ucell][col_Ucell];
		contextualizeNewAgentInCell(thing, cell);
	}
	/** Declares a new object in the context and positions it within the raster ground */
	public void contextualizeNewAgentInCell(I_SituatedThing thing, I_Container cell) {
		if (!context.contains(thing)) {
			context.add(thing);
			this.landscape.moveToLocation(thing, cell.getCoordinate_Ucs());
			cell.agentIncoming(thing);
			if (thing instanceof A_VisibleAgent) ((A_VisibleAgent) thing).bornCoord_Umeter = this.landscape
					.getThingCoord_Umeter(thing);
			if (thing instanceof A_NDS) ((A_NDS) thing).setAge_Uday(0.);
			if (thing instanceof C_Rodent) {
				inspector.addRodentToList((C_Rodent) thing);
				((C_Rodent) thing).setAge_Uday(C_Parameters.FEMALE_SEXUAL_MATURITY_Uday);
			}
			if (thing instanceof C_Background) this.landscape.translate((A_VisibleAgent) thing, new Coordinate(
					-C_Parameters.UCS_WIDTH_Umeter / 2, -C_Parameters.UCS_WIDTH_Umeter / 2));
		}
		else A_Protocol.event("A_Protocol.contextualizeNewAgentInCell: " + ((A_NDS) thing).getThisName() + "/"
				+ ((A_NDS) thing).getMyId() + " already exist in context", isError);
	}
	public void contextualizeOldAgentInCell(I_SituatedThing thing, I_Container cell) {
		this.landscape.moveToContainer(thing, cell);
		this.landscape.moveToLocation(thing, cell.getCoordinate_Ucs());
	}
	/** LIVE AND LET DIE AGENTS 2/ RODENTS'DEATH PROCEDURE<br>
	 * To avoid concurrent modification exception as well as scrambling the order of rodents, all death procedure mark the rodent as
	 * having to die. The death and remove of dead rodents is then proceeded in one shot <br>
	 * @see A_Protocol#step_Utick
	 * @revision Author J.Le Fur 2012, rev. 02.2013, 12.2015, 04.2016 */
	protected int removeDeadThings() {
		Object[] things = this.context.toArray();// needed to avoid concurrent modification exception
		int nbDeath = 0, nbDeadRodents = 0;
		for (Object oneThing : things) {
			if ((oneThing instanceof A_NDS)) {
				if (((A_NDS) oneThing).isDead()) {
					if (oneThing instanceof C_Rodent) nbDeadRodents++;
					if (wipeOffObject((I_SituatedThing) oneThing)) nbDeath++; // i.e., if remove succeeded
					else A_Protocol.event("A_Protocol.removeDeadThings(), cannot remove dead " + oneThing, isError);
				}
			}
		}
		A_Protocol.inspector.setNbDeath_Urodent(nbDeadRodents);
		return nbDeath;
	}
	/** Destroy a thing, remove it from context and remove its references to other object (lastContainerLeft, inspectors) so as to be
	 * garbage collected<br>
	 * Version Jean-Emmanuel Longueville 2011-01, rev. JLF 2014, 12.2015, 04.2016 */
	public boolean wipeOffObject(I_SituatedThing deadThing) {
		for (I_Inspector inspector : this.inspectorList)
			inspector.discardDeadThing(deadThing);
		deadThing.discardThis();
		// TODO JLF 2015.06 in multiple context should be: Context<Object> context = ContextUtils.getContext(agent);
		boolean test = this.context.remove(deadThing);
		if (!test) A_Protocol.event("A_Protocol.wipeOffObject(): " + deadThing + " cannot be removed from context", isError);
		return test;
	}
	@Override
	public void readUserParameters() {
		C_Parameters.VERBOSE = ((Boolean) C_Parameters.parameters.getValue("VERBOSE")).booleanValue();
		initFixedParameters();
	}
	protected void initFixedParameters() {
		C_Parameters.EXCLOS = false;
		C_Parameters.TICK_MAX = 0; // TODO JLF 2015.10 remove ?
		C_Parameters.MAX_POP = 0; // TODO JLF 2015.10 remove ?
	}
	/** Fills the context with simple _wandering_ C_Rodent agents (as opposed to C_RodentFossorial's that dig burrows) <br>
	 * The sex ratio is randomly generated , rev. JLF 07.2014 currently unused */
	public void randomlyAddRodents(int nbAgent) {
		double[] newLocation = new double[2];
		Dimension dim = this.landscape.getDimension_Ucell();
		int grid_width = (int) dim.getWidth();
		int grid_height = (int) dim.getHeight();
		for (int i = 0; i < nbAgent; i++) {
			// BELOW, THREE POSSIBLE PATTERNS OF INITIAL DISTRIBUTION :
			// 1) Random number to produce a sensitivity analysis
			// int randx = (int)(Math.random()*grid_width);
			// int randy = (int)(Math.random()*grid_height);
			// 2) Reproducible random distribution
			int randx = (int) (C_ContextCreator.randomGeneratorForInitialisation.nextDouble() * grid_width);
			int randy = (int) (C_ContextCreator.randomGeneratorForInitialisation.nextDouble() * grid_height);
			// 3) Put all rodents at the middle at init:
			// int randx = (int) (grid_width / 2);
			// int randy = (int) (grid_height / 2);

			newLocation[0] = randx * C_Parameters.CELL_SIZE_UcontinuousSpace; // cell / cs.cell^-1 -> cs;
			newLocation[1] = randy * C_Parameters.CELL_SIZE_UcontinuousSpace; // cell / cs.cell^-1 -> cs;

			C_Rodent agent = createRodent();
			// Provide a random age to agents at initialization
			long randAge_Uday = Math.round(C_ContextCreator.randomGeneratorForInitialisation.nextDouble()
					* C_Parameters.FEMALE_SEXUAL_MATURITY_Uday);
			agent.setAge_Uday(randAge_Uday);
			contextualizeNewAgentInGrid(agent, randx, randy);
			agent.getNewRandomDisplacement();
		}
	}
	/** Record the current state of every inspectors'indicators in one unique .csv indicatorsFile */
	public void recordIndicatorsInFile() {
		String indicatorValues = "";
		for (A_Inspector inspector : inspectorList) {
			indicatorValues += inspector.getIndicatorsValues();
			indicatorValues += CSV_FIELD_SEPARATOR;
		}
		//indicatorValues += indicatorsFile.getNumRun();
		indicatorsFile.writeln(indicatorValues);
	}
	/** Record the current state of every inspectors'indicators in one unique .csv indicatorsFile */
	public void recordHeadersInFile() {
		String indicatorHeader = "";
		for (A_Inspector inspector : inspectorList) {
			indicatorHeader += inspector.getIndicatorsHeader();
			indicatorHeader += CSV_FIELD_SEPARATOR;
		}
		indicatorHeader += "NumRun";
		System.out.println("A_Protocol.recordHeadersInFile(): " + indicatorHeader);
		indicatorsFile.writeln(indicatorHeader);
	}
	public C_Rodent createRodent() {
		return new C_Rodent(new C_GenomeAmniota());
	}
	/** Check rodent list sizes */
	public void checkRodentLists() {
		TreeSet<C_Rodent> rodentList = C_InspectorPopulation.rodentList;
		int withinContext_Urodent = 0, withinSoilMatrix_Urodent = 0, trapped_Urodent = 0;
		Object[] contextContent = RunState.getInstance().getMasterContext().toArray();
		int contextSize = contextContent.length;
		for (int i = 0; i < contextSize; i++) {
			if (contextContent[i] instanceof C_Rodent) {
				withinContext_Urodent++;
				if (((C_Rodent) contextContent[i]).trappedOnBoard) trapped_Urodent++;
			}
		}
		for (int i = 0; i < this.landscape.dimension_Ucell.getWidth(); i++) {
			for (int j = 0; j < this.landscape.dimension_Ucell.getHeight(); j++) {
				if (!this.landscape.getGrid()[i][j].getFullRodentList().isEmpty()) withinSoilMatrix_Urodent += this.landscape
						.getGrid()[i][j].getFullRodentList().size();
			}
		}
		withinSoilMatrix_Urodent += trapped_Urodent;
		if ((withinContext_Urodent != rodentList.size()) || (withinSoilMatrix_Urodent != rodentList.size())) {
			A_Protocol.event("A_Protocol.checkRodentLists(): list sizes differ: rodentList/context/soilMatrix(trapped)"
					+ rodentList.size() + "/" + withinContext_Urodent + "/" + withinSoilMatrix_Urodent + " (" + trapped_Urodent
					+ ")", isError);
		}
	}
	/** record the current state of every inspectors'indicators in one unique .csv indicatorsFile,<br>
	 * count & display the simulation duration. Version author JLF, 2014, 05.2016 */
	protected void haltSimulation() {
		for (A_Inspector inspector : inspectorList)
			inspector.closeSimulation();
		double simLength = System.currentTimeMillis() - C_ContextCreator.simulationStartTime_Ums;
		A_Protocol.event("A_Protocol.haltSimulation(), simulation length: " + ((int) simLength / 1000) + "sec. (~"
				+ ((int) simLength / 60000) + "mn, ~" + ((int) simLength / 3600000) + "h.) / Tick "
				+ (int) RepastEssentials.GetTickCount() + ".", isNotError);
		indicatorsFile.closeFile();
		if (C_Parameters.VERBOSE) C_sound.sound("bip.wav");
		RepastEssentials.EndSimulationRun(); // Halt simulation once all step_Utick() are proceeded !
	}
	/** Display the map if on, remove it if off. Only one map object. The switch can only go from on to off and vice versa Version
	 * author J.Le Fur, 09.2014 */
	protected void switchDisplayMap() {
		if (context.contains(facilityMap)) this.wipeOffObject(facilityMap);// wipe off map
		else {
			contextualizeNewAgentInGrid(facilityMap, facilityMap.whereX, facilityMap.whereY);
			this.landscape.getContinuousSpace().moveByDisplacement(facilityMap, -.4, -.4);// slightly adjust background position
																							// TODO JLF 02.2016 misplaced
		}
	}
	/** Sets the initial time for simulation. Sets it to current time if not declared in daughter protocols. */
	public void initCalendar() {// TODO JLF 2015.04 Could also be the first date read on chronogram
		Date date = new Date();// get current date of the run
		Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
		calendar.setTime(date);
		protocolCalendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
		protocolCalendar.get(Calendar.YEAR);
	}
	/** Exploratory, retrieve events and manage them appropriately. Here, tag and print them / author jlf 03.2015 */
	public static String event(String message, Boolean isError) {
		message = (int) RepastEssentials.GetTickCount() + " / " + protocolCalendar.stringHourDate() + ": " + message;
		if (isError) System.err.println(message);
		else System.out.println(message);
		return message;
	}
	//
	// SETTER & GETTERS
	//
	public void setLandscape(C_Landscape landscape) {
		this.landscape = landscape;
	}
	/** @return the current date of the protocol as a short string (jj/mm/aa) */
	public String getStringShortDate() {
		return protocolCalendar.stringShortDate();
	}
	/** @return the current date of the protocol as a long string (day month year)) */
	public String getStringLongDate() {
		return protocolCalendar.stringLongDate();
	}
	/** @return the current date of the protocol as a long string (day month year) + hour:min:sec */
	public String getStringHourDate() {
		return protocolCalendar.stringHourDate();
	}
	/** @return the value of seasonToMate (Boolean) */
	public static Boolean isBreedingSeason() {
		return breedingSeason;
	}
	/** Check if chronogram is exhausted or if a precondition is verified (e.g., population is < 2). <br>
	 * This method may be redefined by daughter protocols */
	public boolean isSimulationEnd() {
	//	if (RepastEssentials.GetTickCount() == 20000) return true;
		if ((chronogram != null) && (chronogram.isEndOfChrono)) {
			A_Protocol.event(protocolCalendar.stringShortDate()
					+ ": A_Protocol.isSimulationEnd(), chronogram exhausted; halting simulation", isNotError);
			return true;
		}
		if (C_Parameters.TICK_MAX != 0 && RepastEssentials.GetTickCount() >= C_Parameters.TICK_MAX) {
			A_Protocol.event(protocolCalendar.stringShortDate()
					+ ": A_Protocol.isSimulationEnd(), TickMax reached; halting simulation", isNotError);
			return true;
		}
		return false;
	}
}
