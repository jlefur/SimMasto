package simmasto0.protocol;

import java.util.Calendar;
import java.util.TreeSet;
import presentation.display.C_Background;
import presentation.display.C_CustomPanelSet;
import presentation.epiphyte.C_InspectorCMR;
import presentation.epiphyte.C_InspectorGenetic;
import repast.simphony.context.Context;
import thing.C_Rodent;
import thing.C_RodentCmr;
import thing.I_SituatedThing;
import thing.dna.C_GenomeMastoErythroleucus;
import thing.ground.C_Trap;
import thing.ground.I_Container;
import data.C_Chronogram;
import data.C_Event;
import data.C_Parameters;

/** initialize the simulation and manages the inputs coming from the csv events file
 * @author Diakhate & Le Fur july 2013, 08.2014 */
public class C_ProtocolBandia extends C_ProtocolFossorial implements data.constants.I_ConstantCmr {

	protected C_InspectorGenetic geneticInspector;
	protected C_InspectorCMR C_InspectorCMR;
	public static int numSession = 0; // unique id number for each session
	//
	// CONSTRUCTOR
	//
	public C_ProtocolBandia(Context<Object> ctxt) {
		super(ctxt);// Init parameters and higher level inspectors & displays
		geneticInspector = new C_InspectorGenetic();
		inspectorList.add(geneticInspector);
		C_CustomPanelSet.addGeneticInspector(geneticInspector);
		chronogram = new C_Chronogram(CHRONO_FILENAME); // Create and build the dataFromChrono
		// initialize the epiphyte system
		C_InspectorCMR = new C_InspectorCMR();
		inspectorList.add(C_InspectorCMR);
		C_CustomPanelSet.addCMRInspector(C_InspectorCMR);
		geneticInspector = new C_InspectorGenetic();
		inspectorList.add(geneticInspector);
		C_CustomPanelSet.addGeneticInspector(geneticInspector);
		facilityMap = new C_Background(-3.44, 95, 85);
	}
	//
	// METHODS
	//
	@Override
	public void readUserParameters() {
		super.readUserParameters();
		/** If true, display the affinity map, else display the value layer */
		C_Parameters.DISPLAY_MAP = ((Boolean) C_Parameters.parameters.getValue("DISPLAY_MAP")).booleanValue();
	}
	/** Used to compute the population in the trap system area (to be comparable with MNA). */
	@Override
	public void initProtocol() {
		super.initProtocol();
		setTrapArea_Ucell();
	}
	/** Check if map has to be switched
	 * Version JLF 08.2014, rev.10.2015 */
	@Override
	public void manageTimeLandmarks() {
		boolean displayMapBefore = C_Parameters.DISPLAY_MAP;
		super.manageTimeLandmarks();// read user parameters
		if (displayMapBefore != C_Parameters.DISPLAY_MAP) switchDisplayMap();
	}
	@Override
	/** Update the universe according to bandiaEvents (chrono)
	 * If the current simulation date is one date of bandiaEvents then account for the corresponding event 
	 * then proceed to inspector's step */
	public void step_Utick() {
		// Switch either configuration by (un)commenting the selected one :
		// 1) Disconnect events reader and proceed to one CMR session each new month, Le Fur 08/08/13.
		int currentDay = protocolCalendar.get(Calendar.DATE);
		if (currentDay == 03) addTrapSystem();
		else if (currentDay > 03 && currentDay < 8) checkTrapSystem(); // TODO number in source days when trap system is checked
		else if (currentDay == 8) removeTrapSystem();
		// 2) Read the effective protocol from the events' chrono
		// updateUniverseFromChrono();
		// this.removeDeadThings();
		geneticInspector.step_Utick();
		super.step_Utick();// has to come after the other inspectors step since it records indicators in file
	}
	/** Used to compute the population within the trap system area (provides a value comparable with MNA). <br>
	 * Has to be in protocol since the inspector does not know (correct ?) the raster JLF 08.2014 */
	public void setTrapArea_Ucell() {
		int x = 0, y = 0;
		TreeSet<I_Container> trapArea = new TreeSet<I_Container>();
		int intervalX_Umeter = (int) (TRAP_INTERVALx_Umeter / C_Parameters.CELL_WIDTH_Umeter);
		int intervalY_Umeter = (int) (TRAP_INTERVALy_Umeter / C_Parameters.CELL_WIDTH_Umeter);
		for (int i = 0; i < TRAP_COLS * intervalX_Umeter; i++) {
			x = TRAP0_x_Ucell + i;
			for (int j = 0; j < TRAP_LINES * intervalY_Umeter; j++) {
				y = TRAP0_y_Ucell + j;
				trapArea.add(this.landscape.getGrid()[x][y]);
			}
		}
		C_InspectorCMR.setTrapArea(trapArea);// inspector is in charge of computing the rodent pop. size within the area
	}
	@Override
	/** created rodents are of the Mastomys erythroleucus genus*/
	public C_Rodent createRodent() {
		return new C_RodentCmr(new C_GenomeMastoErythroleucus());
	}
	/** Create a trap and inform bandiaInspector */
	public void addOneTrap(int x, int y) {
		C_Trap oneTrap = new C_Trap(BURROW_SYSTEM_AFFINITY, x, y);
		contextualizeNewAgentInGrid(oneTrap, x, y);
		C_InspectorCMR.addTrap(oneTrap);
	}
	/** create a set of traps */
	public void addTrapSystem() {
		int x, y, nbTraps = 0;
		int intervalX = (int) (TRAP_INTERVALx_Umeter / C_Parameters.CELL_WIDTH_Umeter);
		int intervalY = (int) (TRAP_INTERVALy_Umeter / C_Parameters.CELL_WIDTH_Umeter);
		for (int i = 0; i < TRAP_COLS; i++) {
			x = TRAP0_x_Ucell + (i * intervalX);
			for (int j = 0; j < TRAP_LINES; j++) {
				y = TRAP0_y_Ucell + j * intervalY;
				addOneTrap(x, y);
				nbTraps++;
			}
		}
		A_Protocol.event(" Bandia protocol, trap system added (" + nbTraps + " traps)", isNotError);
	}
	/** Check one trap, tag rodent, open trap and release rodent */
	protected void checkTrap(C_Trap oneTrap) {
		for (I_SituatedThing thing : oneTrap.getFullOccupantList()) {
			C_RodentCmr rodent = (C_RodentCmr) thing;
			tag(rodent);
			rodent.recordCatch(C_ProtocolBandia.numSession, getStringShortDate());
			// release rodent
			oneTrap.openTrap();
			rodent.trappedOnBoard = false;
			rodent.actionRandomExitOfBurrow(); // make rodent escape
		}
	}
	/** Check a set of traps */
	public void checkTrapSystem() {
		for (C_Trap oneTrap : C_InspectorCMR.getTrapList())
			checkTrap(oneTrap);
		A_Protocol.event(getStringShortDate() + " Bandia protocol, trap system checked (current tag="
				+ C_InspectorCMR.taggedRodentsNumber + ")", isNotError);
	}
	/** add rodent tagged in bandiaInspector */
	protected void tag(C_RodentCmr rodent) {
		C_InspectorCMR.tag(rodent);
	}
	/** suppress traps and remove them in bandiaInspector */
	public void removeTrapSystem() {
		Object[] tempTrapList = C_InspectorCMR.getTrapList().toArray();// Needed to avoid concurrent modification exception
		C_Trap thisTrap = null;
		for (Object o : tempTrapList) {
			thisTrap = (C_Trap) o;
			if (!thisTrap.getFullOccupantList().isEmpty()) checkTrap(thisTrap);
			thisTrap.setDead(true);
		}
		// Process the elapsed session, compute the MNA,DRS and DMR indicators
		C_InspectorCMR.computeDRS(numSession);
		C_InspectorCMR.computeDMR(numSession);
		C_InspectorCMR.computeMNA(numSession);
		C_InspectorCMR.storeCMRIndicators(getStringShortDate());
		A_Protocol.event(" Bandia protocol, trap system removed", isNotError);
	}
	/** Update the universe according to oneEventLine from BandiaEvents
	 * @param oneEventLine from BandiaEvents(or dataChrono) */
	@Override
	protected void manageOneEvent(C_Event oneEvent) {
		String eventName = oneEvent.type;
		if (eventName.equals(ADD_TRAP)) addTrapSystem();
		else if (eventName.equals(CHECK_TRAP)) checkTrapSystem();
		else if (eventName.equals(REMOVE_TRAP)) {
			checkTrapSystem();
			removeTrapSystem();
		}
	}
	@Override
	public void initCalendar() {
		protocolCalendar.set(2008, Calendar.DECEMBER, 1);
	}
}
