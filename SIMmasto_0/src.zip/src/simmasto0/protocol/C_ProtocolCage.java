package simmasto0.protocol;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.TreeSet;

import presentation.display.C_CustomPanelSet;
import presentation.epiphyte.C_InspectorGenetic;
import presentation.epiphyte.C_InspectorHybrid;
import presentation.epiphyte.C_InspectorPopulation;
import repast.simphony.context.Context;
import simmasto0.C_ContextCreator;
import thing.C_Rodent;
import thing.C_RodentCaged;
import thing.I_SituatedThing;
import thing.dna.C_GenomeEucaryote;
import thing.dna.C_GenomeMastoErythroleucus;
import thing.dna.C_GenomeMastoNatalensis;
import thing.dna.C_GenomeMastomys;
import thing.ground.C_LandPlot;
import thing.ground.C_SoilCell;
import data.C_Parameters;
import data.constants.I_ConstantNumeric;

/** first line: nat x nat and ery x ery second line: nat x ery and ery x nat third line : hybrid x hybrid fourth line : hybrid x
 * nat(male) and hybrid x ery(male)
 * @author J.Le Fur, A.Comte 03/2012 */
public class C_ProtocolCage extends A_Protocol implements I_ConstantNumeric {
	//
	// FIELDS
	//
	private int FORBID_ZONE = 2; // affinity of plots outside the cages
	private int NB_CAGES_COLUMNS = 20, NB_CAGES_LINES = 11;
	private C_LandPlot cagesMatrix[][];
	protected C_InspectorGenetic geneticInspector;
	private C_InspectorHybrid hybridInspector;
	//
	// CONSTRUCTOR
	//
	/** declare the inspectors, add them to the inspector list, declare them to the panelInitializer for indicators graphs. Author J.
	 * Le Fur 02.2013 */
	public C_ProtocolCage(Context<Object> ctxt) {
		super(ctxt);
		cagesMatrix = new C_LandPlot[NB_CAGES_LINES][NB_CAGES_COLUMNS];
		geneticInspector = new C_InspectorGenetic();
		hybridInspector = new C_InspectorHybrid();
		inspectorList.add(geneticInspector);
		inspectorList.add(hybridInspector);
		C_GenomeEucaryote.init(hybridInspector);// declares the inspector that stores the lethal alleles causes JLF 02.2013
		C_CustomPanelSet.addGeneticInspector(geneticInspector);
		C_CustomPanelSet.addHybridInspector(hybridInspector);// declares the inspector to grasp the values for the
																// panel display JLF 02.2013
	}
	//
	// METHODS
	//
	/** Positions the pure rodents Ery and Nat in the cages for the beginning of the protocol. The first line: pures crosses nat x
	 * nat and ery x ery The second line: crosses nat x ery and ery x nat A-The third line: Hybrids from the second line are crossed
	 * with themselves B-The fourth line: Hybrids from the second line are crossed with pure males C-the fifth line: Hybrids from
	 * the second line are crossed with pure females Then, A,B and C are repeated for hybrids from the fourth line. Author J.Le Fur,
	 * A.Comte 03/2012 */
	@Override
	public void initProtocol() {
		TreeSet<C_LandPlot> landPlotList = (TreeSet<C_LandPlot>) this.landscape.getAffinityLandPlots().clone();
		for (C_LandPlot plot : landPlotList)
			if (plot.getAffinity() < FORBID_ZONE) this.landscape.getAffinityLandPlots().remove(plot);
		C_LandPlot[] landPlots = new C_LandPlot[NB_CAGES_COLUMNS * NB_CAGES_LINES];
		this.landscape.getAffinityLandPlots().toArray(landPlots);
		// invert the array, JLF 10.214
		for (int i = 0; i < landPlots.length / 2; i++) {
			C_LandPlot temp = landPlots[i];
			landPlots[i] = landPlots[landPlots.length - i - 1];
			landPlots[landPlots.length - i - 1] = temp;
		}
		C_RodentCaged male = null;
		C_RodentCaged female = null;
		// the PlotMatrice is created to have the origin (line = 0, col = 0) at the upper left cage.
		int line = NB_CAGES_LINES - 1, col = 0;
		for (C_LandPlot plot : landPlots) {
			if (col < NB_CAGES_COLUMNS) {
				if (line >= 0) {
					cagesMatrix[line][col] = plot;
					line--;
				}
				else {
					line = NB_CAGES_LINES - 1;
					col++;
					cagesMatrix[line][col] = plot;
					line--;
				}
			}
		}
		// (NB_CAGES_COLUMNS / 2) is to have half the column erythroleucus and the other half natalensis.
		for (int col2 = 0; col2 < NB_CAGES_COLUMNS / 2; col2++) {
			// ery x ery and nat x nat
			male = new C_RodentCaged(new C_GenomeMastoNatalensis(SEX_GENE_Y));
			female = new C_RodentCaged(new C_GenomeMastoNatalensis(SEX_GENE_X));
			contextualizeNewAgentInGrid(female, 0, col2);
			contextualizeNewAgentInGrid(male, 0, col2);
		}
		for (int col2 = NB_CAGES_COLUMNS / 2; col2 < NB_CAGES_COLUMNS; col2++) {
			male = new C_RodentCaged(new C_GenomeMastoErythroleucus(SEX_GENE_Y));
			female = new C_RodentCaged(new C_GenomeMastoErythroleucus(SEX_GENE_X));
			contextualizeNewAgentInGrid(female, 0, col2);
			contextualizeNewAgentInGrid(male, 0, col2);
		}
		// Mery x Fnat and Mnat x Fery
		for (int col2 = 0; col2 < NB_CAGES_COLUMNS / 2; col2++) {
			male = new C_RodentCaged(new C_GenomeMastoNatalensis(SEX_GENE_Y));
			female = new C_RodentCaged(new C_GenomeMastoErythroleucus(SEX_GENE_X));
			contextualizeNewAgentInGrid(female, 1, col2);
			contextualizeNewAgentInGrid(male, 1, col2);
		}
		for (int col2 = NB_CAGES_COLUMNS / 2; col2 < NB_CAGES_COLUMNS; col2++) {
			male = new C_RodentCaged(new C_GenomeMastoErythroleucus(SEX_GENE_Y));
			female = new C_RodentCaged(new C_GenomeMastoNatalensis(SEX_GENE_X));
			contextualizeNewAgentInGrid(female, 1, col2);
			contextualizeNewAgentInGrid(male, 1, col2);
		}
		// nat x Hyb and ery x Hyb --> here only the pure Nat and ery are added.
		for (int line2 = 1; (line2 * 3 + 1) < NB_CAGES_LINES; line2++) {
			for (int col2 = 0; col2 < NB_CAGES_COLUMNS / 2; col2++) {
				male = new C_RodentCaged(new C_GenomeMastoNatalensis(SEX_GENE_Y));
				contextualizeNewAgentInGrid(male, (line2 * 3), col2); // males are
				// added every
				// three lines
				female = new C_RodentCaged(new C_GenomeMastoNatalensis(SEX_GENE_X));
				// females are added every three lines after the males
				contextualizeNewAgentInGrid(female, (line2 * 3 + 1), col2);
			}
			for (int col2 = NB_CAGES_COLUMNS / 2; col2 < NB_CAGES_COLUMNS; col2++) {
				male = new C_RodentCaged(new C_GenomeMastoErythroleucus(SEX_GENE_Y));
				contextualizeNewAgentInGrid(male, (line2 * 3), col2); // males are
				// added every
				// three lines
				female = new C_RodentCaged(new C_GenomeMastoErythroleucus(SEX_GENE_X));
				// females are added every three lines after the males
				contextualizeNewAgentInGrid(female, (line2 * 3 + 1), col2);
			}
		}
		super.initProtocol();
	}
	@Override
	protected void contextualizeNewAgentInGrid(I_SituatedThing animal, int line, int col) {
		context.add(animal);
		int h = (int) (C_ContextCreator.randomGeneratorForInitialisation.nextDouble() * (cagesMatrix[line][col]).getCells().size());
		C_SoilCell cell = (cagesMatrix[line][col]).retrieveOneCell(h);
		this.landscape.moveToLocation(animal, cell.getCoordinate_Ucs());
		cell.agentIncoming(animal);
		C_RodentCaged rodent = (C_RodentCaged) animal;
		rodent.bornCoord_Umeter = this.landscape.getThingCoord_Umeter(rodent);
		rodent.setAge_Uday(C_Parameters.FEMALE_SEXUAL_MATURITY_Uday);
		rodent.setBirthCage(cagesMatrix[line][col]);
		rodent.setCurrentCage(cagesMatrix[line][col]);
		rodent.setCurrentLine(line);
		inspector.addRodentToList(rodent);
	}

	/** method must be called at each step */
	@Override
	public void step_Utick() {
		boolean found = false;
		int lineHybrids = 2, lineHybrids2 = 5, lineHybrids3 = 8, lineMixMale1 = 3, lineMixFemale1 = 4, lineMixMale2 = 6, lineMixFemale2 = 7, lineMixMale3 = 9, lineMixFemale3 = 10;
		TreeSet<C_Rodent> hybridListCopy = C_InspectorPopulation.rodentList;
		geneticInspector.step_Utick();
		hybridInspector.step_Utick();
		super.step_Utick();// has to be after the other inspectors step since it records indicators in file

		//
		// LOOP NO 1
		//
		for (C_Rodent rodent : hybridListCopy) {
			found = false;
			if (rodent.getGenome().getClass() == C_GenomeMastomys.class) {
				C_RodentCaged cagedRodent = (C_RodentCaged) rodent;
				if (cagedRodent.getCurrentLine() == 1) {// has to originate from this line
					for (int col = 0; col < NB_CAGES_COLUMNS; col++) {
						C_LandPlot cage = cagesMatrix[lineHybrids][col];
						TreeSet<C_Rodent> occupants = cage.getFullRodentList();
						if (occupants.isEmpty()) {
							changeCage(cagedRodent, lineHybrids, col, "F1");
							found = true;
							break;
						}
						else if (occupants.size() == 1) {
							C_RodentCaged occupant = (C_RodentCaged) occupants.first();

							if ((occupant.getBirthCage() != cagedRodent.getBirthCage()) && (!sameSex(occupant, cagedRodent))) {
								changeCage(cagedRodent, lineHybrids, col, "F1");
								found = true;
								break;
							}
						}
					}
					if (!found) {
						for (int col = 0; col < NB_CAGES_COLUMNS; col++) {
							if ((cagesMatrix[lineMixMale1][col].getFullLoad_Urodent() == 1) && (cagedRodent.isFemale())) {
								changeCage(cagedRodent, lineMixMale1, col, "F1");
								found = true;
								break;
							}
							else if ((cagesMatrix[lineMixFemale1][col].getFullLoad_Urodent() == 1) && (cagedRodent.isMale())) {
								changeCage(cagedRodent, lineMixFemale1, col, "F1");
								found = true;
								break;
							}
						}
					}
				}
			}
		}
		//
		// LOOP NO 2
		//
		for (C_Rodent rodent : hybridListCopy) {
			found = false;
			if (rodent.getGenome().getClass() == C_GenomeMastomys.class) {
				C_RodentCaged cagedRodent = (C_RodentCaged) rodent;
				// has to originate from this line
				if ((cagedRodent.getCurrentLine() == 3) && (cagedRodent.generation != "F1")) {
					for (int col = 0; col < NB_CAGES_COLUMNS; col++) {
						C_LandPlot cage = cagesMatrix[lineHybrids2][col];
						TreeSet<C_Rodent> occupants = cage.getFullRodentList();
						if (occupants.isEmpty()) {
							changeCage(cagedRodent, lineHybrids2, col, "F2");
							found = true;
							break;
						}
						else if (occupants.size() == 1) {
							C_RodentCaged occupant = (C_RodentCaged) occupants.first();
							if ((occupant.getBirthCage() != cagedRodent.getBirthCage()) && (!sameSex(occupant, cagedRodent))) {
								changeCage(cagedRodent, lineHybrids2, col, "F2");
								found = true;
								break;
							}
						}
					}
					if (!found) {
						for (int col = 0; col < NB_CAGES_COLUMNS; col++) {
							if ((cagesMatrix[lineMixMale2][col].getFullLoad_Urodent() == 1) && (cagedRodent.isFemale())) {
								changeCage(cagedRodent, lineMixMale2, col, "F2");
								found = true;
								break;
							}
							else if ((cagesMatrix[lineMixFemale2][col].getFullLoad_Urodent() == 1) && (cagedRodent.isMale())) {
								changeCage(cagedRodent, lineMixFemale2, col, "F2");
								found = true;
								break;
							}
						}
					}
				}
			}
		}
		//
		// LOOP NO 3
		//
		for (C_Rodent rodent : hybridListCopy) {
			found = false;
			if (rodent.getGenome().getClass() == C_GenomeMastomys.class) {
				C_RodentCaged cagedRodent = (C_RodentCaged) rodent;
				// has to originate from this line
				if ((cagedRodent.getCurrentLine() == 6) && (cagedRodent.generation != "F2")) {
					for (int col = 0; col < NB_CAGES_COLUMNS; col++) {
						C_LandPlot cage = cagesMatrix[lineHybrids3][col];
						TreeSet<C_Rodent> occupants = cage.getFullRodentList();
						if (occupants.isEmpty()) {
							changeCage(cagedRodent, lineHybrids3, col, "F3");
							found = true;
							break;
						}
						else if (occupants.size() == 1) {
							C_RodentCaged occupant = (C_RodentCaged) occupants.first();

							if ((occupant.getBirthCage() != cagedRodent.getBirthCage()) && (!sameSex(occupant, cagedRodent))) {
								changeCage(cagedRodent, lineHybrids3, col, "F3");
								found = true;
								break;
							}
						}
					}
					if (!found) {
						for (int col = 0; col < NB_CAGES_COLUMNS; col++) {
							if ((cagesMatrix[lineMixMale3][col].getFullLoad_Urodent() == 1) && (cagedRodent.isFemale())) {
								changeCage(cagedRodent, lineMixMale3, col, "F3");
								found = true;
								break;
							}
							else if ((cagesMatrix[lineMixFemale3][col].getFullLoad_Urodent() == 1) && (cagedRodent.isMale())) {
								changeCage(cagedRodent, lineMixFemale3, col, "F3");
								found = true;
								break;
							}
						}
					}
				}
			}
		}
		// Killing rodents not used
		for (int line = 0; line < NB_CAGES_LINES; line++) {
			for (int col = 0; col < NB_CAGES_COLUMNS; col++) {
				C_LandPlot cage2 = cagesMatrix[line][col];
				TreeSet<C_Rodent> occupants2 = cage2.getFullRodentList();
				// System.out.println("C_ProtocolCage.step_Utick()" + occupants2);
				if (occupants2.size() >= 2) {
					ArrayList<C_RodentCaged> parents = new ArrayList<C_RodentCaged>();
					for (I_SituatedThing rodent : occupants2) {
						// Rodents are not killed if they are pure and born at the beginning of the simulation (i.e
						// first line, BirthDate = -1) OR if they are hybrid and older than newborn(age = 0).
						if ((((((C_RodentCaged) rodent).getGenome()).getClass() != C_GenomeMastomys.class) && (((C_RodentCaged) rodent)
								.getBirthDate_Utick() == -1))
								|| ((((C_RodentCaged) rodent).getAge_Uday() > 0))
								&& ((((C_RodentCaged) rodent).getGenome()).getClass() == C_GenomeMastomys.class)) {
							parents.add((C_RodentCaged) rodent);
						}
					}
					if (occupants2.size() > 2) {
						occupants2.removeAll(parents);
						for (Iterator<C_Rodent> iterator = occupants2.iterator(); iterator.hasNext();)
							iterator.next().testDeath(1);
					}
				}
			}
		}
	}
	private boolean sameSex(C_RodentCaged one, C_RodentCaged two) {
		if (one.isMale() && two.isMale()) return true;
		else if (one.isFemale() && two.isFemale()) return true;
		else if (one.isFemale() && two.isMale()) return false;
		if (one.isMale() && two.isFemale()) return false;
		else {
			System.err.println("C_ProtocolCage.compareSex(): unable to compute");
			return false;
		}
	}

	private void changeCage(C_RodentCaged rodent, int line, int col, String generation) {
		int h = (int) (C_ContextCreator.randomGeneratorForInitialisation.nextDouble() * (cagesMatrix[line][col]).getCells().size());
		rodent.generation = generation;
		C_SoilCell destinationCell = (cagesMatrix[line][col]).retrieveOneCell(h);
		contextualizeOldAgentInCell(rodent, destinationCell);
		rodent.setCurrentCage(cagesMatrix[line][col]);
		rodent.setCurrentLine(line);
	}

	public C_LandPlot[][] getCagesMatrix() {
		return cagesMatrix;
	}

	public int getNB_CAGES_COLUMNS() {
		return NB_CAGES_COLUMNS;
	}

	public int getNB_CAGES_LINES() {
		return NB_CAGES_LINES;
	}

	@Override
	public void readUserParameters() {
		super.readUserParameters();
		C_Parameters.INIT_RODENT_POP_SIZE = ((Integer) C_Parameters.parameters.getValue("INIT_POP_SIZE")).intValue();
		// DYNAMIC AGENTS CONSTANTS //
		C_Parameters.RODENT_SPEED_UmeterByTick = ((Integer) C_Parameters.parameters.getValue("AGENT_SPEED_UmeterByDay")).intValue();
		C_Parameters.AGENT_PERCEPTION_RADIUS_UmeterByDay = ((Integer) C_Parameters.parameters
				.getValue("AGENT_PERCEPTION_RADIUS_UmeterByDay")).intValue();
		/** used only for the computation of the mortality table
		 * @see C_Rodent#getDeathProbabilityMicrotusArvalis_Uday */
		C_Parameters.MAX_AGE_Uday = ((Integer) C_Parameters.parameters.getValue("MAX_AGE_Uday")).intValue();
		// Reproduction attributes common to both sexes //
		C_Parameters.REPRO_START_Umonth = ((Integer) C_Parameters.parameters.getValue("REPRO_START_Umonth")).intValue(); // 91;
		C_Parameters.REPRO_END_Umonth = ((Integer) C_Parameters.parameters.getValue("REPRO_END_Umonth")).intValue();
	}

	@Override
	public void initCalendar() {
		protocolCalendar.set(2014, Calendar.JANUARY, 1);
	}
}
