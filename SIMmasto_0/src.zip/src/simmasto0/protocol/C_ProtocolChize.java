package simmasto0.protocol;

import java.util.Calendar;

import presentation.display.C_Background;
import presentation.display.C_CustomPanelSet;
import presentation.epiphyte.C_InspectorGenetic;
import repast.simphony.context.Context;
import thing.C_Rodent;
import thing.C_RodentFossorialColonial;
import thing.dna.C_GenomeMicrotusArvalis;
import data.C_CropRotationChize;
import data.C_Parameters;

/** author J.Le Fur, A.Comte 03.2012 / J.Le Fur 07.2012, 07.2014 */

public class C_ProtocolChize extends C_ProtocolFossorial {
	//
	// FIELDS
	//
	private C_CropRotationChize cropRotation = null;
	protected C_InspectorGenetic geneticInspector;
	//
	// CONSTRUCTOR
	//
	/** declare the inspectors, add them to the inspector list, declares them to the panelInitializer for indicators graphs. Author J.Le Fur 02.2013 */
	public C_ProtocolChize(Context<Object> ctxt) {
		super(ctxt);
		geneticInspector = new C_InspectorGenetic();
		inspectorList.add(geneticInspector);
		C_CustomPanelSet.addGeneticInspector(geneticInspector);
		cropRotation = new C_CropRotationChize(this.landscape);
		facilityMap = new C_Background(-.05, 26, 27);
	}
	//
	// METHODS
	//
	@Override
	public void readUserParameters() {
		super.readUserParameters();
		/** If true, display the affinity map, else display the value layer */
		C_Parameters.DISPLAY_MAP = ((Boolean) C_Parameters.parameters.getValue("DISPLAY_MAP")).booleanValue();
	}

	@Override
	/** randomly add burrows and randomly put fossorial rodent agents in them*/
	public void initProtocol() {
		super.initProtocol();// initializes burrow systems in C_ProtocolFossorial
		this.cropRotation.setInitialLandplotTypes();
	}
	@Override
	public C_Rodent createRodent() {
		return new C_RodentFossorialColonial(new C_GenomeMicrotusArvalis());
	}
	@Override
	public void step_Utick() {
		geneticInspector.step_Utick();
		super.step_Utick();// has to be after the other inspectors step since it records indicators in file
		this.landscape.resetCellsColor();// account for culture changes
	}
	@Override
	/** Manages agricultural changes Authors JEL2011, AR, rev. Le Fur 2011, 2012, 04.2014, 08.2014,09 */
	public void manageTimeLandmarks() {
		boolean displayMapBefore = C_Parameters.DISPLAY_MAP;// Check if map has to be switched
		int currentYear = protocolCalendar.get(Calendar.YEAR);
		int currentMonth = protocolCalendar.get(Calendar.MONTH);
		super.manageTimeLandmarks();
		if (displayMapBefore != C_Parameters.DISPLAY_MAP) switchDisplayMap();
		if (currentYear != protocolCalendar.get(Calendar.YEAR)) cropRotation.cropTransition(protocolCalendar.get(Calendar.MONTH));
		if (currentMonth != protocolCalendar.get(Calendar.MONTH)) cropRotation.culturalPractice(protocolCalendar.get(Calendar.MONTH));
	}
	@Override
	public void initCalendar() {
		protocolCalendar.set(2016, Calendar.APRIL, 2);
	}
}
