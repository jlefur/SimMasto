package simmasto0.protocol;

import java.util.Calendar;
import java.util.Date;

import presentation.display.C_Background;
import presentation.display.C_CustomPanelSet;
import presentation.display.C_IconNightDay;
import presentation.epiphyte.C_InspectorGenetic;
import repast.simphony.context.Context;
import simmasto0.C_Calendar;
import thing.C_Rodent;
import thing.C_RodentDomestic;
import thing.dna.C_GenomeMusMusculus;
import data.C_CircadianAffinitiesMus;
import data.C_Parameters;
import data.converters.C_ConvertTimeAndSpace;

/** author J.Le Fur & M.Diakhate 07.2014, rev. JLF 10.2014 */

public class C_ProtocolDodel extends A_Protocol {
	//
	// FIELDS
	//
	private C_CircadianAffinitiesMus circadianAffinities = null;
	protected C_InspectorGenetic geneticInspector;
	protected C_IconNightDay dayNight = null;// used for displaying a an icon sun/moon
	//
	// CONSTRUCTOR
	//
	/** declare the inspectors, add them to the inspector list, declares them to the panelInitializer for indicators graphs. Author J.Le Fur 02.2013 */
	public C_ProtocolDodel(Context<Object> ctxt) {
		super(ctxt);
		facilityMap = new C_Background(0.05, 13, 19);
		dayNight = new C_IconNightDay(0, 0, 37);
		geneticInspector = new C_InspectorGenetic();
		inspectorList.add(geneticInspector);
		C_CustomPanelSet.addGeneticInspector(geneticInspector);
		circadianAffinities = new C_CircadianAffinitiesMus(this.landscape);
	}
	//
	// METHODS
	//
	@Override
	public void initProtocol() {
		contextualizeNewAgentInGrid(dayNight, dayNight.whereX, dayNight.whereY);
		if (C_Parameters.DISPLAY_MAP) contextualizeNewAgentInGrid(facilityMap, facilityMap.whereX, facilityMap.whereY);
		this.circadianAffinities.setInitialAffinities();
		randomlyAddRodents(C_Parameters.INIT_RODENT_POP_SIZE);// add rodents within already created burrows
		System.out.println("C_ProtocolRodents(): Population of " + C_Parameters.INIT_RODENT_POP_SIZE + " rodents created and positioned randomly");
		super.initProtocol();// manage inspectors and files after everything
	}
	@Override
	public C_Rodent createRodent() {
		return new C_RodentDomestic(new C_GenomeMusMusculus());
	}
	@Override
	public void step_Utick() {
		this.dayNight.hasToSwitchFace = true;// always refresh the icon
		geneticInspector.step_Utick();
		super.step_Utick();// has to come after the other inspectors' step since it records indicators in file
		if (C_Parameters.TERMINATE) haltSimulation();
	}
	@Override
	public void manageTimeLandmarks() {
		boolean displayMapBefore = C_Parameters.DISPLAY_MAP;// has to be before the super (which reads parameters)
		super.manageTimeLandmarks();
		circadianAffinities.setAffinity(protocolCalendar.get(Calendar.HOUR_OF_DAY) / 2);
		this.landscape.resetCellsColor();
		// int hourOfDay = protocolCalendar.get(Calendar.HOUR_OF_DAY);
		if (displayMapBefore != C_Parameters.DISPLAY_MAP) switchDisplayMap();
	}
	@Override
	public void readUserParameters() {
		super.readUserParameters();
		/** If true, display the affinity map, else display the value layer */
		C_Parameters.DISPLAY_MAP = ((Boolean) C_Parameters.parameters.getValue("DISPLAY_MAP")).booleanValue();
		/** If true cleanly end the simulation */
		C_Parameters.TERMINATE = ((Boolean) C_Parameters.parameters.getValue("TERMINATE")).booleanValue();
		C_Parameters.INIT_RODENT_POP_SIZE = ((Integer) C_Parameters.parameters.getValue("INIT_POP_SIZE")).intValue();
		C_Parameters.RODENT_SPEED_UmeterByTick = ((Integer) C_Parameters.parameters.getValue("AGENT_SPEED_UmeterByDay")).intValue();
		C_Parameters.AGENT_PERCEPTION_RADIUS_UmeterByDay = ((Integer) C_Parameters.parameters.getValue("AGENT_PERCEPTION_RADIUS_UmeterByDay"))
				.intValue();
		C_Parameters.MAX_AGE_Uday = ((Integer) C_Parameters.parameters.getValue("MAX_AGE_Uday")).intValue();
		C_Parameters.MALE_SEXUAL_MATURITY_Uday = ((Integer) C_Parameters.parameters.getValue("MALE_SEXUAL_MATURITY_Uday")).intValue();
		C_Parameters.FEMALE_SEXUAL_MATURITY_Uday = ((Integer) C_Parameters.parameters.getValue("FEMALE_SEXUAL_MATURITY_Uday")).intValue();
		String oldUnit = C_Parameters.TICK_UNIT_Ucalendar;
		int oldAmount = C_Parameters.TICK_LENGTH_Ucalendar;
		C_Parameters.TICK_LENGTH_Ucalendar = ((Integer) C_Parameters.parameters.getValue("TICK_LENGTH_Ucalendar")).intValue();
		C_Parameters.TICK_UNIT_Ucalendar = (String) C_Parameters.parameters.getValue("TICK_UNIT_Ucalendar");
		if ((C_Parameters.TICK_LENGTH_Ucalendar != oldAmount) || (C_Parameters.TICK_UNIT_Ucalendar != oldUnit)) {
			// Reset time converter
			C_ConvertTimeAndSpace.init(C_Parameters.TICK_LENGTH_Ucalendar, C_Parameters.TICK_UNIT_Ucalendar, "M");
			// Calendar has also to be reset to account for the new timeSpaceConverter.
			Date savedDate = A_Protocol.protocolCalendar.getTime();
			A_Protocol.protocolCalendar = new C_Calendar();
			A_Protocol.protocolCalendar.setTime(savedDate);
			A_Protocol.event("A_ProtocolTransportation.readUserParameters(), new tick definition: " + C_Parameters.TICK_LENGTH_Ucalendar + " "
					+ C_Parameters.TICK_UNIT_Ucalendar, isNotError);
		}
	}
	@Override
	protected void initFixedParameters() {
		super.initFixedParameters();
		C_Parameters.REPRO_START_Umonth = 0;
		C_Parameters.REPRO_END_Umonth = 11;
	}
}