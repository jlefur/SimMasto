package simmasto0.protocol;

import java.util.Calendar;

import presentation.display.C_CustomPanelSet;
import presentation.display.C_UserPanel;
import presentation.epiphyte.C_InspectorColonialRodents;
import presentation.epiphyte.C_InspectorGenetic;
import presentation.epiphyte.C_InspectorHybrid;
import repast.simphony.context.Context;
import thing.C_Rodent;
import thing.dna.C_GenomeEucaryote;
import thing.dna.C_GenomeMastoErythroleucus;
import thing.dna.C_GenomeMastoNatalensis;
import data.C_Parameters;
import data.constants.I_ConstantNumeric;

/** author J.Le Fur, A.Comte 03/2012 / rev. J.Le Fur feb.2013 */

public class C_ProtocolEnclosure extends A_Protocol implements I_ConstantNumeric {
	protected C_InspectorGenetic geneticInspector;
	protected C_InspectorColonialRodents burrowInspector;
	protected C_InspectorHybrid hybridInspector;
	public C_ProtocolEnclosure(Context<Object> ctxt) {
		super(ctxt);// Init parameters and higher level inspectors & displays
		burrowInspector = new C_InspectorColonialRodents();
		geneticInspector = new C_InspectorGenetic();
		hybridInspector = new C_InspectorHybrid();
		inspectorList.add(hybridInspector);
		inspectorList.add(burrowInspector);
		inspectorList.add(geneticInspector);
		// declare the inspector that stores the lethal alleles causes JLF 02.2013
		C_GenomeEucaryote.init(hybridInspector);
		C_CustomPanelSet.addHybridInspector(hybridInspector);
		C_CustomPanelSet.addGeneticInspector(geneticInspector);
		C_UserPanel.addBurrowInspector(burrowInspector);
	}

	@Override
	public void initProtocol() { //TODO JLF 01.2012 use of Math.random() in protocole cage ~OK (robustless however)
		for (int i = 0; i < 4; i++) {
			C_Rodent female = new C_Rodent(new C_GenomeMastoNatalensis(SEX_GENE_X));
			contextualizeNewAgentInGrid(female, (int) (Math.random() * 40) + 4, (int) (Math.random() * 40) + 4);
		}
		for (int i = 0; i < 2; i++) {
			C_Rodent male = new C_Rodent(new C_GenomeMastoNatalensis(SEX_GENE_Y));
			contextualizeNewAgentInGrid(male, (int) (Math.random() * 40) + 4, (int) (Math.random() * 40) + 4);
		}
		for (int i = 0; i < 3; i++) {
			C_Rodent female = new C_Rodent(new C_GenomeMastoErythroleucus(SEX_GENE_X));
			contextualizeNewAgentInGrid(female, (int) (Math.random() * 40) + 48, (int) (Math.random() * 40) + 4);
		}
		for (int i = 0; i < 3; i++) {
			C_Rodent male = new C_Rodent(new C_GenomeMastoErythroleucus(SEX_GENE_Y));
			contextualizeNewAgentInGrid(male, (int) (Math.random() * 40) + 48, (int) (Math.random() * 40) + 4);
		}
		super.initProtocol();
	}
	@Override
	public void step_Utick() {
		geneticInspector.step_Utick();
		hybridInspector.step_Utick();
		burrowInspector.step_Utick();
		super.step_Utick();// has to be after the other inspectors step since it records indicators in file
	}

	@Override
	public void readUserParameters() {
		super.readUserParameters();
		C_Parameters.INIT_RODENT_POP_SIZE = ((Integer) C_Parameters.parameters.getValue("INIT_POP_SIZE")).intValue();
		C_Parameters.PERSISTANCE_BURROW = ((Boolean) C_Parameters.parameters.getValue("PERSISTANCE_BURROW")).booleanValue();
		C_Parameters.NUMBER_OF_BURROW_SYSTEM = ((Integer) C_Parameters.parameters.getValue("NUMBER_OF_BURROW_SYSTEM")).intValue();

		C_Parameters.RODENT_SPEED_UmeterByTick = ((Integer) C_Parameters.parameters.getValue("AGENT_SPEED_UmeterByDay")).intValue();
		C_Parameters.AGENT_PERCEPTION_RADIUS_UmeterByDay = ((Integer) C_Parameters.parameters
				.getValue("AGENT_PERCEPTION_RADIUS_UmeterByDay")).intValue();
		C_Parameters.MAX_AGE_Uday = ((Integer) C_Parameters.parameters.getValue("MAX_AGE_Uday")).intValue();
		C_Parameters.REPRO_START_Umonth = ((Integer) C_Parameters.parameters.getValue("REPRO_START_Umonth")).intValue();
		C_Parameters.REPRO_END_Umonth = ((Integer) C_Parameters.parameters.getValue("REPRO_END_Umonth")).intValue();
		C_Parameters.MALE_SEXUAL_MATURITY_Uday = ((Integer) C_Parameters.parameters.getValue("MALE_SEXUAL_MATURITY_Uday"))
				.intValue();
		C_Parameters.FEMALE_SEXUAL_MATURITY_Uday = ((Integer) C_Parameters.parameters.getValue("FEMALE_SEXUAL_MATURITY_Uday"))
				.intValue();
		C_Parameters.FEMALE_BURROW_SYSTEM_CARRYING_CAPACITY_MULTIPLIER = ((Integer) C_Parameters.parameters
				.getValue("FEMALE_BURROW_SYSTEM_CARRYING_CAPACITY_MULTIPLIER")).intValue();
	}

	@Override
	public void initCalendar() {
		protocolCalendar.set(2014, Calendar.JANUARY, 1);
	}
}
