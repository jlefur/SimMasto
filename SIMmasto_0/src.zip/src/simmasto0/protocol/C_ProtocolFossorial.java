package simmasto0.protocol;

import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;

import presentation.display.C_CustomPanelSet;
import presentation.display.C_UserPanel;
import presentation.epiphyte.C_InspectorColonialRodents;
import presentation.epiphyte.C_InspectorPopulation;
import repast.simphony.context.Context;
import simmasto0.C_ContextCreator;
import thing.C_Rodent;
import thing.C_RodentFossorial;
import thing.I_SituatedThing;
import thing.dna.C_GenomeAmniota;
import thing.ground.C_BurrowSystem;
import thing.ground.C_SoilCell;
import thing.ground.C_Trap;
import thing.ground.I_Container;
import data.C_Parameters;
import data.constants.I_ConstantNumeric;

/** author J.Le Fur, A.Comte 03.2012 / J.Le Fur 07.2012, 07.2013, 02.2014 */

public class C_ProtocolFossorial extends A_Protocol implements I_ConstantNumeric {
	//
	// FIELD
	//
	protected C_InspectorColonialRodents burrowInspector;
	//
	// CONSTRUCTOR
	//
	/** declare the inspectors, add them to the inspector list, declare them to the panelInitializer for indicators graphs. Author J.Le Fur 02.2013 */
	public C_ProtocolFossorial(Context<Object> ctxt) {
		super(ctxt);// Init parameters, raster ground and higher level inspectors & displays
		burrowInspector = new C_InspectorColonialRodents();
		inspectorList.add(burrowInspector);
		C_CustomPanelSet.addBurrowInspector(burrowInspector);
		C_UserPanel.addBurrowInspector(burrowInspector);
	}
	//
	// METHODS
	//
	/** Randomly add burrows and randomly put RodentAgents in them */
	@Override
	public void initProtocol() {
		// add burrow systems and agents within
		addBurrowSystems(C_Parameters.NUMBER_OF_BURROW_SYSTEM);
		randomlyAddRodents(C_Parameters.INIT_RODENT_POP_SIZE);// add rodents within already created burrows
		// clean unused burrows
		for (C_BurrowSystem burrow : burrowInspector.getBurrowList()) {
			if (burrow.getOccupantList().isEmpty()) {
				((C_SoilCell) burrow.getCurrentSoilCell()).containerRemoved(burrow);
				context.remove(burrow);
			}
		} // end of clean
		System.out.println("C_ProtocolFossorial.init(): " + burrowInspector.getNbBurrows() + "(asked: " + C_Parameters.NUMBER_OF_BURROW_SYSTEM
				+ ") burrows created");
		System.out.println("C_ProtocolFossorial.init(): Population of " + C_Parameters.INIT_RODENT_POP_SIZE
				+ " fossorial rodents created and positioned randomly in burrow systems");
		super.initProtocol();// manage inspectors and files after everything
	}
	@Override
	public void step_Utick() {
		burrowInspector.step_Utick();
		super.step_Utick();// has to come after the other inspectors step since it records indicators in file
	}
	protected int removeDeadThings() {
		for (C_BurrowSystem burrow : burrowInspector.getBurrowList())
			if (!(burrow instanceof C_Trap)) {
				if (burrow.getOccupantList().isEmpty()) if (burrow.getAnimalsTargetingMe().size() == 0) burrow.setDead(true);
			}
		return super.removeDeadThings();
	}
	@Override
	/** Declares a new object in the context and positions it within the raster ground; if burrow system, declare it to the inspector */
	public void contextualizeNewAgentInCell(I_SituatedThing thing, I_Container cell) {
		super.contextualizeNewAgentInCell(thing, cell);
		if (thing instanceof C_BurrowSystem) burrowInspector.addBurrowToList((C_BurrowSystem) thing);
	}
	/** Initializing the first set of burrowSystem.
	 * @param nbBurrowSystem Number of burrowSystem */
	public void addBurrowSystems(int nbBurrowSystem) {
		int x, y;
		double[] new_location = new double[2];
		I_Container[][] soilCellsMatrix = this.landscape.getGrid();
		Dimension dim = this.landscape.getDimension_Ucell();
		int grid_width = (int) dim.getWidth();
		int grid_height = (int) dim.getHeight();

		for (int i = 0; i < nbBurrowSystem; i++) {
			// BELOW, THREE POSSIBLE PATTERNS OF BURROW SYSTEMS INITIAL DISTRIBUTION :
			// pure random number to produce a sensitivity analysis
			// x = (int)(Math.random()*grid_width);
			// y = (int)(Math.random()*grid_height);
			// reproducible distribution
			x = (int) (C_ContextCreator.randomGeneratorForInitialisation.nextDouble() * grid_width);
			y = (int) (C_ContextCreator.randomGeneratorForInitialisation.nextDouble() * grid_height);
			// put all burrow systems at the middle at init:
			// x = (int) (grid_width / 2);
			// y = (int) (grid_height / 2);
			new_location[0] = x * C_Parameters.CELL_SIZE_UcontinuousSpace; // cell / cs.cell^-1 -> cs;
			new_location[1] = y * C_Parameters.CELL_SIZE_UcontinuousSpace; // cell / cs.cell^-1 -> cs;
			// Provides existence to the agent within the continuous space if not in a highway or lethal area
			if (soilCellsMatrix[x][y].getAffinity() > 0) {
				C_BurrowSystem burrow = new C_BurrowSystem(BURROW_SYSTEM_AFFINITY, x, y);
				contextualizeNewAgentInGrid(burrow, x, y);
			}
			else i--;
		}
	}
	@Override
	/** Fills the context with dynamics agent _within the burrows_ for the first step of a simulation.<br>
	 * Sex ratio is randomly generated */
	public void randomlyAddRodents(int nbAgent) {
		C_RodentFossorial agent;
		ArrayList<C_BurrowSystem> burrowList = new ArrayList<C_BurrowSystem>();
		burrowList.addAll(burrowInspector.getBurrowList());
		Collections.sort(burrowList);
		for (int i = 0; i < nbAgent; i++) {
			int randPosition = (int) (C_ContextCreator.randomGeneratorForInitialisation.nextDouble() * burrowList.size());
			C_BurrowSystem burrow = burrowList.get(randPosition);
			// creates the agents
			agent = (C_RodentFossorial) createRodent();
			// provide a random age to agents at initialization
			long randAge_Uday = Math.round(C_ContextCreator.randomGeneratorForInitialisation.nextDouble() //
					* C_Parameters.FEMALE_SEXUAL_MATURITY_Uday);
			agent.setAge_Uday(randAge_Uday);
			contextualizeNewAgentInCell(agent, burrow);
		}
	}
	@Override
	public C_Rodent createRodent() {
		return new C_RodentFossorial(new C_GenomeAmniota());
	}
	@Override
	public void readUserParameters() {
		super.readUserParameters();
		C_Parameters.INIT_RODENT_POP_SIZE = ((Integer) C_Parameters.parameters.getValue("INIT_POP_SIZE")).intValue();
		C_Parameters.PERSISTANCE_BURROW = ((Boolean) C_Parameters.parameters.getValue("PERSISTANCE_BURROW")).booleanValue();
		C_Parameters.NUMBER_OF_BURROW_SYSTEM = ((Integer) C_Parameters.parameters.getValue("NUMBER_OF_BURROW_SYSTEM")).intValue();
		C_Parameters.RODENT_SPEED_UmeterByTick = ((Integer) C_Parameters.parameters.getValue("AGENT_SPEED_UmeterByDay")).intValue();
		C_Parameters.AGENT_PERCEPTION_RADIUS_UmeterByDay = ((Integer) C_Parameters.parameters.getValue("AGENT_PERCEPTION_RADIUS_UmeterByDay"))
				.intValue();
		C_Parameters.MAX_AGE_Uday = ((Integer) C_Parameters.parameters.getValue("MAX_AGE_Uday")).intValue();
		C_Parameters.REPRO_START_Umonth = ((Integer) C_Parameters.parameters.getValue("REPRO_START_Umonth")).intValue();
		C_Parameters.REPRO_END_Umonth = ((Integer) C_Parameters.parameters.getValue("REPRO_END_Umonth")).intValue();
		C_Parameters.MALE_SEXUAL_MATURITY_Uday = ((Integer) C_Parameters.parameters.getValue("MALE_SEXUAL_MATURITY_Uday")).intValue();
		C_Parameters.FEMALE_SEXUAL_MATURITY_Uday = ((Integer) C_Parameters.parameters.getValue("FEMALE_SEXUAL_MATURITY_Uday")).intValue();
		C_Parameters.FEMALE_BURROW_SYSTEM_CARRYING_CAPACITY_MULTIPLIER = ((Integer) C_Parameters.parameters
				.getValue("FEMALE_BURROW_SYSTEM_CARRYING_CAPACITY_MULTIPLIER")).intValue();
	}
	@Override
	public void initCalendar() {
		Calendar.getInstance();
	}
	/** Close simulation if population is < 2 or if a precondition is verified. <br>
	 * This method may be redefined by daughter protocols */
	public boolean isSimulationEnd() {
	//	if(RepastEssentials.GetTickCount()>1000)return true;
		if (C_Parameters.MAX_POP != 0 && C_InspectorPopulation.rodentList.size() > C_Parameters.MAX_POP) {
			A_Protocol.event("C_ProtocolFossorial.isSimulationEnd(), MaxPop reached; halting simulation", isNotError);
			if (C_Parameters.PERSISTANCE_BURROW) blackMap();
			return true;
		}
		else if (C_InspectorPopulation.getNbFemales() == 0) {
			if (C_Parameters.VERBOSE) java.awt.Toolkit.getDefaultToolkit().beep();
			A_Protocol.event("C_ProtocolFossorial.isSimulationEnd() : population is extinct (no female); halting simulation", isNotError);
			if (C_Parameters.PERSISTANCE_BURROW) blackMap();
			return true;
		}
		return super.isSimulationEnd();
	}
	/** Color the map in black to see the overall distribution of burrows<br>
	 * Author J.Le Fur 10.2014 TODO JLF 10.2014 should be in presentation package ? */
	private void blackMap() {
		for (int i = 0; i < this.landscape.getDimension_Ucell().getWidth(); i++)
			for (int j = 0; j < this.landscape.getDimension_Ucell().getHeight(); j++) {
				if (this.landscape.getValueLayer().get(i, j) == 1) // houses
				this.landscape.getValueLayer().set(2, i, j);
				else if (this.landscape.getValueLayer().get(i, j) != 7) // hedges
				this.landscape.getValueLayer().set(10, i, j);
			}
	}
}
