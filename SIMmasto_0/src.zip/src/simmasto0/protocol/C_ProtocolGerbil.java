package simmasto0.protocol;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.TreeSet;

import presentation.display.C_CustomPanelSet;
import presentation.epiphyte.C_InspectorVegetation;
import repast.simphony.context.Context;
import simmasto0.C_Calendar;
import simmasto0.C_ContextCreator;
import simmasto0.C_LandscapeSahelianSavanna;
import thing.C_BarnOwl;
import thing.C_RodentGerbil;
import thing.C_Vegetation;
import thing.I_SituatedThing;
import thing.dna.C_GenomeAcacia;
import thing.dna.C_GenomeBalanites;
import thing.dna.C_GenomeFabacea;
import thing.dna.C_GenomeGerbillusNigeriae;
import thing.dna.C_GenomePoacea;
import thing.dna.C_GenomeTytoAlba;
import thing.dna.C_XsomePairSexual;
import thing.ground.C_SoilCellSavanna;

import com.vividsolutions.jts.geom.Coordinate;

import data.C_Chronogram;
import data.C_Event;
import data.C_Parameters;
import data.C_ReadRaster;
import data.constants.I_ConstantGerbil;
import data.constants.I_ConstantNumeric;
import data.converters.C_ConvertGeographicCoordinates;
import data.converters.C_ConvertTimeAndSpace;

/** Initialize the simulation and manage inputs coming from the csv events file
 * @author J.Le Fur, 10.2014, rev. M.Sall 12.2015 */
public class C_ProtocolGerbil extends C_ProtocolFossorial implements I_ConstantGerbil, I_ConstantNumeric {
	//
	// FIELDS
	//
	private C_ConvertGeographicCoordinates geographicCoordinateConverter = null;
	protected C_InspectorVegetation vegetationInspector;
	//
	// CONSTRUCTOR
	//
	public C_ProtocolGerbil(Context<Object> ctxt) {
		super(ctxt);
		// Choose value of cell size
		cellSize.set(0, CELL_SIZE);
		vegetationInspector = new C_InspectorVegetation();
		inspectorList.add(vegetationInspector);
		for (int i = 0; i < this.landscape.dimension_Ucell.width; i++) {
			for (int j = 0; j < this.landscape.dimension_Ucell.height; j++) {
				TreeSet<I_SituatedThing> agentList = this.landscape.getGrid()[i][j].getOccupantList();
				for (I_SituatedThing agent : agentList) {
					if (agent instanceof C_Vegetation) vegetationInspector.addVegetationToList((C_Vegetation) agent);
				}
			}
		}
		C_CustomPanelSet.addVegetationInspector(vegetationInspector);
		// Create and build the dataFromChrono from the csv file
		chronogram = new C_Chronogram(I_ConstantGerbil.CHRONO_FILENAME);
	}
	//
	// METHODS
	//
	@Override
	/** Initialize the protocol with the raster origin*/
	public void initProtocol() {
		this.geographicCoordinateConverter = new C_ConvertGeographicCoordinates(new Coordinate(
				I_ConstantGerbil.rasterLongitudeWest_LatitudeSouth_Udegree.get(0), I_ConstantGerbil.rasterLongitudeWest_LatitudeSouth_Udegree.get(1)));
		this.initFixedParameters();
		super.initProtocol();
	}
	@Override
	/** In gerbil protocol, the landscape raster values (i.e., affinity) contain the landcover values*/
	protected void initLandscape(Context<Object> context) {
		this.setLandscape(new C_LandscapeSahelianSavanna(context, C_Parameters.RASTER_URL, VALUE_LAYER_NAME, CONTINUOUS_SPACE_NAME));
		// Comment the following lines to undisplay soil cells, JLF 10.2015, 11.2015
		for (int i = 0; i < this.landscape.dimension_Ucell.width; i++) {
			for (int j = 0; j < this.landscape.dimension_Ucell.height; j++) {
				context.add(this.landscape.getGrid()[i][j]);
				this.landscape.moveToLocation(this.landscape.getGrid()[i][j], this.landscape.getGrid()[i][j].getCoordinate_Ucs());
				this.contextualizeVegetationInSavannaCell((C_SoilCellSavanna) this.landscape.getGrid()[i][j]);
			}
		}
	}
	@Override
	public void initCalendar() {
		protocolCalendar.set(1999, Calendar.JANUARY, 1);
	}
	@Override
	/** Default rodents are of the Gerbillus nigeriae species*/
	public C_RodentGerbil createRodent() {
		return new C_RodentGerbil(new C_GenomeGerbillusNigeriae());
	}
	public C_BarnOwl createBarnOwl() {
		return new C_BarnOwl(new C_GenomeTytoAlba());
	}
	/** Add vegetation in soil cell at the requested position from the value of land cover (i.e., cell affinity) */
	public void contextualizeVegetationInSavannaCell(C_SoilCellSavanna currentSoilCellSavanna) {
		String[] vegetationInLandcover = LANDCOVER_TO_VEGETATION.get(currentSoilCellSavanna.getAffinity());
		List<Coordinate> coordinateList = new ArrayList<Coordinate>();
		if (vegetationInLandcover != null) {
			Coordinate oneCoordinate = null;
			// Randomly add vegetation in soil cell, check that vegetation are not too close
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 2; j++) {
					oneCoordinate = getVegetationCoordinate(DISTANCE_THRESHOLD, coordinateList, currentSoilCellSavanna);
					C_Vegetation oneVegetation = createVegetation(vegetationInLandcover[j]);
					if (oneVegetation != null) {
						contextualizeNewAgentInCell(oneVegetation, currentSoilCellSavanna);
						this.landscape.moveToLocation(oneVegetation, oneCoordinate);
						coordinateList.add(oneCoordinate);
					}
				}
			}
		}
	}
	/** Compute one coordinate, compare its position with the other in the list and if it's correct return the position */
	public Coordinate getVegetationCoordinate(double distanceThresHold, List<Coordinate> coordinateList, C_SoilCellSavanna currentCell) {
		Coordinate oneCoordinate = null;
		while (oneCoordinate == null) {
			oneCoordinate = new Coordinate(currentCell.getLineNo() + C_ContextCreator.randomGeneratorForInitialisation.nextDouble(), currentCell
					.getColNo()
					+ C_ContextCreator.randomGeneratorForInitialisation.nextDouble());
			if (coordinateList.size() != 0) {
				int i = coordinateList.size();
				while ((oneCoordinate != null) && (i > 0)) {
					double vegetationDistance = .0;
					Coordinate secondCoord = coordinateList.get(i - 1);
					vegetationDistance = Math.sqrt(((oneCoordinate.x - secondCoord.x) * (oneCoordinate.x - secondCoord.x))
							+ (oneCoordinate.y - secondCoord.y) * (oneCoordinate.y - secondCoord.y));
					if (vegetationDistance < distanceThresHold) oneCoordinate = null;
					i--;
				}
			}
		}
		return oneCoordinate;
	}
	/** Create vegetation with genome given in args */
	public C_Vegetation createVegetation(String vegetationInLandcover) {
		C_Vegetation oneVegetation = null;
		switch (vegetationInLandcover) {
			case SHRUBS :
				oneVegetation = new C_Vegetation(new C_GenomeBalanites());
				break;
			case CROPS :
				oneVegetation = new C_Vegetation(new C_GenomeFabacea());
				break;
			case GRASSES :
				oneVegetation = new C_Vegetation(new C_GenomePoacea());
				break;
			case TREES :
				oneVegetation = new C_Vegetation(new C_GenomeAcacia());
				break;
		}
		return oneVegetation;
	}
	@Override
	public boolean isSimulationEnd() {
		// TODO MS 02-2017 if this function necessary to be declare
		if ((chronogram != null) && (chronogram.isEndOfChrono)) {
			A_Protocol.event(protocolCalendar.stringShortDate() + ": A_Protocol.isSimulationEnd(), chronogram exhausted; halting simulation",
					isNotError);
			return true;
		}
		return false;
	}
	/** Author MSall 10.2015<br>
	 * @see A_Protocol#manageOneEvent */
	public void manageOneEvent(C_Event event) {
		Coordinate coordinateCell = null;
		if (event.whereX_Ucell == null) {// then: 1) suppose that y is also null, 2) double are values in decimal degrees
			coordinateCell = this.geographicCoordinateConverter.convertCoordinate_Ucs(event.whereX_Udouble, event.whereY_Udouble);
			event.whereX_Ucell = (int) coordinateCell.x;
			event.whereY_Ucell = (int) coordinateCell.y;
		}
		if (coordinateCell == null) coordinateCell = new Coordinate(event.whereX_Ucell, event.whereY_Ucell);
		switch (event.type) {
			case RAIN :// file name example: 199901-PE-Rain.txt or 199901-TPE-Rain.txt
				String url;
				{
					Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
					calendar.setTime(event.when_Ucalendar);
					// Month of simulation begin in 0 why we need to add 1 in the month value and put 0 before the month value between 0 and 8
					if (calendar.get(Calendar.MONTH) < 9) url = RASTER_PATH + rainUrl_suffixRainFile.get(0) + calendar.get(Calendar.YEAR) + "0"
							+ (calendar.get(Calendar.MONTH) + 1) + rainUrl_suffixRainFile.get(1);
					else url = RASTER_PATH + rainUrl_suffixRainFile.get(0) + calendar.get(Calendar.YEAR) + (calendar.get(Calendar.MONTH) + 1)
							+ rainUrl_suffixRainFile.get(1);
					int[][] matriceLue = C_ReadRaster.txtRasterLoader(url);
					int imax = this.landscape.getDimension_Ucell().width;
					int jmax = this.landscape.getDimension_Ucell().height;
					double rainFallLevel = 0.;
					// Change rain value of the cell with the value in the corresponding rain file
					for (int i = 0; i < imax; i++) {
						for (int j = 0; j < jmax; j++) {
							int value = matriceLue[i][j];
							rainFallLevel += value;
							((C_SoilCellSavanna) this.landscape.getGrid()[i][j]).setRainLevel(value);
							((C_LandscapeSahelianSavanna) this.landscape).setRainGridValueLayer(value, i, j);
						}
					}
					vegetationInspector.setRainFallMean(rainFallLevel / (double) (imax * jmax));
				}
				break;
			case OWL_EVENT : {// Randomly add Gerbillus nigeriae found in owl pellets over a distance of between 0 and 2.5 km
				this.addThingWithEvent(event, coordinateCell, OWL_EVENT);
				for (int i = 0; i < Integer.parseInt(event.value2); i++) {
					coordinateCell.x = event.whereX_Udouble
							+ ((-1 + (2 * C_ContextCreator.randomGeneratorForInitialisation.nextDouble())) * averageDistanceHuntingOWL_Umeter)
							/ C_Parameters.UCS_WIDTH_Umeter;
					coordinateCell.y = event.whereY_Udouble
							+ ((-1 + (2 * C_ContextCreator.randomGeneratorForInitialisation.nextDouble())) * averageDistanceHuntingOWL_Umeter)
							/ C_Parameters.UCS_WIDTH_Umeter;
					if (coordinateCell.x < 0) coordinateCell.x = 0.0;
					if (coordinateCell.y < 0) coordinateCell.y = 0.0;
					event.whereX_Ucell = (int) coordinateCell.x;
					event.whereY_Ucell = (int) coordinateCell.y;
					this.addThingWithEvent(event, coordinateCell, GERBIL_EVENT);
				}
			}
				break;
			case GERBIL_EVENT : {
				this.addThingWithEvent(event, coordinateCell, GERBIL_EVENT);
			}
				break;
		}
		super.manageOneEvent(event);
	}
	/** Add rodent or owl with event in the soil cell corresponding to the coordinate give in parameter */
	public void addThingWithEvent(C_Event event, Coordinate coordinate_Ucs, String thing) {
		// Verify that the thing location is within the domain
		if ((coordinate_Ucs.x < width_heightRaster_Ukilometer.get(0)) && (coordinate_Ucs.y < width_heightRaster_Ukilometer.get(1))) {
			C_SoilCellSavanna eventSC = (C_SoilCellSavanna) this.landscape.getGrid()[event.whereX_Ucell][event.whereY_Ucell];
			switch (thing) {
				case GERBIL_EVENT : {
					C_RodentGerbil one_rodent = this.createRodent();
					this.addSexToRodent(one_rodent, event.value1);
					contextualizeNewAgentInCell(one_rodent, eventSC);
					this.landscape.moveToLocation(one_rodent, coordinate_Ucs);
					if (event.value2 != null) one_rodent.setThisName(GERBIL_EVENT + NAMES_SEPARATOR + event.value2);
					// Randomly define age of Gerbil
					int ageOfRodent = (int) (C_ContextCreator.randomGeneratorForInitialisation.nextDouble() * C_Parameters.MAX_AGE_Uday);
					one_rodent.setAge_Uday(ageOfRodent);
				}
					break;
				case OWL_EVENT : {
					C_BarnOwl one_barnOwl = this.createBarnOwl();
					contextualizeNewAgentInCell(one_barnOwl, eventSC);
					this.landscape.moveToLocation(one_barnOwl, coordinate_Ucs);
					one_barnOwl.makeNest();
				}
					break;
			}
		}
	}
	// TODO MS 2016-09 randomly add Gerbil in soil cell
	public void randomlyAddGerbil(Coordinate coordinate_Ucs, String gender) {
		if ((coordinate_Ucs.x < width_heightRaster_Ukilometer.get(0)) && (coordinate_Ucs.y < width_heightRaster_Ukilometer.get(1))) {
			C_SoilCellSavanna soilCell = (C_SoilCellSavanna) this.landscape.getGrid()[Coordinate.X][Coordinate.Y];
			C_RodentGerbil oneRodent = this.createRodent();
			this.addSexToRodent(oneRodent, gender);
			contextualizeNewAgentInCell(oneRodent, soilCell);
			oneRodent.setThisName(GERBIL_EVENT + "-UnknowName");
			int ageOfRodent = (int) (C_ContextCreator.randomGeneratorForInitialisation.nextDouble() * C_Parameters.MAX_AGE_Uday / 4);
			oneRodent.setAge_Uday(ageOfRodent);
		}
	}
	public void addSexToRodent(C_RodentGerbil one_rodent, String sex) {
		if ("MF".contains(sex)) {// determine its gender
			int sexeGene = SEX_GENE_Y;
			boolean isMale = true;
			if (sex.equalsIgnoreCase("F")) {
				sexeGene = SEX_GENE_X;
				isMale = false;
			}
			((C_GenomeGerbillusNigeriae) one_rodent.getGenome()).setGonosome(new C_XsomePairSexual(sexeGene));
			one_rodent.setMale(isMale);
		}
		// else A_Protocol.event("Protocol Gerbil, gerbil event - gender unknown: " + sex, isError);
	}
	@Override
	public void step_Utick() {
		vegetationInspector.dataOutPutBiomass(this.getAveragePrecipitation_Umm());
		super.step_Utick();
	}
	public double getAveragePrecipitation_Umm() {
		double precipitationValue_Umm = .0;
		for (int i = 0; i < this.landscape.dimension_Ucell.width; i++) {
			for (int j = 0; j < this.landscape.dimension_Ucell.height; j++) {
				int value = ((C_SoilCellSavanna) this.landscape.getGrid()[i][j]).getRainLevel();
				switch (value) {
					case 2 :
						precipitationValue_Umm += 10;
						break;
					case 3 :
						precipitationValue_Umm += 25;
						break;
					case 4 :
						precipitationValue_Umm += 60;
						break;
					case 5 :
						precipitationValue_Umm += 115;
						break;
					case 6 :
						precipitationValue_Umm += 175;
						break;
					case 7 :
						precipitationValue_Umm += 235;
						break;
					case 8 :
						precipitationValue_Umm += 270;
						break;
				}
			}
		}
		return precipitationValue_Umm / (this.landscape.dimension_Ucell.getHeight() * this.landscape.dimension_Ucell.getHeight());
	}
	@Override
	public String toString() {
		return "protocolGerbil";
	}
	@Override
	public void readUserParameters() {
		C_Parameters.VERBOSE = ((Boolean) C_Parameters.parameters.getValue("VERBOSE")).booleanValue();
		/** If true, display the affinity map, else display the value layer */
		C_Parameters.DISPLAY_MAP = ((Boolean) C_Parameters.parameters.getValue("DISPLAY_MAP")).booleanValue();
		/** If true cleanly end the simulation */
		C_Parameters.TERMINATE = ((Boolean) C_Parameters.parameters.getValue("TERMINATE")).booleanValue();
		// Check user change of the tick length and reset time stuff if yes /
		// JLF 12.2014
		// NB: C_Parameters.parameters = RunEnvironment.getInstance().getParameters();
		String oldUnit = C_Parameters.TICK_UNIT_Ucalendar;
		double oldAmount = C_Parameters.TICK_LENGTH_Ucalendar;
		C_Parameters.TICK_LENGTH_Ucalendar = ((Integer) C_Parameters.parameters.getValue("TICK_LENGTH_Ucalendar")).intValue();
		C_Parameters.TICK_UNIT_Ucalendar = (String) C_Parameters.parameters.getValue("TICK_UNIT_Ucalendar");
		if ((C_Parameters.TICK_LENGTH_Ucalendar != oldAmount) || (C_Parameters.TICK_UNIT_Ucalendar != oldUnit)) {
			C_ConvertTimeAndSpace.init(C_Parameters.TICK_LENGTH_Ucalendar, C_Parameters.TICK_UNIT_Ucalendar, "M");
			// Calendar has to be reset to account for the new timeSpaceConverter.
			Date savedDate = A_Protocol.protocolCalendar.getTime();
			A_Protocol.protocolCalendar = new C_Calendar();
			A_Protocol.protocolCalendar.setTime(savedDate);
		}
		C_Parameters.RODENT_SPEED_UmeterByTick = ((Integer) C_Parameters.parameters.getValue("AGENT_SPEED_UmeterByDay")).intValue();
		C_Parameters.AGENT_PERCEPTION_RADIUS_UmeterByDay = ((Integer) C_Parameters.parameters.getValue("AGENT_PERCEPTION_RADIUS_UmeterByDay"))
				.intValue();
		C_Parameters.MAX_AGE_Uday = ((Integer) C_Parameters.parameters.getValue("MAX_AGE_Uday")).intValue();
		String[] raster_Parameters = RASTER_PARAMETERS.get(C_Parameters.RASTER_URL.toLowerCase());
		if (raster_Parameters != null) {
			C_Parameters.RASTER_URL = (raster_Parameters[0]);
			rainUrl_suffixRainFile.set(0, raster_Parameters[1]);
			rainUrl_suffixRainFile.set(1, raster_Parameters[2]);
			width_heightRaster_Ukilometer.set(0, Integer.parseInt(raster_Parameters[3]));
			width_heightRaster_Ukilometer.set(1, Integer.parseInt(raster_Parameters[4]));
			rasterLongitudeWest_LatitudeSouth_Udegree.set(0, Double.parseDouble(raster_Parameters[5]));
			rasterLongitudeWest_LatitudeSouth_Udegree.set(1, Double.parseDouble(raster_Parameters[6]));
		}
	}
}