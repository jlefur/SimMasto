package simmasto0.protocol;

import java.awt.Dimension;

import presentation.display.C_CustomPanelSet;
import presentation.display.C_UserPanel;
import presentation.epiphyte.C_InspectorColonialRodents;
import presentation.epiphyte.C_InspectorGenetic;
import presentation.epiphyte.C_InspectorHybrid;
import repast.simphony.context.Context;
import simmasto0.C_ContextCreator;
import thing.C_RodentFossorialColonial;
import thing.dna.C_GenomeEucaryote;
import thing.dna.C_GenomeMastoErythroleucus;
import thing.dna.C_GenomeMastoNatalensis;
import data.C_Parameters;

/** author J.Le Fur, A.Comte 03.2012 / J.Le Fur 07.2012, 02.2013 */

public class C_ProtocolHybridUniform extends A_Protocol {
	//
	// FIELDS
	//
	protected C_InspectorHybrid hybridInspector;
	protected C_InspectorGenetic geneticInspector;
	protected C_InspectorColonialRodents burrowInspector;
	//
	// CONSTRUCTOR
	//
	public C_ProtocolHybridUniform(Context<Object> ctxt) {
		super(ctxt);
		burrowInspector = new C_InspectorColonialRodents();
		geneticInspector = new C_InspectorGenetic();
		hybridInspector = new C_InspectorHybrid();
		inspectorList.add(hybridInspector);
		inspectorList.add(burrowInspector);
		inspectorList.add(geneticInspector);
		// declare the inspector that stores the lethal alleles causes JLF 02.2013
		C_GenomeEucaryote.init(hybridInspector);
		C_CustomPanelSet.addHybridInspector(hybridInspector);
		C_CustomPanelSet.addGeneticInspector(geneticInspector);
		C_CustomPanelSet.addBurrowInspector(burrowInspector);
		C_UserPanel.addBurrowInspector(burrowInspector);
	}
	//
	// METHODS
	//
	/** Fills the context with dynamics agent for the first step of a simulation. The sex ratio is randomly generated */
	public void initProtocol() {
		int nbAgent = C_Parameters.INIT_RODENT_POP_SIZE;
		// TODO JLF 08.2014 code below should replaced with an upper method
		C_RodentFossorialColonial agent;
		double[] newLocation = new double[2];
		Dimension dim = this.landscape.getDimension_Ucell();
		int grid_width = (int) dim.getWidth();
		int grid_height = (int) dim.getHeight();
		for (int i = 0; i < nbAgent; i++) {
			int randx = (int) (C_ContextCreator.randomGeneratorForInitialisation.nextDouble() * grid_width);
			int randy = (int) (C_ContextCreator.randomGeneratorForInitialisation.nextDouble() * grid_height);
			// put all rodents at the middle at init:
			// int randx = (int) (grid_width / 2);
			// int randy = (int) (grid_height / 2);
			newLocation[0] = randx * C_Parameters.CELL_SIZE_UcontinuousSpace; // cell / cs.cell^-1 -> cs;
			newLocation[1] = randy * C_Parameters.CELL_SIZE_UcontinuousSpace; // cell / cs.cell^-1 -> cs;
			// creates the agents
			int agentTaxon = (int) (C_ContextCreator.randomGeneratorForInitialisation.nextDouble() * 2);
			if (agentTaxon == 0) agent = new C_RodentFossorialColonial(new C_GenomeMastoNatalensis());
			else agent = new C_RodentFossorialColonial(new C_GenomeMastoErythroleucus());
			// provides a random age to agents at initialisation
			long randAge_Uday = Math.round(C_ContextCreator.randomGeneratorForInitialisation.nextDouble() //
					* C_Parameters.FEMALE_SEXUAL_MATURITY_Uday);
			agent.setAge_Uday(randAge_Uday);
			contextualizeNewAgentInGrid(agent, randx, randy);
			agent.getNewRandomDisplacement();
		}
		super.initProtocol();
	}
	@Override
	public void step_Utick() {
		geneticInspector.step_Utick();
		hybridInspector.step_Utick();
		burrowInspector.step_Utick();
		super.step_Utick();// has to be after the other inspectors step since it records indicators in file
	}
	@Override
	public void readUserParameters() {
		super.readUserParameters();
		C_Parameters.INIT_RODENT_POP_SIZE = ((Integer) C_Parameters.parameters.getValue("INIT_POP_SIZE")).intValue();
		C_Parameters.EXCLOS = ((Boolean) C_Parameters.parameters.getValue("EXCLOS")).booleanValue();
		/** when true empty burrow systems are not destroyed */
		C_Parameters.PERSISTANCE_BURROW = ((Boolean) C_Parameters.parameters.getValue("PERSISTANCE_BURROW")).booleanValue();
		C_Parameters.NUMBER_OF_BURROW_SYSTEM = ((Integer) C_Parameters.parameters.getValue("NUMBER_OF_BURROW_SYSTEM")).intValue();

		// DYNAMIC AGENTS CONSTANTS //

		C_Parameters.RODENT_SPEED_UmeterByTick = ((Integer) C_Parameters.parameters.getValue("AGENT_SPEED_UmeterByDay")).intValue();
		C_Parameters.AGENT_PERCEPTION_RADIUS_UmeterByDay = ((Integer) C_Parameters.parameters
				.getValue("AGENT_PERCEPTION_RADIUS_UmeterByDay")).intValue();
		/** used only for the computation of the mortality table
		 * @see C_Rodent#getDeathProbabilityMicrotusArvalis_Uday */
		C_Parameters.MAX_AGE_Uday = ((Integer) C_Parameters.parameters.getValue("MAX_AGE_Uday")).intValue();
		// Reproduction attributes common to both sexes //
		C_Parameters.REPRO_START_Umonth = ((Integer) C_Parameters.parameters.getValue("REPRO_START_Umonth")).intValue(); // 91;
		C_Parameters.REPRO_END_Umonth = ((Integer) C_Parameters.parameters.getValue("REPRO_END_Umonth")).intValue();
		/** Reproduction attribute specific to males (Microtus arvalis 60, Rattus rattus 75 day (JMD)) */
		C_Parameters.MALE_SEXUAL_MATURITY_Uday = ((Integer) C_Parameters.parameters.getValue("MALE_SEXUAL_MATURITY_Uday"))
				.intValue();
		/** Reproduction attribute specific to females (Rattus rattus 75 day (JMD); Microtus arvalis 60 (Gauffre) */
		C_Parameters.FEMALE_SEXUAL_MATURITY_Uday = ((Integer) C_Parameters.parameters.getValue("FEMALE_SEXUAL_MATURITY_Uday"))
				.intValue();

		// FIELD AGENTS CONSTANTS

		C_Parameters.FEMALE_BURROW_SYSTEM_CARRYING_CAPACITY_MULTIPLIER = ((Integer) C_Parameters.parameters
				.getValue("FEMALE_BURROW_SYSTEM_CARRYING_CAPACITY_MULTIPLIER")).intValue();
	}
}
