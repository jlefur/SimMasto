package simmasto0.util;

/** @author Mboup 2014 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import presentation.dataOutput.C_FileWriter;
import data.C_ReadWriteFile;
import data.constants.I_ConstantString;

public class C_ChooseProtocol extends JFrame implements ActionListener, I_ConstantString {
	private static final long serialVersionUID = 1L;
	private JPanel container = new JPanel();
	private JComboBox<String> combo = new JComboBox<String>();
	private JLabel label = new JLabel("Choose protocol");

	public static void main(String[] args) {
		new C_ChooseProtocol();
	}
	public C_ChooseProtocol() {
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // imp�ratif cette ligne
		String protocols[] = {"", "CHIZE2","GERBILS", "DODEL", "MUS_TRANSPORT", "DECENAL", "BANDIA", "CENTENAL", "HYBRID_UNIFORM", "ENCLOSURE",
				"CAGES", "CHIZE"};

		// String protocols[] = {
		// "1.-CHIZE:             field vole population in a dynamic agricultural landscape",};"
		// "1.-CHIZE2:            field vole population in a dynamic agricultural landscape + MAP",};"
		// "2.-CAGES:             laboratory experiment on hybridization","
		// "3.-ENCLOSURE:         enclosure experiment on hybridization","
		// "3bis.-HYBRID_UNIFORM: hybridization simulation in an uniform plane","
		// "4.-CENTENAL:          colonization of the black rat in Senegal","
		// "4bis.-DECENAL:		  colonization of the black rat in south-east Senegal","
		// "5.-BANDIA:            CMR simulation in an african reserve","
		// "6.-MUS_TRANSPORT:     colonization of North Senegal by the house mouse","
		// "7.-DODEL:  			  commensal rodent dynamics in urban landscape","
		// "8.-GERBILS:	          Gerbillus nigeriae in North Senegal (CERISE project)","

		this.setTitle("Choose protocol");
		this.setSize(300, 230);
		this.setLocation(560, 250);
		// this.setLocationRelativeTo(null);
		container.setBackground(Color.white);
		container.setLayout(new BorderLayout());
		this.setContentPane(container);
		this.setVisible(true);

		combo = new JComboBox<String>(protocols);
		// combo.setFont(new Font("Courier New", Font.PLAIN, 12));
		combo.setForeground(Color.blue);
		combo.addActionListener(this);
		combo.setMaximumRowCount(24);

		JPanel top = new JPanel();
		top.add(label);
		top.add(combo);
		container.add(top);
		combo.setVisible(true);
		// bouton = new JButton("SELECT");
		// bouton.addActionListener(this);
		// container.add(bouton, BorderLayout.SOUTH);

	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == combo) {
			System.out.println(combo.getSelectedItem() + " Protocol choosed");
			String xmlFileName = "parameters_scenario_" + combo.getSelectedItem() + ".txt";
			splitRepastXmlConfigFiles(xmlFileName);
			System.exit(0);
		}
	}
	/** Build parameters.xml and scenario.xml files from the merged file : parameter_scenario_protocolName.xml file The merged file must be in
	 * SIMmasto_0.rs/, and files built will be in the same folder.
	 * @param xmlFileName */
	public void splitRepastXmlConfigFiles(String xmlFileName) {
		BufferedReader buffer = C_ReadWriteFile.openBufferReader(REPAST_PATH, xmlFileName);
		C_FileWriter writingXmlFile = null;
		String readLine;
		try {
			// Write the next lines in a matrix before going on with the raterFile
			readLine = buffer.readLine();
			while (readLine != null) {
				if (readLine.contains("<?xml") && !readLine.trim().startsWith("<!--")) {
					String fistReadLine = readLine; // on sauvegarde la premi�re ligne
					readLine = buffer.readLine(); // on passe � la deuxi�me pr r�cup�rer le nom
					// R�cup�ration du nom. example: parameters.xml ou scenario.xml d'une ligne comme <!--fileName:parameters.xml-->
					// ou
					// <!--fileName:scenario.xml-->
					String xmlConfigFileName = readLine.replace(" ", "").split(":")[1].split(".xml")[0] + ".xml";
					// Cr�ation du fichier .xml en construction
					writingXmlFile = new C_FileWriter(REPAST_PATH + xmlConfigFileName, false);
					// Ecriture de la premi�re ligne (<?xml version="1.0" encoding="UTF-8" ?>)
					writingXmlFile.writeln(fistReadLine);
				}// Ecriture du reste du fichier
				writingXmlFile.writeln(readLine);
				readLine = buffer.readLine();
			}
		} catch (Exception e) {
			System.err.println("C_CsvChronoReader.buildParametersAndScenarioXmlFiles() : " + "Error of reading or writing xml file " + e.getMessage());
			e.printStackTrace();
		}
		finally {
			try {
				buffer.close();
				writingXmlFile.closeFile();
			} catch (Exception e) {
				System.err.println("C_CsvChronoReader.buildParametersAndScenarioXmlFiles() :" + " buffer or writingXmlFile closing error"
						+ e.getMessage());
			}
		}
	}
}