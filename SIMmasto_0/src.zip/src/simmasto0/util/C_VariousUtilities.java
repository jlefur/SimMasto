package simmasto0.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import repast.simphony.engine.environment.RunState;
import repast.simphony.essentials.RepastEssentials;
import repast.simphony.random.RandomHelper;
import simmasto0.C_ContextCreator;
import thing.dna.C_Chromosome;
import thing.dna.C_ChromosomePair;
import thing.dna.C_Gene;
import thing.dna.I_DiploidGenome;
import thing.dna.I_MappedDna;
import thing.dna.variator.C_GeneConstraint;
import thing.dna.variator.C_GeneMutatorDouble;
import thing.dna.variator.C_GeneMutatorSet;
import thing.dna.variator.C_RecombinatorMapGenome;
import thing.dna.variator.C_RecombinatorOnePt;
import thing.dna.variator.I_Recombinator;
import cern.jet.random.engine.RandomEngine;

public class C_VariousUtilities {
	//
	// CONSTRUCTOR
	//
	public C_VariousUtilities() {}
	/** utility to perform the comparison of decimals values Author J.Le Fur august 2012 */
	public static boolean compareDecimals(double n1, double n2) {
		return truncate(n1) == truncate(n2);
	}
	//
	// METHODS
	//
	/** Display the context on the output (for checking or debugging) */
	public static void printContextFullContent() {
		Object[] list = RunState.getInstance().getMasterContext().toArray();
		System.out.println("=================================");
		System.out.println("A_Protocol, context size/nb agents/current tick: " + list.length + "/" + C_ContextCreator.AGENT_NUMBER
				+ "/" + RepastEssentials.GetTickCount());
		System.out.println("=================================");
		System.out.println("A_Protocol, START OF full context content : ");
		for (int i = 0; i < list.length; i++)
			System.out.println("�l�ment: " + C_VariousUtilities.getShortClassName(list[i].getClass()) + ": " + list[i]);
		System.out.println("A_Protocol, END OF full context content.");
		System.out.println("=================================");
	}
	/** Test of the method used in C_GenomeEucaryote
	 * @see I_DiploidGenome#isHybrid */
	public void TestCompareDecimals(String args[]) {
		double x = 4.29, y = 4.3, z = 5.30, w = 4.31;
		System.out.println(compareDecimals(x, y));
		System.out.println(compareDecimals(x, z));
		System.out.println(compareDecimals(x, w));
		System.out.println(compareDecimals(y, z));
		System.out.println(compareDecimals(y, w));
	}
	/** utility to extract the decimals values Author J.Le Fur august 2012 x is supposed to have a maximum of two decimal digits */
	private static double truncate(double x) {
		long y = (long) (x * 1000.);
		y = y - ((int) x) * 1000;
		return y;
	}

	public void testRegisterGenerator() {
		final int BINARY_RANDOM_SEED = 654879511;
		RandomEngine randomGeneratorForBinarySelector;
		randomGeneratorForBinarySelector = RandomHelper.registerGenerator("binary_seed", BINARY_RANDOM_SEED);
		for (int i = 0; i < 30; i++) {
			System.out.print((int) (randomGeneratorForBinarySelector.nextDouble() * 2));
			System.out.print(" / nextdouble: ");
			System.out.print(randomGeneratorForBinarySelector.nextDouble() * 2);
			System.out.print(" / nextint: ");
			System.out.println(randomGeneratorForBinarySelector.nextInt());
		}
	}
	/** Test the chromosome function (was formerly the main of C_Chromosome) author Kyle Wagner circa 2002, rev. JLF 2012
	 * @see C_Chromosome */
	public void testChromosome(String[] args) {
		System.out.println("Testing chromosome");
		Random randGen = new Random();
		C_Chromosome one_chromosome = new C_Chromosome(4, new C_RecombinatorOnePt());
		// cr�e 4 g�nes avec des valeurs (g�ne <=> all�le) al�atoires aux loci 1 � 4.
		for (int i = 1; i <= 4; i++) {
			double mapLoc = i * 2.5;
			C_Gene dblGene = new C_Gene(new Double(new Random().nextDouble()), mapLoc, new C_GeneMutatorDouble(), one_chromosome
					.getMyId(), new C_GeneConstraint(-10, 10));
			one_chromosome.setGeneAtLocus(i, dblGene);
		}
		System.out.println("chromosome:         " + one_chromosome);
		testMapLocs(one_chromosome);
		one_chromosome.mutate(new Double(0.5));
		System.out.println("mutated chromosome: " + one_chromosome);
		testMapLocs(one_chromosome);
		for (int i = 0; i < 4; i++) {
			System.out.println("getGene(" + i + "): " + one_chromosome.getGene(i));
			System.out.println("  getLocusAllele(" + i + "): " + one_chromosome.getLocusAllele(i));
		}
		// Test randomize();
		one_chromosome.randomize();
		System.out.println("...randomize(): " + one_chromosome);
		testMapLocs(one_chromosome);
		System.out.println("getAlleles(): " + one_chromosome.getAlleles());
		// Replicate w/o mutation
		C_Chromosome gCopy = (C_Chromosome) one_chromosome.replicate(new Double(0));
		System.out.println("original: " + one_chromosome);
		System.out.println("copy:     " + gCopy);
		gCopy.mutate(new Double(1));
		System.out.println("original: " + one_chromosome);
		System.out.println("mut copy: " + gCopy);
		testMapLocs(gCopy);
		// Test out crossover
		I_Recombinator onePt = new C_RecombinatorOnePt();
		System.out.println("\nOne Pt Crossover:");
		testCrossover(onePt, one_chromosome, gCopy);
		I_Recombinator multiPt = new C_RecombinatorOnePt();
		System.out.println("\nMulti Pt Crossover:");
		testCrossover(multiPt, one_chromosome, gCopy);
		I_Recombinator mapXover = new C_RecombinatorMapGenome();
		System.out.println("\nMap Genome Crossover:");
		testCrossover(mapXover, one_chromosome, gCopy);
		System.out.println("\nCrossover and Mating");
		System.out.println("parent1: " + one_chromosome);
		System.out.println("parent2: " + gCopy);
		System.out.println("crossover(): " + one_chromosome.crossover(gCopy));
		C_Chromosome mate = (C_Chromosome) one_chromosome.mate(new Double(0.75), gCopy);
		System.out.println("mate(): " + mate);
		testMapLocs(mate);
		int numGenes = 20;
		double mapLen = numGenes * 2.5;
		List<Integer> intAlleles = new ArrayList<Integer>(10);
		for (int i = 0; i < 10; i++)
			intAlleles.add(new Integer(i));
		C_GeneMutatorSet setGeneMut = new C_GeneMutatorSet(intAlleles);
		C_Chromosome genome3 = new C_Chromosome(mapLen, numGenes, mapXover);
		double mapLoc = 0;
		for (int i = 1; i <= numGenes; i++) {
			mapLoc += randGen.nextDouble() * 2.5;
			C_Gene dblGene = new C_Gene(new Integer((int) randGen.nextDouble() * 10), mapLoc, setGeneMut, one_chromosome.getMyId());
			genome3.setGeneAtLocus(i, dblGene);
		}
		C_Chromosome genome3copy = (C_Chromosome) genome3.replicate(new Double(0));
		genome3copy.mutate(new Double(1));
		System.out.println("genome3:         " + genome3);
		System.out.println("genome3copy:     " + genome3copy);
		testMapLocs(genome3);
		testCrossover(mapXover, genome3, genome3copy);
		// Test copySegment()
		I_MappedDna copiedSegment1 = (I_MappedDna) one_chromosome.copySegment(0, 1);
		I_MappedDna copiedSegment2 = (I_MappedDna) one_chromosome.copySegment(1, 3);
		I_MappedDna copiedSegment3 = (I_MappedDna) one_chromosome.copySegment(3, 4);
		System.out.println("\ncopySegment()");
		System.out.println("genome: " + one_chromosome);
		System.out.println("genome.copySegment(0,1):" + copiedSegment1);
		testMapLocs(copiedSegment1);
		System.out.println("genome.copySegment(1,3):" + copiedSegment2);
		testMapLocs(copiedSegment2);
		System.out.println("genome.copySegment(3,4):" + copiedSegment3);
		testMapLocs(copiedSegment3);
	}
	private static void testMapLocs(I_MappedDna genome) {
		double mapLoc = 5.0;
		System.out.println("genome.getMapLength():         " + genome.getMapLength());
		for (int i = 0; i < genome.getNumLoci(); i++) {
			C_Gene gene = ((C_Chromosome) genome).getGene(i);
			System.out.print("  getGene(" + i + "): " + gene);
			System.out.println("  mapLoc: " + gene.getMapLoc());
			System.out.println("  mapLoc(" + mapLoc + ") allele: " + genome.getLocusAllele(mapLoc));
		}
	}
	private static void testCrossover(I_Recombinator r, C_Chromosome parent1, C_Chromosome parent2) {
		System.out.println("parent1:   " + parent1);
		System.out.println("parent2:   " + parent2);
		C_ChromosomePair child = (C_ChromosomePair) r.crossover(parent1, parent2);
		System.out.println("offspring: " + child);
		testMapLocs(child);

		System.out.println("\nMutating child (100%), parents shouldn't change:");
		child.mutate(new Double(1));
		System.out.println("parent1:   " + parent1);
		System.out.println("parent2:   " + parent2);
		System.out.println("offspring: " + child);
	}

	/** return classes names with or without packages Author http://www.rgagnon.com/javadetails/java-0389.html, ver. 09.2011 */
	public void testClassNames() {
		System.out.println(getShortClassName(java.awt.Frame.class));
		System.out.println(getFullClassName(java.awt.Frame.class));
		System.out.println(getPackageName(java.awt.Frame.class));
		System.out.println("----");
		System.out.println(getShortClassName(C_VariousUtilities.class));
		System.out.println(getFullClassName(C_VariousUtilities.class));
		System.out.println(getPackageName(C_VariousUtilities.class));
		System.out.println("----");
		java.util.Calendar cal = java.util.Calendar.getInstance();
		System.out.println(getShortClassName(cal.getClass()));
		System.out.println(getFullClassName(cal.getClass()));
		System.out.println(getPackageName(cal.getClass()));
	}
	/** returns the class (without the package if any) */
	public static String getShortClassName(Class<?> c) {
		String FQClassName = c.getName();
		int firstChar;
		firstChar = FQClassName.lastIndexOf('.') + 1;
		if (firstChar > 0) {
			FQClassName = FQClassName.substring(firstChar);
		}
		return FQClassName;
	}

	/** returns package and class name */
	public String getFullClassName(Class<?> c) {
		return c.getName();
	}

	/** returns the package without the classname, empty string if there is no package */
	public String getPackageName(Class<?> c) {
		String fullyQualifiedName = c.getName();
		int lastDot = fullyQualifiedName.lastIndexOf('.');
		if (lastDot == -1) { return ""; }
		return fullyQualifiedName.substring(0, lastDot);
	}
}
