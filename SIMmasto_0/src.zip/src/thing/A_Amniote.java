/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt */
package thing;// test

import simmasto0.protocol.A_Protocol;
import thing.dna.C_GenomeAmniota;
import thing.dna.C_GenomeEucaryote;
import thing.dna.I_DiploidGenome;
import data.C_Parameters;
import data.converters.C_ConvertTimeAndSpace;

public abstract class A_Amniote extends A_Animal {
	//
	// FIELDS
	//
	/** Reproductive status */
	protected boolean sexualMature = false; // i.e., is this gonade able to make gamete
	protected boolean readyToMate; // agent physiologic ability to mate
	protected double curMatingLatency;// TODO JLF 2016.05 ! Unused
	protected double curGestationLength_Uday = -1; // TODO JLF 2015.08 number in source OK
	protected double matingLatency;// TODO JLF 2016.05 ! Unused
	protected int numMatings;
	public boolean preMature = false;
	//
	// CONSTRUCTOR
	//
	public A_Amniote(I_DiploidGenome genome) {
		super(genome);
		readyToMate = false;
		if (isFemale()) femaleInit();
	}
	//
	// METHODS
	//
	/** Mammals' activity within one tick (inherit animal's activity also) - rev JLF 03/07.2014 */
	/** All methods must be called at each step */
	@Override
	public void step_Utick() {
		updatePhysiologicStatus();
		super.step_Utick();
	}

	protected void femaleInit() {
		numMatings = 0;
		curGestationLength_Uday = -1.; // TODO number in source OK JLF 08.2015 gestation length = -1
	}

	/** Manage sexual immaturity, gestation. NB: account for tick length rev.Le Fur 08.2015, 11.2015 */
	protected void updatePhysiologicStatus() {
		double oneTick_Uday = 1. / C_ConvertTimeAndSpace.oneDay_Utick;
		if (isSexualMature()) {
			readyToMate = true;
			if (isPregnant()) {
				curGestationLength_Uday -= oneTick_Uday;
				if (curGestationLength_Uday <= 0.) this.actionSpawn();
				readyToMate = false;
			}
		}
		else if (getAge_Uday() >= ((C_GenomeAmniota) this.genome).getWeaningAge_Uday()) {
			preMature = true;
			this.trappedOnBoard = false;// Can now deliberate and move JLF 01.2017
			if (getAge_Uday() >= getAgeOfMaturity_Uday()) {
				sexualMature = true;
				preMature = false;
				hasToSwitchFace = true;
			}
		}
	}

	/** Only female proceed to mate. This may be triggered by the male the femaleFertilisation method accounts for copulation it
	 * produces eggs (litter size) with the new genome (Eucaryotes: 2 gonosomes and microsatXsome)
	 * @see C_Rodent#actionInteract(C_Rodent)
	 * @param male the father with wich to mate */
	public void actionMateWithMale(I_ReproducingThing male) {
		I_DiploidGenome eggGenome;
		C_GenomeAmniota maleParentGenome = (C_GenomeAmniota) ((A_Animal) male).getGenome();
		C_GenomeAmniota thisFemaleParentGenome = ((C_GenomeAmniota) this.genome);
		this.curGestationLength_Uday = thisFemaleParentGenome.getGestationLength_Uday();
		this.curMatingLatency = thisFemaleParentGenome.getMatingLatency_Uday();
		this.readyToMate = false;
		this.hasToSwitchFace = true;
		// generate LITTER_SIZE zygotes (fusion, cross-over (& mutation)) from the mother and father
		int litterSize = thisFemaleParentGenome.getLitterSizeValue();
		for (int i = 0; i < litterSize; i++) {
			eggGenome = this.genome.mate(0, maleParentGenome);
			// if one of the microsatelite of the genome of the egg contains the Lethal_Allele (for a reason or an other). The egg
			// is killed. Then, the size of the litter will be smaller.
			if (((C_GenomeEucaryote) eggGenome).getMicrosatXsome().getAlleles().contains(C_GenomeEucaryote.LETHAL_ALLELE)) {
				if (C_Parameters.VERBOSE) A_Protocol.event("A_Mammal.mateWithMale(): EGG NIPPED IN THE BUD :'(", isNotError);
			}
			else eggList.add(new C_Egg(eggGenome));
		}
		if (C_Parameters.VERBOSE) A_Protocol.event("mate at "+this.currentSoilCell, isNotError);
	}

	/** Create eggs number of children; use giveBirth() for each egg's genome. Rev. Pape 2015 */
	protected void actionSpawn() {
		if (!isFemale()) A_Protocol.event("A_Mammal.spawn():" + this + "is not a female", isError);
		for (C_Egg egg : this.eggList) {
			A_Animal child = actionGiveBirth(egg.genome);
			child.trappedOnBoard = this.trappedOnBoard;
			if (C_Parameters.VERBOSE && child.trappedOnBoard) {
				A_Protocol.event(child + ", is born in a container: " + this.getCurrentSoilCell(), isNotError);
			}
			myLandscape.addChildAgent(this, child);
			child.getNewRandomDisplacement();
		}
		if (C_Parameters.VERBOSE) System.out.println("_"+this.eggList.size() + "o_");
		eggList.clear();
		curMatingLatency = ((C_GenomeAmniota) this.genome).getMatingLatency_Uday();
		this.hasToSwitchFace = true;
	}
	//
	// GETTERS
	//
	public boolean isSexualMature() {
		return sexualMature;
	}
	/** used to color the icon when pregnant */
	public boolean isPregnant() {
		return (eggList.size() != 0);
	}
	public Boolean getReadyToMate() {
		return readyToMate;
	}
	/** @return the age of maturity tick corresponding to male or female */

	private int getAgeOfMaturity_Uday() {// TODO JLF 2015.11 put in genomes'alleles
		if (isMale()) return C_Parameters.MALE_SEXUAL_MATURITY_Uday;
		else return C_Parameters.FEMALE_SEXUAL_MATURITY_Uday;
	}
}