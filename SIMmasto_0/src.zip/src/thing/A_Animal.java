/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt */
package thing;

import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeSet;

import presentation.display.C_Background;
import simmasto0.C_ContextCreator;
import simmasto0.protocol.A_Protocol;
import thing.dna.C_GenomeEucaryote;
import thing.dna.I_DiploidGenome;
import thing.ground.A_SupportedContainer;
import thing.ground.C_LandPlot;
import thing.ground.C_SoilCell;
import thing.ground.I_Container;

import com.vividsolutions.jts.geom.Coordinate;

import data.C_Parameters;

/** This class accounts for animals as moving agents.
 * @author Q.Baduel, J-E Longueville, J. Le Fur 2011-02, 2013.01, 04.2015 */
public abstract class A_Animal extends A_Organism {
	//
	// FIELDS
	//
	/** Simple data structure to hold zygote information during matingLatency */
	protected TreeSet<C_Egg> eggList = new TreeSet<C_Egg>();
	public boolean trappedOnBoard = false;
	protected double speed_UmeterByTick;
	protected Coordinate nextMove_Umeter = new Coordinate();
	protected Coordinate targetPoint_Umeter = null;
	protected String targetName = "";// For display purposes - JLF 02.2017
	protected boolean hasToDisperse = false;// used to avoid return to containers left for fullness
	protected A_VisibleAgent target = null; // store the container selected as a destination
	private double maxDispersalDistance_Umeter = 0.0;
	protected I_Container lastContainerLeft; // Used to compute dispersal
	protected boolean male; // shortcut to avoid fetching each time into gonosomes and so on (see constructor)
	//
	// CONSTRUCTOR
	//
	public A_Animal(I_DiploidGenome genome) {
		super(genome);
		this.speed_UmeterByTick = C_Parameters.RODENT_SPEED_UmeterByTick;
		this.male = ((C_GenomeEucaryote) genome).getGonosome().isMale();
	}
	//
	// METHODS
	//
	/** Remove references to last container left, targeted container and eggs */
	@Override
	public void discardThis() {
		this.lastContainerLeft = null;
		this.setTarget(null);
		this.eggList.clear();
		super.discardThis();
	}

	/** Realize actions, then compute indicator and super */
	@Override
	public void step_Utick() {
		if (!this.trappedOnBoard) {// if trapped, do nothing - JLF 07.2013
			this.testDanger();
			// Second general case : decision then action (movetoDestination)
			if (this.hasToDisperse) this.actionDisperse();
			if (this.target == null) {
				// PDE (perception, deliberation, decision, action) - action select and move towards a direction - dedicated to be sophisticated in
				// daughter classes JLF 06.2014 */
				if (selectDestination(deliberation(perception())) == null) {
					getNewRandomDisplacement();
				}
			}
			this.actionMoveToDestination();
			computeMaxDispersalDistance_Umeter();
			super.step_Utick();
		}
	}

	/** if not dead and with a dangerous area, test death. Can be overridden by daughter classes JLF&MS 01.2017 */
	protected void testDanger() {
		// If arrived in wrong place, get back two steps
		if (this.currentSoilCell.getAffinity() <= DANGEROUS_AREA_AFFINITY) {
			this.nextMove_Umeter.x = -2. * this.nextMove_Umeter.x;// TODO JLF 2016.01 number in source get back two steps
			this.nextMove_Umeter.y = -2. * this.nextMove_Umeter.y;// TODO JLF 2016.01 number in source get back two steps
			this.targetPoint_Umeter = null;
		}
		if ((this.currentSoilCell.getAffinity() <= DANGEROUS_AREA_AFFINITY) && (!this.isDead())) this.testDeath(DANGEROUS_AREA_MORTALITY_RATE);
	}

	/** Method redefined in daughters classes. The A_VisibleAgent interacts with an Object
	 * @param animal any daughter class of A_Animal / JLF 02.2014
	 * @return true if success */
	protected boolean actionInteract(A_Animal animal) {
		A_Protocol.event("A_VisibleAgent.interact(): " + animal + " do nothing", isError);
		return false;
	}
	public void actionDisperse() {
		this.targetPoint_Umeter = null;;
		if ((nextMove_Umeter.x == 0) && (nextMove_Umeter.y == 0)) this.getNewRandomDisplacement();
		actionMoveToDestination();
		actionMoveToDestination();// Accentuate dispersal JLF 12.2016
		actionMoveToDestination();// Accentuate dispersal JLF 12.2016
		actionMoveToDestination();// Accentuate dispersal JLF 12.2016
		actionMoveToDestination();// Accentuate dispersal JLF 12.2016
		this.hasToDisperse = false;
	}

	/** Second stage of the scheme perception, deliberation action of Ferber 1999 :<br>
	 * makes animals systematically interact with others and returns the available soil cells.
	 * @param perceivedThings TreeSet <I_situated_thing> listeVisibleObjects from perception method
	 * @return candidate targets Version J.E.Longueville & J.Le Fur 2011 / jlefur 03.2012 */
	protected TreeSet<I_SituatedThing> deliberation(TreeSet<I_SituatedThing> perceivedThings) {
		TreeSet<I_SituatedThing> candidateTargets = new TreeSet<I_SituatedThing>();

		C_SoilCell currentDest = null, testedCell = null;
		for (I_SituatedThing oneThingPerceived : perceivedThings) {
			// if animal encountered, systematically interact - subclasses override interact procedure
			if (oneThingPerceived instanceof A_Animal && oneThingPerceived != this) {
				if (this.actionInteract((A_Animal) oneThingPerceived)) break;
			}
			// Select soil cells with best affinities
			else if (oneThingPerceived instanceof C_SoilCell) {
				testedCell = (C_SoilCell) oneThingPerceived;
				if (testedCell.getAffinity() > this.getCurrentSoilCell().getAffinity()) {
					if (currentDest == null || testedCell.getAffinity() > currentDest.getAffinity()) {
						candidateTargets.clear();
						candidateTargets.add(testedCell);
						currentDest = testedCell;
					}
					else if (testedCell.getAffinity() == currentDest.getAffinity()) candidateTargets.add(testedCell);
				}
			}
			else if (oneThingPerceived instanceof C_LandPlot) {} // Currently no interaction with landplots
			else if (oneThingPerceived instanceof C_Background) {} // Background has to be managed as an object
			else if (oneThingPerceived instanceof C_Vegetation) {} // Currently no interaction with vegetation
			else if (oneThingPerceived != this)
				A_Protocol.event("A_Animal.deliberation(): neither an Animal/SoilCell/LandPlot/Vegetation/Background" + oneThingPerceived.getClass(),
						isError);
		}
		if (lastContainerLeft != null) candidateTargets.remove(lastContainerLeft);// Do not reenter the container just left
		return candidateTargets;
	}
	/** Compute next move to target, test if is arrived, move on the GUI */
	protected void actionMoveToDestination() {
		this.computeNextMoveToTarget();
		this.isArrived();
		if (!trappedOnBoard) myLandscape.translate(this, nextMove_Umeter); // Move agent on the graphics presentation
	}
	/** Random selection of the field agent target from the candidate cells set (all visible fields agent)
	 * @param TreeSet<I_SituatedThing> candidates */
	// TODO JLF 2015.09 could more largely apply to containers (would be great) or NDS !
	protected I_SituatedThing selectDestination(TreeSet<I_SituatedThing> candidates) {
		I_SituatedThing selectedDestination = null;
		if (!candidates.isEmpty()) {
			ArrayList<A_VisibleAgent> candidateList = new ArrayList<A_VisibleAgent>();
			for (I_SituatedThing visibleAgent : candidates)
				candidateList.add((A_VisibleAgent) visibleAgent);
			Collections.sort(candidateList);
			int nthCell = (int) (C_ContextCreator.randomGeneratorForDestination.nextDouble() * candidates.size());
			selectedDestination = candidateList.get(nthCell);
			this.setTarget((A_VisibleAgent) selectedDestination);
			return selectedDestination;
		}
		else getNewRandomDisplacement();
		return null;
	}

	/** Dismiss targetPoint and provide two random coordinates in meters. This redefines the nextMove_Umeter field. */
	public void getNewRandomDisplacement() {
		this.targetPoint_Umeter = null;// Pas besoin d'objectif on r�cup une trajectoire al�atoire.
		nextMove_Umeter.x = (C_ContextCreator.randomGeneratorForMovement.nextDouble() * speed_UmeterByTick)
				- (C_ContextCreator.randomGeneratorForMovement.nextDouble() * speed_UmeterByTick);
		nextMove_Umeter.y = (C_ContextCreator.randomGeneratorForMovement.nextDouble() * speed_UmeterByTick)
				- (C_ContextCreator.randomGeneratorForMovement.nextDouble() * speed_UmeterByTick);
	}

	/** A simple function which provide agents with an aim to move toward specific coordinates. We watch if the agent is (or isn't) near its goal, we
	 * have to do several tests because if the agent is near in the x variable but not in the y, the next step it may be too far on the x abscissa and
	 * near to the y abscissa, we have to make sure that the agent won't go on a perpetual move. author QBaduel */
	protected void computeNextMoveToTarget() {
		if (targetPoint_Umeter != null) computeNextMoveToTarget(this.speed_UmeterByTick);
	}
	/** The same function as computeNext_move but with a given speed Le d�placement est suivant un vecteur de coordonn�es (vectCoordX, vectCoordY) ie
	 * targetPoint_Umeter - currentPoint_Umeter (sens), de longeur vectNorm = racine(vectCoordX�, vectCoordY�) (norme) et faisant un angle alpha par
	 * rapport � l'abscisse (direction) si vectCoordX == 0, alpha = +PI/2 ou -PI/2 �a d�pend du signe de vectCoordY sinon alpha =
	 * atan(vectCoordY/vectCoordX) Ainsi nous avons la direction et le sens du d�placement. Et donc � partir de la distance � parcourir, on peut
	 * calculer exactement nextMove_Umeter.x et nextMove_Umeter.y
	 * @param agentSpeed_UmeterByTick is the max distance of the agent or agent's vehicle to go over (speed_Umeter). if speed_Umeter surpass the
	 *            targetPoint than the distance to goal is just the distance between currentPoint_Umeter and targetPoint_Umeter.
	 * @see #computeNextMoveToTarget()
	 * @author LeFur 08.2012 rev. Mboup 10.2014 */
	protected void computeNextMoveToTarget(double agentSpeed_UmeterByTick) {
		if (agentSpeed_UmeterByTick > 0 && (targetPoint_Umeter != null) && !trappedOnBoard) {
			// vecteur de d�placement
			double alpha, signeX;
			double distanceToTargetX = targetPoint_Umeter.x - getCoordinate_Umeters().x;
			double distanceToTargetY = targetPoint_Umeter.y - getCoordinate_Umeters().y;
			double distanceToTarget = Math.sqrt(distanceToTargetX * distanceToTargetX + distanceToTargetY * distanceToTargetY);
			if (distanceToTargetX == 0) {
				signeX = 1.0; // positif
				alpha = Math.signum(distanceToTargetY) * Math.PI / 2;
			}
			else {
				signeX = Math.signum(distanceToTargetX);
				alpha = Math.atan(distanceToTargetY / distanceToTargetX);
			}
			if (distanceToTarget < agentSpeed_UmeterByTick) { // pour que l'agent ne d�passe pas sa destination
				agentSpeed_UmeterByTick = distanceToTarget;
			}
			nextMove_Umeter.x = signeX * agentSpeed_UmeterByTick * Math.cos(alpha);
			nextMove_Umeter.y = signeX * agentSpeed_UmeterByTick * Math.sin(alpha);
		}
	}
	/** Maximum distance (straight line) from its birth location */
	public void computeMaxDispersalDistance_Umeter() {
		double currentDispersalDistance_Umeters = getCurrentDispersalDistance_Umeter();
		if (currentDispersalDistance_Umeters > maxDispersalDistance_Umeter) maxDispersalDistance_Umeter = currentDispersalDistance_Umeters;
	}
	@Override
	public String toString() {
		String sex = "+F:";
		if (isMale()) sex = "-M:";
		return (sex + genome + NAMES_SEPARATOR + myId);
	}
	//
	// GETTERS AND SETTERS
	//
	protected boolean isArrived() {
		return isArrived(this.speed_UmeterByTick);
	}
	/** The same function as isArrived but with a given speed
	 * @see #isArrived()
	 * @param speed the speed of the agent or agent's vehicle
	 * @author author: LeFur 08.2012 */
	protected boolean isArrived(double speed) {
		Coordinate currentCoord_Umeter = this.getCoordinate_Umeters();
		if (targetPoint_Umeter != null) {
			// Verification if the agent is arrived
			boolean reach_x = false;
			boolean reach_y = false;
			if (Math.abs(currentCoord_Umeter.x - targetPoint_Umeter.x) <= speed) {
				reach_x = true;
				this.nextMove_Umeter.x = 0;
			}
			if (Math.abs(currentCoord_Umeter.y - targetPoint_Umeter.y) <= speed) {
				reach_y = true;
				this.nextMove_Umeter.y = 0;
			}
			// if its travel is achieved, it looses its goal
			if (reach_x && reach_y) {
				this.targetPoint_Umeter = null;
				return true;
			}
			return false;
		}
		else return true;
	}
	/** Maximum distance (straight line) from its birth location */
	protected double getCurrentDispersalDistance_Umeter() {
		Coordinate current = myLandscape.getThingCoord_Umeter(this);
		// We use * and not Math.pow to improve computing time
		return Math.sqrt((current.x - this.bornCoord_Umeter.x) * (current.x - this.bornCoord_Umeter.x) + (current.y - this.bornCoord_Umeter.y)
				* (current.y - this.bornCoord_Umeter.y));

	}
	/** Tag the container selected as a destination
	 * @author JEL 2011, rev.jlf 09.2015, 04.2017 */
	public void setTarget(A_VisibleAgent selectedDestination) {
		if (this.target != null) this.target.animalsTargetingMe.remove(this);
		this.target = selectedDestination;
		if (selectedDestination != null) {
			this.targetPoint_Umeter = selectedDestination.getCoordinate_Umeters();
			this.target.addAnimalTargetingMe(this);
		}
		else this.targetPoint_Umeter = null;
	}
	/** Tag animal last container when it leaves
	 * @see A_SupportedContainer#agentLeaving */
	public void setLastContainerLeft(I_Container lastContainerLeft) {
		this.lastContainerLeft = lastContainerLeft;
	}
	public boolean isHasToDisperse() {
		return this.hasToDisperse;
	}
	public void setHasToDisperse(boolean dispersal) {
		this.hasToDisperse = dispersal;
		this.hasToSwitchFace = true;
	}
	/** For display purposes - JLF 02.2017 */
	public String getTargetName() {
		if (this.target != null) return this.target.name;
		else return "none";
	}
	public double getMaxDispersalDistance_Umeter() {// used to display on GUI
		return maxDispersalDistance_Umeter;
	}
	public boolean isTrappedOnBoard() {
		return trappedOnBoard;
	}
	public boolean isMale() {
		return this.male;
	}
	public boolean isFemale() {
		return !this.male;
	}
}
