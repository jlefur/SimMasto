/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt */
package thing;

import thing.dna.C_GenomeEucaryote;
import thing.dna.I_DiploidGenome;

/** This class accounts for animals with a genome
 * @see C_GenomeEucaryote
 * @author J. Le Fur 2016-03 */
public abstract class A_Organism extends A_VisibleAgent implements I_ReproducingThing{
	//
	// FIELD
	//
	protected I_DiploidGenome genome;
	//
	// CONSTRUCTORS
	//
	public A_Organism(I_DiploidGenome genome) {
		this.genome = genome;
	}
	//
	// METHODS
	//
	/** Remove references to genome */
	@Override
	public void discardThis() {
		this.genome = null;
		super.discardThis();
	}
	@Override
	public String toString() {
		return (genome + NAMES_SEPARATOR + myId);
	}
	//
	// GETTER
	//
	public I_DiploidGenome getGenome() {
		return genome;
	}
}
