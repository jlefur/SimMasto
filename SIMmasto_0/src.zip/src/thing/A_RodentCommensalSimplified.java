package thing;

import java.util.Calendar;
import java.util.TreeSet;

import simmasto0.protocol.A_Protocol;
import thing.dna.I_DiploidGenome;
import thing.ground.C_SoilCellGraphed;

/** Simplified rodent for transportation protocol: do not move outside this city, perceive only this current cell content
 * @author J.Le Fur 04.2015 */
public abstract class A_RodentCommensalSimplified extends C_RodentCommensal {

	public A_RodentCommensalSimplified(I_DiploidGenome genome) {
		super(genome);
	}
	/** Remove rodent if it is not trapped and it has left city / JLF 10.215 */
	@Override
	public void step_Utick() {
		if (this.trappedOnBoard || ((C_SoilCellGraphed) currentSoilCell).getGroundTypes().contains(CITY)) super.step_Utick();
		else this.dead = true;
	}
	/** Cities affinity are not significant for this / JLF 01.2017 */
	@Override
	protected void testDanger() {};
	@Override
	/**For centenal simulation : cell affinity account for bioclimate, from favourable (12) to unfavourable (2) 
	 * -> this provide the length of the breeding season for Rattus: if current month < affinity*3 readyToMate=false<br>
	 * JLeFur, 10.2016*/
	protected void updatePhysiologicStatus() {
		super.updatePhysiologicStatus();
		if (this.isSexualMature() && !this.isPregnant()) if (this.getCurrentSoilCell().getAffinity() * 3 >= A_Protocol.protocolCalendar
				.get(Calendar.MONTH)) // TODO number in source JLF 2016.10 affinity >=4 -> reproduction all year
		this.readyToMate = true;
		else this.readyToMate = false;
	}
	/** Do not perform exact perception radius computation: only perceive this current cell objects */
	@Override
	protected TreeSet<I_SituatedThing> perception() {
		return this.currentSoilCell.getOccupantList();
	}
	/** For display purpose only, JLF 01.2017 */
	public String getCellName() {
		if (this.currentSoilCell != null) return this.currentSoilCell.toString();
		else return "None";
	}
}
