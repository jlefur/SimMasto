/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt */
package thing;

import java.util.TreeSet;

import simmasto0.C_Landscape;
import simmasto0.protocol.A_Protocol;
import simmasto0.util.C_PathWanderer;
import thing.ground.I_Container;

import com.vividsolutions.jts.geom.Coordinate;

import data.C_Parameters;

/** Class similar to A_VisibleThing but extending the A_NDS class
 * @author jlefur 2010, rev 12.2013 */
public abstract class A_VisibleAgent extends A_NDS implements I_SituatedThing {
	//
	// FIELDS
	//
	public boolean hasToSwitchFace = false;
	protected static C_Landscape myLandscape = null;
	protected I_Container currentSoilCell;
	public boolean agentJustLeftDomain = false; // if the agent reaches an edge, it leaves the simulation
	public boolean agentJustEnteredDomain = false; // a new agent comes at an edge from outside the exclos
	public Coordinate bornCoord_Umeter;
	protected int sensing_Umeter;
	protected double energy_Ukcal;
	protected TreeSet<A_Animal> animalsTargetingMe = new TreeSet<A_Animal>();

	/** Used for animals within network landscapes @see C_LandscapeNetwork */
	public C_PathWanderer pathWanderer;
	//
	// CONSTRUCTOR
	//
	public A_VisibleAgent() {
		sensing_Umeter = C_Parameters.AGENT_PERCEPTION_RADIUS_UmeterByDay;
	}
	//
	// METHODS
	//
	/** @param m : the ground manager which will look after the Agent action (if the field is concerned) */
	public static void init(C_Landscape m) {
		myLandscape = m;// first, we give the agent a reference to the ground_manager it can use
	}
	/** Remove references to pathwanderer and leave all containers */
	@Override
	public void discardThis() {
		this.pathWanderer = null;
		while (this.getCurrentSoilCell() != null) {
			if (!this.getCurrentSoilCell().agentLeaving(this)) // leave the supporting soil cell.
			A_Protocol.event("A_VisibleAgent:discardThis: " + this + " cannot leave " + this.getCurrentSoilCell(), isError);
		}
		super.discardThis();
	}
	/** First stage of the scheme perception, deliberation, action of Jacques Ferber
	 * <p>
	 * Ferber, J., 1995. Les syst�mes multi-agents: vers une intelligence collective, InterEditions Paris.</Br> Available at:
	 * http://www.citeulike.org/user/Bc91/article/1464256 [Accessed February 28, 2011].
	 * </p>
	 * Can be used as an indicator of interaction
	 * @return TreeSet<I_situated_thing> listeVisibleObject Authors J.E. Longueville 2011 - J.Le Fur 03.2012 */
	protected TreeSet<I_SituatedThing> perception() {
		return myLandscape.findObjectsOncontinuousSpace(this, (double) sensing_Umeter);
	}
	/** Test if the perceived surrounding is full JLF 12.2016 */
	protected boolean isSurroundingFull() {
		return this.currentSoilCell.isFull();
/*		C_LandPlot currentPlot = ((C_SoilCell) this.currentSoilCell).affinityLandPlot;
		int nrodents = 0, k = 0;
		for (I_Container percept : this.cellPerception()) {
			k += percept.getCarryingCapacity_Urodent();
			nrodents += percept.getLoad_Urodent();
		}
		if (nrodents > k) return true;
		else if (currentPlot != null && currentPlot.isFull()) return true;
		else return false;*/
	}
	//
	// SETTER AND GETTERS
	//
	public void addAnimalTargetingMe(A_Animal agent) {
		animalsTargetingMe.add(agent);
	}
	public void removeAnimalTargetingMe(A_Animal agent) {
		if (animalsTargetingMe.remove(agent)) {}
		else A_Protocol.event("C_SupportedContainer.removeAnimalTargetingMe(), " + agent + " was not referenced in " + this, isError);
	}
	public TreeSet<A_Animal> getAnimalsTargetingMe() {
		return animalsTargetingMe;
	}
	public void setCurrentSoilCell(I_Container currentSoilCell) {
		this.currentSoilCell = currentSoilCell;
	}
	public Coordinate getCoordinate_Umeters() {
		return myLandscape.getThingCoord_Umeter(this);
	}
	public Coordinate getCoordinate_Ucs() {
		return myLandscape.getThingCoord_Ucs(this);
	}
	public I_Container getCurrentSoilCell() {
		return currentSoilCell;
	}
	public int getSensing_Umeter() {
		return sensing_Umeter;
	}
}