package thing;

import java.util.Calendar;
import java.util.TimeZone;
import java.util.TreeSet;

import simmasto0.C_ContextCreator;
import simmasto0.protocol.A_Protocol;
import thing.dna.I_DiploidGenome;
import thing.ground.C_BurrowSystem;
import thing.ground.C_Nest;
import thing.ground.I_Container;
import data.constants.I_ConstantGerbil;
import data.converters.C_ConvertTimeAndSpace;

public class C_BarnOwl extends A_Amniote implements I_ConstantGerbil {
	//
	// FIELD
	//
	protected C_Nest myNest;
	//
	// CONSTRUCTOR
	//
	public C_BarnOwl(I_DiploidGenome genome) {
		super(genome);
		this.speed_UmeterByTick = C_ConvertTimeAndSpace.convertSpeed_UspaceByTick(averageDistanceHuntingOWL_Umeter, "m", "d");
		this.sensing_Umeter = (int) this.speed_UmeterByTick;
		energy_Ukcal = initialBarnOwlVitalEnergy_Ukcal;
	}
	//
	// METHODS
	//
	@Override
	protected TreeSet<I_SituatedThing> perception() {
		TreeSet<I_SituatedThing> perceptList = super.perception();
		TreeSet<I_SituatedThing> barnOwlPerceptList = new TreeSet<I_SituatedThing>();
		if (!perceptList.isEmpty()) {
			for (I_SituatedThing oneThing : perceptList) {
				if (((oneThing instanceof C_Rodent) && !(oneThing.getCurrentSoilCell() instanceof C_BurrowSystem)) || (oneThing instanceof C_Nest)) barnOwlPerceptList
						.add(oneThing);
			}
		}
		return barnOwlPerceptList;
	}
	/** Get list of perceived things, create list of rodent gerbil and call interact function
	 * @return empty list of soilcell
	 * @param perceivedThings Authors MS 10.2016 */
	@Override
	public TreeSet<I_SituatedThing> deliberation(TreeSet<I_SituatedThing> perceivedThings) {
		if (!isActive()) {
			if (this.currentSoilCell != myNest) {
				TreeSet<I_SituatedThing> newPercevingList = new TreeSet<I_SituatedThing>();
				newPercevingList.add(myNest);
				return newPercevingList;
			}
		}
		else {
			if (isHungry()) return this.choosePrey(perceivedThings);
		}
		return super.deliberation(perceivedThings);
	}
	/** Choose the prey if barn owl need to eat and return rodent list perceived */
	public TreeSet<I_SituatedThing> choosePrey(TreeSet<I_SituatedThing> percevingRodent) {
		TreeSet<I_SituatedThing> rodentList = new TreeSet<I_SituatedThing>();
		for (I_SituatedThing oneThing : percevingRodent) {
			if (oneThing instanceof C_Rodent) rodentList.add(oneThing);
		}
		return rodentList;
	}
	@Override
	public void step_Utick() {
		//TODO MS 03.2017 change the target if barn owl need to eat
		if(isActive() && (this.target == myNest) && isHungry()){
			this.setTarget(null);
		}
		super.step_Utick();
	}
	@Override
	protected boolean actionInteract(A_Animal gerbilList) {
		if (this.isHungry()) {
			this.actionMoveToDestination();
			// gerbilList.setDead(true);
			this.energy_Ukcal += eatRodentGainedEnergy_UKcal;
			return true;
		}
		else return false;
	}
	/** Create the origin nest of barn owl and contextualize it */
	public void makeNest() {
		I_Container curentSoilCell = this.getCurrentSoilCell();
		myNest = new C_Nest(curentSoilCell.getAffinity(), currentSoilCell.getColNo(), curentSoilCell.getLineNo());
		C_ContextCreator.protocol.contextualizeNewAgentInCell(myNest, curentSoilCell);
		C_ContextCreator.protocol.contextualizeOldAgentInCell(this, myNest);
	}
	/** metabolism consumption, Le Fur & Sall 01.2017 */
	@Override
	protected void updatePhysiologicStatus() {
		super.updatePhysiologicStatus();
		this.energy_Ukcal -= thermoregulationBarnOwl_UkcalPerHour;
	}
	/** Compute next move to target, test if is arrived, move on the GUI */
	@Override
	protected void actionMoveToDestination() {
		super.actionMoveToDestination();
		this.energy_Ukcal -= huntRodentsConsumptionEnergy_Ukcal;// TODO MS 2017.01 temporaire
	}
	@Override
	public A_Animal actionGiveBirth(I_DiploidGenome genome) {
		C_BarnOwl oneBarnOwl = new C_BarnOwl(genome);
		return oneBarnOwl;
	}
	/** Action to put barn owl in this nest */
	public void actionPutInNest(C_Nest oneNest) {
		C_ContextCreator.protocol.contextualizeOldAgentInCell(this, oneNest);// Put barn owl in nest
		myLandscape.moveToLocation(this, myLandscape.getThingCoord_Ucs(oneNest));// Place barn owl at the nest position
	}
	//
	// SETTER & GETTER
	//
	/** Return true when the agent can do his action like eat, chase, etc... */
	public boolean isActive() {
		Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
		calendar.setTime(A_Protocol.protocolCalendar.getTime());
		int currentTime = calendar.get(Calendar.HOUR_OF_DAY);
		if (!((currentTime < hourRelease_Uhour) && (currentTime > bedTime_Uhour))) return true;
		return false;
	}
	/** Check if barn owl need to eat */
	public boolean isHungry() {
		return (energy_Ukcal <= initialBarnOwlVitalEnergy_Ukcal - eatRodentGainedEnergy_UKcal);
	}
}
