package thing;
import thing.dna.I_DiploidGenome;
/** a simple structure containing a diploid genome, gets all the properties of NDS
 * @author J.LeFur 2011 */
public class C_Egg extends A_NDS {
	protected I_DiploidGenome genome;
	public C_Egg(I_DiploidGenome zygoteGenome) {
		genome = zygoteGenome;
	}
	/** Remove reference to genome */
	@Override
	public void discardThis() {
		this.genome = null;
		super.discardThis();
	}
	public I_DiploidGenome getGenome() {
		return genome;
	}
}