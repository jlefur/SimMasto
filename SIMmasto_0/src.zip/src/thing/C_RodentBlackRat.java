package thing;

import thing.dna.I_DiploidGenome;

/** JLF 01.2017 */
public class C_RodentBlackRat extends A_RodentCommensalSimplified {

	public C_RodentBlackRat(I_DiploidGenome genome) {
		super(genome);
	}
	/** generate a new animal, necessary to use spawn
	 * @see A_Amniote#spawn */
	@Override
	public A_Animal actionGiveBirth(I_DiploidGenome genome) {
		return new C_RodentBlackRat(genome);
	}
	/** Black rats do not board in taxis JLF 01.2017 */
	protected boolean actionTryBoardingVehicle(C_HumanCarrier carrier) {
		if (carrier instanceof C_TaxiMan) return false;
		else return super.actionTryBoardingVehicle(carrier);
	}
}
