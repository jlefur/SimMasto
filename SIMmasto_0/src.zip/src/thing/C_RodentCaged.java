package thing;

import java.util.TreeSet;
import thing.dna.C_GenomeAmniota;
import thing.dna.C_GenomeEucaryote;
import thing.dna.C_GenomeMastoErythroleucus;
import thing.dna.C_GenomeMastoNatalensis;
import thing.dna.C_GenomeMastomys;
import thing.dna.I_DiploidGenome;
import thing.ground.C_LandPlot;
import thing.ground.C_SoilCell;
import data.C_Parameters;

/** Standard rodents only living in cage
 * @author JLF, 03.2012 */
public class C_RodentCaged extends C_Rodent {
	//
	// FIELDS
	//
	public String generation = "F0";
	private C_LandPlot birthCage; // used to identify inbreeding rodents.
	private C_LandPlot currentCage;
	private int currentLine;
	//
	// CONSTRUCTOR
	//
	public C_RodentCaged(I_DiploidGenome genome) {
		super(genome);
		this.speed_UmeterByTick = C_Parameters.RODENT_SPEED_UmeterByTick/10.;// TODO number in source OK JLF (speed reducer for rodent caged)
	}
	//
	// METHODS
	//
	/** Remove references to cages */
	@Override
	public void discardThis() {
		this.birthCage = null;
		this.currentCage = null;
		super.discardThis();
	}
	/** generate a new animal, necessary to use spawn
	 * @see A_Amniote#spawn */
	@Override
	public A_Animal actionGiveBirth(I_DiploidGenome genome) {
		return new C_RodentCaged(genome);
	}
	/** Special procedure for MBour experiment Author jlefur
	 * @return void
	 * @param perceivedThings */
	@Override
	protected TreeSet<I_SituatedThing> deliberation(TreeSet<I_SituatedThing> perceivedThings) {
		TreeSet<I_SituatedThing> visibleSoilCells = new TreeSet<I_SituatedThing>();
		for (Object oneObject : perceivedThings) {
			if (oneObject instanceof C_SoilCell) visibleSoilCells.add((C_SoilCell) oneObject);
			else if ((oneObject instanceof C_RodentCaged) && !(oneObject.equals(this))) this.actionInteract((C_RodentCaged) oneObject);
		}
		return visibleSoilCells;
	}
	/** Special procedure for MBour experiment: remove all cells that do not belong to the cage. Author jlefur
	 * @return accointances: perceived things */
	@Override
	protected TreeSet<I_SituatedThing> perception() {
		return this.currentCage.getFullOccupantList();
	}
	/** Extend the rodent procedure to produce proper RodentCaged */
	protected void actionSpawn() {
		for (C_Egg egg : this.eggList) {
			C_RodentCaged rodentChild;
			if (genome instanceof C_GenomeMastoNatalensis) rodentChild = new C_RodentCaged(new C_GenomeMastoNatalensis());
			if (genome instanceof C_GenomeMastoErythroleucus) rodentChild = new C_RodentCaged(new C_GenomeMastoErythroleucus());
			else {
				rodentChild = new C_RodentCaged(new C_GenomeMastomys());
			}
			// Replace the genome of the newly created rodent with the egg genome :-)
			rodentChild.genome = egg.genome;
			// necessary to ensure the shortcut of sex determination (@see A_Animal constructors)
			rodentChild.male = ((C_GenomeEucaryote) rodentChild.genome).getGonosome().isMale();
			myLandscape.addChildAgent(this, rodentChild);
			rodentChild.birthCage = this.currentCage;
			rodentChild.currentCage = this.currentCage;
			rodentChild.currentLine = this.currentLine;
			rodentChild.getNewRandomDisplacement();
			if (C_Parameters.VERBOSE) System.out.println("o");
		}
		eggList.clear();
		curMatingLatency = ((C_GenomeAmniota) this.genome).getMatingLatency_Uday();
	}
	//
	// SETTERS & GETTERS
	//
	public void setBirthCage(C_LandPlot birthLandPlot) {
		this.birthCage = birthLandPlot;
	}
	public void setCurrentCage(C_LandPlot currentCage) {
		this.currentCage = currentCage;
	}
	public void setCurrentLine(int currentLine) {
		this.currentLine = currentLine;
	}
	@Override
	protected double getDeathProbability_Uday() {
		return 0.;
	}
	public C_LandPlot getBirthCage() {
		return birthCage;
	}
	public C_LandPlot getCurrentCage() {
		return currentCage;
	}
	public int getCurrentLine() {
		return currentLine;
	}
}
