package thing;

import java.util.TreeSet;

import simmasto0.C_ContextCreator;
import thing.dna.I_DiploidGenome;
import thing.ground.C_Vehicle;
import data.constants.I_ConstantTransportation;

/** Define rodent agents that are used to live with humans (e.g., random move if no destination, try boarding in vehicles)<br>
 * created for protocolCentenal
 * @author Jean Le Fur, oct.2014 */
public class C_RodentCommensal extends C_Rodent implements I_ConstantTransportation {
	//
	// FIELD
	//
	public boolean everTransported;
	//
	// CONSTRUCTOR
	//
	public C_RodentCommensal(I_DiploidGenome genome) {
		super(genome);
		everTransported = false;
	}
	//
	// METHODS
	//
	/** generate a new animal, necessary to use spawn
	 * @see A_Amniote#spawn */
	@Override
	public A_Animal actionGiveBirth(I_DiploidGenome genome) {
		return new C_RodentCommensal(genome);
	}
	public boolean isEverTransported() {
		return everTransported;
	}
	/** Interact with another rodent. systematically mates if both partner reproductive status are ok. <br>
	 * @see C_Rodent#mateWithMale <br>
	 *      Here, no breeding season test: commensal rodent do not have a reproduction season, they mate all year long */
	@Override
	protected boolean actionInteract(C_Rodent rodent) {
		if (this.genome.getClass().equals(rodent.genome.getClass()) && (this.readyToMate && rodent.readyToMate && recognized(rodent))) {
			if (this.isFemale() && rodent.isMale()) {
				this.actionMateWithMale(rodent);
				return true;
			}
			else if (this.isMale() && rodent.isFemale()) {
				rodent.actionMateWithMale(this);
				return true;
			}
		}
		return false;// TODO JLF 2017.01 place for future agonistic behaviours
	}

	/** Tentatively board into the carrier's vehicle / JLF feb.2014 */
	@Override
	protected boolean actionInteract(C_HumanCarrier carrier) {
		return actionTryBoardingVehicle(carrier);
	}
	/** Rat boarding is computed following the loading probability of the carrier's vehicle Mboup 2013 Version rev. JLF 02.2014, 10.2015 */
	protected boolean actionTryBoardingVehicle(C_HumanCarrier carrier) {
		// JLF everTransported below accounts for possible previous successful boarding
		if (carrier.isParked() && !trappedOnBoard && !this.everTransported) {
			C_Vehicle vehicle = carrier.getVehicle();
			// TODO number in source OK (%) JLF 2015
			double x = C_ContextCreator.randomGeneratorForBoarding.nextDouble() * 100;
			if (!vehicle.isFull() && x < vehicle.getLoadingProba()) {
				C_ContextCreator.protocol.contextualizeOldAgentInCell(this, vehicle);
				return (this.trappedOnBoard = true);
			}
		}
		return (this.trappedOnBoard = false);
	}
	/** If within a city and no destination is found, have a new random move Version JLF 10.2014 */
	@Override
	protected I_SituatedThing selectDestination(TreeSet<I_SituatedThing> candidateCells) {
		/*
		 * //comment 10.2016 JLF if (currentSoilCell.getAffinity() != EVENT_AFFINITY_CODES.get(CITY)) { candidateCells.remove(this.currentSoilCell);
		 * if (candidateCells.size() > 0) return super.selectDestination(candidateCells); }
		 */
		getNewRandomDisplacement();
		return null;
	}
}
