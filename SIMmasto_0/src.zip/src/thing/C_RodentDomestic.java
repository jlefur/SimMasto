package thing;

import java.util.Calendar;
import java.util.TreeSet;

import simmasto0.protocol.A_Protocol;
import thing.dna.I_DiploidGenome;
import data.constants.I_ConstantDodel;

/** Define rodent agents that are used to live within cities buildings (e.g., suspend activity during daytime)<br>
 * created for protocol Dodel
 * @author Jean Le Fur, march 2015 */
public class C_RodentDomestic extends C_RodentCommensal {
	//
	// FIELD
	//
	double speed_Origin;
	//
	// CONSTRUCTOR
	//
	public C_RodentDomestic(I_DiploidGenome genome) {
		super(genome);
		speed_Origin = speed_UmeterByTick;
	}
	//
	// METHODS
	//
	/** generate a new animal, necessary to use spawn
	 * @see A_Amniote#spawn */
	@Override
	public A_Animal actionGiveBirth(I_DiploidGenome genome) {
		return new C_RodentDomestic(genome);
	}
	/** Do not test death as domestic rodent may often be within a dangerous area JLF&MS 01.2017 */
	protected void testDanger() {}

	/** Transform Perception according time / author: M.Diakhate, rev. J.Le Fur 11.2016 */
	@Override
	protected TreeSet<I_SituatedThing> perception() {
		double sensing = sensing_Umeter;
		int hourOfDay = A_Protocol.protocolCalendar.get(Calendar.HOUR_OF_DAY);
		// Low perception during daylight (hidden)
		if ((hourOfDay >= I_ConstantDodel.DAY_START_Uhour) && (hourOfDay <= I_ConstantDodel.DAY_END_Uhour)) {
			sensing = (double) sensing_Umeter / I_ConstantDodel.RODENT_DECREASE_PERCEPTION;
		}
		// greater perception of rodent at dawn and twilight
		else if ((I_ConstantDodel.TWILIGHT_START_Uhour <= hourOfDay && hourOfDay <= I_ConstantDodel.TWILIGHT_END_Uhour)
				|| (I_ConstantDodel.DAWN_START_Uhour <= hourOfDay && hourOfDay <= I_ConstantDodel.DAWN_END_Uhour)) {
			sensing = (double) sensing_Umeter * I_ConstantDodel.RODENT_INCREASE_PERCEPTION;
		}
		// System.err.println("heure= "+hourOfDay +" perception= "+ sensing);
		return myLandscape.findObjectsOncontinuousSpace(this, sensing);
	}
	/** Transform Speed according time / author: M.Diakhate, rev. J.Le Fur 11.2016 */
	@Override
	protected void computeNextMoveToTarget() {
		speed_UmeterByTick = speed_Origin;
		int hourOfDay = A_Protocol.protocolCalendar.get(Calendar.HOUR_OF_DAY);
		// No activities between 9 and 18h
		if (I_ConstantDodel.DAY_START_Uhour <= hourOfDay && hourOfDay <= I_ConstantDodel.DAY_END_Uhour) {
			speed_UmeterByTick = speed_Origin / I_ConstantDodel.SPEED_SMALL_ACTIVITIES;
		}
		// More activities of rodent between these moments
		else if ((I_ConstantDodel.TWILIGHT_START_Uhour <= hourOfDay && hourOfDay <= I_ConstantDodel.TWILIGHT_END_Uhour)
				|| (I_ConstantDodel.DAWN_START_Uhour <= hourOfDay && hourOfDay <= I_ConstantDodel.DAWN_END_Uhour)) {
			speed_UmeterByTick = speed_Origin * I_ConstantDodel.SPEED_SMALL_ACTIVITIES;
		}
		super.computeNextMoveToTarget(speed_UmeterByTick);
	}

}
