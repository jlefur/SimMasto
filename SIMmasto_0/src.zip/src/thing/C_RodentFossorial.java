/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt */
package thing;

import java.util.TreeSet;

import simmasto0.C_ContextCreator;
import thing.dna.I_DiploidGenome;
import thing.ground.C_BurrowSystem;
import thing.ground.I_Container;
import data.C_Parameters;

public class C_RodentFossorial extends C_Rodent {
	//
	// CONSTRUCTOR
	//
	public C_RodentFossorial(I_DiploidGenome genome) {
		super(genome);
	}
	//
	// METHODS
	//
	/** generate a new animal, necessary to use spawn
	 * @see A_Amniote#spawn */
	@Override
	public A_Animal actionGiveBirth(I_DiploidGenome genome) {
		return new C_RodentFossorial(genome);
	}
	/** Spawns if within a burrow, else dig a burrow and spawns , rev. JLF 01.2017 */
	@Override
	protected void actionSpawn() {
		this.setHasToDisperse(false);// for children care
		if (!(this.getCurrentSoilCell() instanceof C_BurrowSystem)) { // if within a burrow do not dig
			// Choose burrow not full and stop
			// for (I_SituatedThing onePerceivedThing : this.perception())
			// if ((onePerceivedThing instanceof C_BurrowSystem) && !(((C_BurrowSystem) onePerceivedThing).isFull())) {
			// C_ContextCreator.protocol.contextualizeOldAgentInCell(this, (I_Container) onePerceivedThing);
			// break;
			// }
		}
		// dig a burrow TODO JLF 2014.08 could be also search first for a burrow.
		if (!(this.getCurrentSoilCell() instanceof C_BurrowSystem)) actionDig();
		super.actionSpawn(); // use giveBirth() for each egg's genome.
	}

	@Override
	/** Verify that the individual is arrived at destination. If it is a burrow system suck up the agent and reset the target
	 * @revision JLF 06.2014 */
	protected void computeNextMoveToTarget() {
		super.computeNextMoveToTarget();
		if (target != null && isArrived()) {
			// Sucked up by the burrowSystem Target, when arrived at proximity.
			C_ContextCreator.protocol.contextualizeOldAgentInCell(this, (I_Container) target);
			this.setTarget(null);
		}
	}
	/** The agent quit its current burrow system and enter in support soil cell of burrow. The movingAgent get a newRandom displacement and moves. */
	public void actionRandomExitOfBurrow() {// TODO JLF 2015.07 transform into randomExitOfContainer trucks, burrows, traps,...)
		C_ContextCreator.protocol.contextualizeOldAgentInCell(this, this.currentSoilCell.getCurrentSoilCell());
		this.getNewRandomDisplacement();
		this.actionMoveToDestination();
	}
	/** If within a burrow system, return the agent within the burrow, else super<br>
	 * Version Authors J.E. Longueville 2011 - J.Le Fur 03.2012,04.2015,01.2016
	 * @see A_VisibleAgent#perception
	 * @return TreeSet<I_situated_thing> listeVisibleObject */
	@Override
	protected TreeSet<I_SituatedThing> perception() {
		// if within a burrow only retrieve the burrow's occupants
		if (this.currentSoilCell instanceof C_BurrowSystem) return this.currentSoilCell.getOccupantList();//
		else return super.perception();
	}
	/** Dig a burrow (at the same coordinates), then enter within it Version Author JE Longueville 2011, rev. jlf 08.2015, 12.2015
	 * @see C_RodentFossorial#spawn */
	public void actionDig() {
		C_BurrowSystem newBurrow = new C_BurrowSystem(BURROW_SYSTEM_AFFINITY, currentSoilCell.getLineNo(), currentSoilCell.getColNo());
		C_ContextCreator.protocol.contextualizeNewAgentInCell(newBurrow, currentSoilCell);// Put burrow in digger's current soilCell
		myLandscape.moveToLocation(newBurrow, myLandscape.getThingCoord_Ucs(this));// Place burrow at the rodent position
		this.actionEnterBurrow(newBurrow);
		if (C_Parameters.VERBOSE) System.out.println("@");
	}
	public void actionEnterBurrow(C_BurrowSystem oneburrow) {
		C_ContextCreator.protocol.contextualizeOldAgentInCell(this, oneburrow);// Put rodent in burrow
		myLandscape.moveToLocation(this, myLandscape.getThingCoord_Ucs(oneburrow));// Place rodent at the burrow position
	}
	@Override
	protected void femaleInit() {
		super.femaleInit();
		// TODO JLF 2016.11 why females only ?
		if (getCurrentSoilCell() instanceof C_BurrowSystem) this.setHasToDisperse(((C_BurrowSystem) getCurrentSoilCell()).isFull());
	}
	//
	// SETTER
	//
	@Override
	public void testDeath(double deathProbability) {
		if (C_ContextCreator.randomGeneratorForDeathProb.nextDouble() <= deathProbability) {
			if (this.target != null) this.target.removeAnimalTargetingMe(this);
			this.dead = true;
		}
	}
}
