package thing;

import java.util.TreeSet;

import simmasto0.protocol.A_Protocol;
import thing.dna.I_DiploidGenome;
import thing.ground.C_BurrowSystem;
import thing.ground.C_LandPlot;
import thing.ground.C_SoilCell;
import thing.ground.I_Container;

public class C_RodentFossorialColonial extends C_RodentFossorial {

	public C_RodentFossorialColonial(I_DiploidGenome genome) {
		super(genome);
	}
	/** generate a new animal, necessary to use spawn
	 * @see A_Amniote#spawn */
	@Override
	public A_Animal actionGiveBirth(I_DiploidGenome genome) {
		return new C_RodentFossorialColonial(genome);
	}
	/** Uses A_Animal deliberation (super). If breeding season, the burrow list replaces the soil cells list
	 * @return list of candidate soilCells
	 * @param perceivedThings Authors JE. Longueville 2011 / drastically simplified jlefur 03.2012 */
	@Override
	protected TreeSet<I_SituatedThing> deliberation(TreeSet<I_SituatedThing> perceivedThings) {
		TreeSet<I_SituatedThing> superDeliberation = super.deliberation(perceivedThings);
		// Disperse if land plot is full / rev. JLF 01.2017
		C_LandPlot currentLandplot = ((C_SoilCell) this.getCurrentSoilCell()).getAffinityLandPlot();
		if (currentLandplot != null && currentLandplot.isFull()) {
			for (I_Container x : currentLandplot.getCells())
				perceivedThings.remove(x);
			this.setHasToDisperse(true);
		}
		if (A_Protocol.isBreedingSeason()) {
			TreeSet<I_SituatedThing> candidateBurrows = new TreeSet<I_SituatedThing>();
			for (I_SituatedThing oneThingPerceived : perceivedThings) {
				if (oneThingPerceived instanceof C_BurrowSystem) {
					candidateBurrows.add((C_BurrowSystem) oneThingPerceived);
					superDeliberation.remove(oneThingPerceived);
				}
				else if (oneThingPerceived instanceof I_Container) if (((I_Container) oneThingPerceived).getAffinity() == DANGEROUS_AREA_AFFINITY) superDeliberation
						.remove(oneThingPerceived);
			}
			if (!candidateBurrows.isEmpty()) return candidateBurrows;
		}
		return superDeliberation;
	}
	/** Manage activity when rodent is within a burrow system, mature...<br>
	 * Adapted from JEL 2010, JLF 03,06.2014 full rev. from svn507, JLF 07.2014, 12.2016, 01.2017 */
	@Override
	public void step_Utick() {
		// if weaning, just grow
		if (!(this.preMature || this.sexualMature)) {
			this.actionGrowOlder_Utick();
			this.testDeath(this.getDeathProbability_Utick());
			this.updatePhysiologicStatus();
		}
		else {
			// disperse if needed
			if ((preMature && isMale()) || hasToDisperse || this.isSurroundingFull()) {
				if (this.getCurrentSoilCell() instanceof C_BurrowSystem) actionRandomExitOfBurrow();
				actionDisperse();
			}
			// sexually mature within breeding season
			if (this.sexualMature && this.isMale() && A_Protocol.isBreedingSeason() && (this.getCurrentSoilCell() instanceof C_BurrowSystem)) {
				// inside burrow
				for (C_Rodent accointance : this.getCurrentSoilCell().getRodentList())
					this.actionInteract(accointance);
				actionRandomExitOfBurrow();
			}
			super.step_Utick();
		}
	}
	@Override
	/** Interact(mate) with another rodent if and only if within a burrow system.
	 * @see C_Rodent#interact JLF 02.2014, 12,2016*/
	protected boolean actionInteract(C_Rodent rodent) {
		if (this.getCurrentSoilCell() instanceof C_BurrowSystem) return super.actionInteract(rodent);
		 else if (!this.isSurroundingFull()) return super.actionInteract(rodent);
		return false;
	}
}
