package thing;

import java.util.Calendar;
//import java.util.TimeZone;
import java.util.TreeSet;

import simmasto0.protocol.A_Protocol;
import thing.dna.C_GenomeFabacea;
import thing.dna.C_GenomePoacea;
import thing.dna.I_DiploidGenome;
import thing.ground.C_BurrowSystem;
import thing.ground.C_SoilCell;
import data.constants.I_ConstantGerbil;
import data.converters.C_ConvertTimeAndSpace;

/** Case study on Gerbillus nigeriae: gerbils choose food, partners or shelter depending on their energetic state and their perceived environment.
 * @author Moussa Sall, 2015, rev. 2016, JLF 04.2017 */
public class C_RodentGerbil extends C_RodentFossorial implements I_ConstantGerbil {
	//
	// CONSTRUCTOR
	//
	public C_RodentGerbil(I_DiploidGenome genome) {
		super(genome);
		energy_Ukcal = initialGerbilVitalEnergy_Ukcal;
		this.speed_UmeterByTick = C_ConvertTimeAndSpace.convertSpeed_UspaceByTick((int) this.speed_UmeterByTick, "m", "d");
		// this.sensing_Umeter = (int) this.speed_UmeterByTick;
	}
	//
	// METHODS
	//
	/** Add vegetation in the whole cell to perceived list / M.Sall 10.2015
	 * @see A_VisibleAgent#perception
	 * @return TreeSet<I_situated_thing> Perceived things including vegetation objects */
	@Override
	protected TreeSet<I_SituatedThing> perception() {
		TreeSet<I_SituatedThing> perceivedThings = super.perception();
		TreeSet<I_SituatedThing> cellOccupants = this.currentSoilCell.getOccupantList();
		for (I_SituatedThing agent : cellOccupants)
			if (agent instanceof C_Vegetation) perceivedThings.add(agent);
		return perceivedThings;
	}
	/** Uses A_Animal deliberation (super) / Author MS 2016.
	 * @return list of candidate soilCells
	 * @param Perceived things */
	@Override
	protected TreeSet<I_SituatedThing> deliberation(TreeSet<I_SituatedThing> perceivedThings) {
		// Search for shelter if night ends
		if (A_Protocol.protocolCalendar.isDawn()) {// Put gerbil in existing burrow system or dig burrow and get inside
			TreeSet<I_SituatedThing> shelter = this.chooseShelter(perceivedThings);
			if (shelter.isEmpty() && !(this.currentSoilCell instanceof C_BurrowSystem)) {// rodents go on the burrow
				C_BurrowSystem newBurrow = (C_BurrowSystem) C_BurrowSystem.createAndPutBurrowInContainer(this.currentSoilCell);
				myLandscape.moveToLocation(newBurrow, myLandscape.getThingCoord_Ucs(this));// Place burrow at the rodent position
				shelter.add(newBurrow);
			}
			return shelter;
		}
		else {
			for (I_SituatedThing onePerceivedThing : perceivedThings) {
				if ((onePerceivedThing instanceof C_BarnOwl) && !(this.getCurrentSoilCell() instanceof C_BurrowSystem))
					return this.chooseShelter(perceivedThings);
			}
			if (this.isLowEnergy()) return this.chooseFood(perceivedThings);
			else {
				if (A_Protocol.isBreedingSeason() && this.isSexualMature()) return this.choosePartner(perceivedThings);
				if (this.needToEat()) return this.chooseFood(perceivedThings);
			}
		}
		return super.deliberation(perceivedThings);
	}
	/** Use list perceived things and choose the candidate shelter who can be one burrow, a vegetation list or nothing */
	public TreeSet<I_SituatedThing> chooseShelter(TreeSet<I_SituatedThing> perceivedThings) {
		TreeSet<I_SituatedThing> thingShelter = new TreeSet<I_SituatedThing>();
		for (I_SituatedThing onePerceivedThing : perceivedThings) {
			if ((onePerceivedThing instanceof C_BurrowSystem) && !((C_BurrowSystem) onePerceivedThing).isFull()) {// Choose burrow and stop
				thingShelter.clear();
				thingShelter.add(onePerceivedThing);
				break;
			}
			else if ((onePerceivedThing instanceof C_Vegetation) && ((C_Vegetation) onePerceivedThing).getVegetationType().equals(SHRUBS)
					&& canInteractWith((C_Vegetation) onePerceivedThing)) {
				thingShelter.add(onePerceivedThing);
			}
		}
		return thingShelter;
	}
	/** Use list perceived things and choose grass or crop */
	public TreeSet<I_SituatedThing> chooseFood(TreeSet<I_SituatedThing> perceivedThings) {
		TreeSet<I_SituatedThing> vegetationSelected = new TreeSet<I_SituatedThing>();
		for (I_SituatedThing onePerceivedThing : perceivedThings) {
			if ((onePerceivedThing instanceof C_Vegetation) && ((((C_Vegetation) onePerceivedThing).getGenome() instanceof C_GenomePoacea)
					|| (((C_Vegetation) onePerceivedThing).getGenome() instanceof C_GenomeFabacea)) && canInteractWith(
							(C_Vegetation) onePerceivedThing)) {
				vegetationSelected.add(onePerceivedThing);
				break;
			}
		}
		return vegetationSelected;
	}
	/** Use list perceived thing to choose the potential partner to interact and return the list */
	protected TreeSet<I_SituatedThing> choosePartner(TreeSet<I_SituatedThing> perceivedThings) {
		TreeSet<I_SituatedThing> rodentCandidate = new TreeSet<I_SituatedThing>();
		for (I_SituatedThing onePerceivedThing : perceivedThings) {
			if (onePerceivedThing instanceof C_RodentGerbil) {// add potential partner in the interact list
				rodentCandidate.add(onePerceivedThing);
			}
		}
		return rodentCandidate;
	}
	/** Check distance between this and the vegetation and return true if he can interact with her */
	public boolean canInteractWith(C_Vegetation one_vegetation) {
		double distanceGerbilToVegetation_Umeter = this.getCurrentSoilCell().getCoordinate_Umeters().distance(one_vegetation.getCoordinate_Umeters());
		if ((vegetationCoverageRadius_Umeter + this.sensing_Umeter) > distanceGerbilToVegetation_Umeter) {
			if (distanceGerbilToVegetation_Umeter > vegetationCoverageRadius_Umeter) {// Move on the radius of vegetation cover
				double distanceToBrowse_Umeter = distanceGerbilToVegetation_Umeter - vegetationCoverageRadius_Umeter;
				nextMove_Umeter.x = (Math.abs(distanceGerbilToVegetation_Umeter - distanceToBrowse_Umeter) / distanceGerbilToVegetation_Umeter)
						* one_vegetation.getCoordinate_Umeters().x + Math.abs(distanceToBrowse_Umeter / distanceGerbilToVegetation_Umeter) * this
								.getCoordinate_Umeters().x;
				nextMove_Umeter.y = (distanceToBrowse_Umeter / (distanceGerbilToVegetation_Umeter - distanceToBrowse_Umeter)) * Math.abs(one_vegetation
						.getCoordinate_Umeters().y - this.getCoordinate_Umeters().y) + this.getCoordinate_Umeters().y;
			}
			return true;
		}
		return false;
	}
	/** Use list candidate shelter and interact with the nearest */
	public double actionHide(I_SituatedThing oneThingPerceived) {
		// Put Gerbil in the burrow
		// TODO MS 2017.01 de jlf revoir avec le terrier dans le target
		if (oneThingPerceived != null) {
			if (oneThingPerceived instanceof C_BurrowSystem && !((C_BurrowSystem) oneThingPerceived).isFull())
				this.actionEnterBurrow((C_BurrowSystem) oneThingPerceived);
			else this.actionDig();
		}
		else this.setHasToDisperse(true);// When rodent can't hide
		return -fleeConsumptionEnergy_Ukcal;
	}
	/** Gerbil consumes vegetation biomass and return gain energy */
	protected double actionEat(I_SituatedThing perceivedThings) {
		if ((perceivedThings != null) && (isActive())) {
			actionRandomExitOfBurrow();
			C_Vegetation oneVegetation = (C_Vegetation) perceivedThings;
			oneVegetation.setBiomass_Ugram(oneVegetation.getBiomass_Ugram() - dailyConsumptionOfGerbil_Ugram);
		}
		return eatGainedEnergy_UKcal;
	}
	/** generate a new animal, necessary to use spawn
	 * @see A_Amniote#spawn */
	@Override
	public A_Animal actionGiveBirth(I_DiploidGenome genome) {
		return new C_RodentGerbil(genome);
	}
	public void actionSpawn() {
		super.actionSpawn();
		energy_Ukcal -= spawnConsumptionEnergy_Ukcal;
	}
	/** Return true when the agent can do his action like eat, hide, disperse ,etc... */
	public boolean isActive() {
		int currentTime = A_Protocol.protocolCalendar.get(Calendar.HOUR_OF_DAY);
		if (!(currentTime < hourRelease_Uhour && currentTime > bedTime_Uhour)) return true;
		return false;
	}
	@Override
	public void step_Utick() {
		if (this.currentSoilCell.isFull()) this.setHasToDisperse(true);
		I_SituatedThing oneThing = selectDestination(deliberation(perception()));
		if ((oneThing instanceof C_BurrowSystem) || ((oneThing instanceof C_Vegetation) && ((C_Vegetation) oneThing).getVegetationType().equals(
				SHRUBS))) {
			// Don't run if the current soil cell of this is a burrow
			if (!(this.currentSoilCell instanceof C_BurrowSystem)) this.actionHide(oneThing);
		}
		else {
			this.actionMoveToDestination();
			if (oneThing instanceof C_RodentGerbil) this.actionInteract((C_Rodent) oneThing);
			else if ((oneThing instanceof C_Vegetation) && !((C_Vegetation) oneThing).getVegetationType().equals(SHRUBS)) this.actionEat(oneThing);
		}
		// JLF 10.2016 TODO MS rodent can it move if it's trapped on board?
		if (((C_SoilCell) this.getCurrentSoilCell()).getAffinityLandPlot() != null) {
			if (preMature && ((C_SoilCell) this.getCurrentSoilCell()).getAffinityLandPlot().isFull()) {
				this.setHasToDisperse(true);
				this.getNewRandomDisplacement();
				this.actionMoveToDestination();
			}
		}
		if ((this.getCurrentSoilCell() instanceof C_BurrowSystem) && this.hasToDisperse) actionRandomExitOfBurrow();
		super.step_Utick();
	}
	/** Return true when this can absorb all quantity he gain when he eat */
	public boolean needToEat() {
		return (energy_Ukcal < initialGerbilVitalEnergy_Ukcal - eatGainedEnergy_UKcal);
	}
	//
	// SETTER & GETTER
	//
	public Double getEnergy_Ukcal() {
		return energy_Ukcal;
	}
	/** return true if rodent energy is under the sill of energy */
	public boolean isLowEnergy() {
		return energy_Ukcal <= sillGerbilVitaleEnergy_Ukcal;
	}
	public void setVitalEnergy_Ukcal(Double vitalEnergy_Ukcal) {
		this.energy_Ukcal = vitalEnergy_Ukcal;
	}
	public void setMale(boolean isMale) {
	this.male=isMale;
		
	}
}
