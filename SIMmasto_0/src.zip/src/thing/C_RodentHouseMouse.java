package thing;

import thing.dna.I_DiploidGenome;

/** used only for display, JLF 01.2017 */
public class C_RodentHouseMouse extends A_RodentCommensalSimplified {

	public C_RodentHouseMouse(I_DiploidGenome genome) {
		super(genome);
	}
	/** generate a new animal, necessary to use spawn
	 * @see A_Amniote#spawn */
	@Override
	public A_Animal actionGiveBirth(I_DiploidGenome genome) {
		return new C_RodentHouseMouse(genome);
	}
	/** Mouse boarding only in taxis JLF 01.2017 */
	protected boolean actionTryBoardingVehicle(C_HumanCarrier carrier) {
		if (carrier instanceof C_TaxiMan) return super.actionTryBoardingVehicle(carrier);
		else return false;
	}
}
