/* This source code is licensed under a BSD license as detailed in file SIMmasto_0.license.txt */
package thing;

import java.util.TreeSet;

import thing.dna.C_GenomeSpermatophyta;
import thing.dna.I_DiploidGenome;
import thing.ground.C_SoilCell;
import thing.ground.C_SoilCellSavanna;
import data.constants.I_ConstantGerbil;
import data.converters.C_ConvertTimeAndSpace;
/** Vegetation objects grow depending on rain intensity.
 * @author M.Sall 10.2015, rev. JLF&MS 03.2016 */
public class C_Vegetation extends A_Organism implements I_ConstantGerbil {
	//
	// FIELDS
	//
	private String vegetationType;// TODO JLF 2015.10 put in C_GenomePlantae or equiv.
	private double biomass_Ugram;
	//
	// CONSTRUCTOR
	//
	/** Set vegetation type, initial biomass and growth rate */
	public C_Vegetation(I_DiploidGenome genome) {
		super(genome);
		switch(genome.toString()){
			case "Poacea":vegetationType = GRASSES;
			break;
			case "Fabacea":vegetationType = CROPS;
			break;
			case "Balanites":vegetationType = SHRUBS;
			break;
			case "Acacia":vegetationType = TREES;
			break;
		}
		this.biomass_Ugram = initialVegetationBiomass_Ugram;
	}
	//
	// METHODS
	//
	protected TreeSet<C_SoilCell> deliberation(TreeSet<I_SituatedThing> perceivedThings) {
		return new TreeSet<C_SoilCell>();
	}
	/** Release seeds at a given threshold */
	public void seedsProduction() {}
	/** Compute the change of biomass given the level of rain in the cell.<br>
	 * The model follow a logistic law : biomass <- biomass(t-1) * (1 + growth_rate * ( 1 - biomass(t-1) / carrying_capacity))
	 * Version J.Le Fur & M.Sall, 02-03 2016 */
	@Override
	public void actionGrowOlder_Utick() {
		// TODO MS de JLF 2016/02 Utiliser le super qui fait �a d�j�
		age_Utick++;
		age_Uday += 1 / C_ConvertTimeAndSpace.oneDay_Utick;
		double oneDay_Utick = C_ConvertTimeAndSpace.convertTimeDurationToTick(1, "d");
		// Compute carrying capacity given the class of rain intensity
		// TODO number in source OK JLF 03.2016 rain classes start at 1
		double carryingCapacityWithRain_Ugram = VegetationCarryingCapacity_Ugram +
				(RAIN_VALUE_MULTIPLIER * (((C_SoilCellSavanna) this.currentSoilCell).getRainLevel() - 1));
		// Compute biomass change using the logistic law for grass, crop and shrub
		if (this.vegetationType != TREES && this.vegetationType != BARREN && this.vegetationType != SHRUBS) {// No growth for these vegetation types
			this.biomass_Ugram += (this.getGrowthRate_UgramPerDay() * ((C_SoilCellSavanna) this.currentSoilCell).getRainLevel() * SENSITIVITY)
					/ oneDay_Utick * (1 - this.biomass_Ugram / carryingCapacityWithRain_Ugram);
		}
	}
	@Override
	public void actionMateWithMale(I_ReproducingThing parent2) {}
	@Override
	public A_Animal actionGiveBirth(I_DiploidGenome genome) {
		return null;
	}
	//
	// SETTERS & GETTERS
	//
	public void setBiomass_Ugram(double growBiomass_Ugram) {
		this.biomass_Ugram = growBiomass_Ugram;
	}
	public String getVegetationType() {
		return vegetationType;
	}
	public double getGrowthRate_UgramPerDay() {
		return ((C_GenomeSpermatophyta) this.getGenome()).getGrowthRateValue();
	}
	public double getBiomass_Ugram() {
		return biomass_Ugram;
	}
}
