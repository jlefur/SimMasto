/**
 * 
 */
package thing;
/** @author jlefur, sep.2010 JE.Longueville 2011-01 */
public interface I_LivingThing {

	/** get existence
	 * @return the identification */
	public String getThisName();

	/** @return the birth time step. */
	public double getBirthDate_Utick();

	/** @return the age in time step. */
	public double getAge_Uday();

	/** increment time step */
	public void actionGrowOlder_Utick();

	/** linked to its environment<br>
	 * public void interact() ? */
}
