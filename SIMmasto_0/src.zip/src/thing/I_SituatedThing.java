/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt */
package thing;

import thing.ground.I_Container;
import com.vividsolutions.jts.geom.Coordinate;

/** Any object or agent in a World is a Thing. They all share some basic properties, so these are implemented as an interface.
 * @author kyle wagner, elyk@acm.org 2000 / Jean Le Fur 2007 Version 1.0, Sun Nov 12 00:56:39 2000, rev jlf 03.2015, 02.2017
 * @see A_NDS
 * @see A_VisibleAgent */

public interface I_SituatedThing {

	public Coordinate getCoordinate_Umeters();
	public Coordinate getCoordinate_Ucs();
	public void setCurrentSoilCell(I_Container cell);
	public I_Container getCurrentSoilCell();
	public void discardThis();
}
