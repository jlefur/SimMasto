/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt */
package thing.dna;

import java.util.ArrayList;

/** @author MS 09.2016 */
public class C_GenomeTytoAlba extends C_GenomeAmniota {
	//
	// CONSTRUCTORS
	//
	/** Returns a new Tyto Alba genome. <br>
	 * Trait values references (see comments in source code):<br>
	 */
	public C_GenomeTytoAlba() {
		super();
		alleles.put(LITTER_SIZE, 6.); // source:between 2 and 14 (https://inpn.mnhn.fr/docs/cahab/fiches/Bruant-desroseaux.pdf), number of eggs
		alleles.put(WEANING_AGE_Uday, 60.);// 8 to 12 weeks source:between  (http://www.barnowltrust.org.uk/barn-owl-facts/owlets-young-barn-owls/): weaning is two months, period when chick are feeding by parents
		alleles.put(MATING_LATENCY_Uday, 56.); // source:between 8 and 10 week (http://www.larousse.fr/encyclopedie/vie-sauvage/effraie_des_clochers/184042)
		alleles.put(GESTATION_LENGTH_Uday, 36.); // source:between 30 and 32 more six day of oviposition (https://fr.wikipedia.org/wiki/Chouette_effraie)
		this.alleles.put(SEXUAL_MATURITY_Uday, 386.9);// source :between 1 and 3 years, on average 1.06 year (https://www.registrelep-sararegistry.gc.ca/virtual_sara/files/cosewic/sr_effraie_clochers_0911_fra.pdf)
		makeAmniotaBivalent(this.alleles);
	}

	/** Returns a new Tyto Alba genome. This method is used for genome mate.
	 * @param microsatXsome
	 * @param gonosome
	 * @param autosomes
	 * @see C_GenomeEucaryote#mate */
	public C_GenomeTytoAlba(C_XsomePairMicrosat microsatXsome, C_XsomePairSexual gonosome,
			ArrayList<C_ChromosomePair> autosomes) {
		super(microsatXsome, gonosome, autosomes);
	}
	//
	// GETTER
	//
	@Override
	protected Double getTaxonSignature() {
		return .71;
	}
}
