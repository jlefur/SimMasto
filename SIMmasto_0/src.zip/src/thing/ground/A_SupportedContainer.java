/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt */
package thing.ground;

import com.vividsolutions.jts.geom.Coordinate;

import thing.A_Animal;
import thing.I_SituatedThing;

/** Container that can be put within a C_SoilCell
 * @author J.Le Fur, 03.2015, rev. 09.2015 */
public abstract class  A_SupportedContainer extends C_SoilCell {
	//
	// CONSTRUCTORS
	//
	public A_SupportedContainer() {}
	public A_SupportedContainer(int affinity, int lineNo, int colNo) {
		super(affinity, lineNo, colNo);
	}
	//
	// METHODS
	//
	/** Remove reference to this from the animals targeting this container
	 * @revision JLF 2016.05 */
	@Override
	public void discardThis() {
		for (A_Animal oneAnimal : animalsTargetingMe)
			oneAnimal.setTarget(null);
		this.animalsTargetingMe.clear();
		super.discardThis();
	}
	@Override
	/** Disperse animal if container is full TODO JLF 2016.01 should be valid for any I_container ? rev M.S 2017.02 remove target container of thing after remove it in animalsTargetingMe */
	public boolean agentIncoming(I_SituatedThing thing) {
		boolean test = super.agentIncoming(thing);
		if (test && (thing instanceof A_Animal)) {
			if (this.animalsTargetingMe.remove(thing)) ((A_Animal) thing).setTarget(null);
			((A_Animal) thing).setHasToDisperse(this.isFull());
		}
		return test;
	}
	@Override
	public String toString() {
		return this.name;// + "(" + this.currentSoilCell.getLineNo() + "," + this.currentSoilCell.getColNo() + ")";
	}
	//
	// SETTERS & GETTERS
	//
	@Override
	/** Cell internal point coordinate (patch for cells not in context) is the one of the supporting soil cell
	 * @see C_SoilCell#getInternalPointCoordinate
	 * Version PAMboup 04/2014, rev jlf 03.2015, 04.2016*/
	public Coordinate getCoordinate_Ucs() {
		return this.currentSoilCell.getCoordinate_Ucs();
	}
	@Override
	public Coordinate getCoordinate_Umeters() { // Author PAMboup 04/2014, rev jlf 03.2015
		return this.currentSoilCell.getCoordinate_Umeters();
	}
}