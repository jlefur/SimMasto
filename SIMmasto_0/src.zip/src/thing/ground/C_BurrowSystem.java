/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt  */
package thing.ground;

import java.util.ArrayList;

import simmasto0.C_ContextCreator;
import thing.A_NDS;
import thing.C_RodentFossorial;
import thing.I_SituatedThing;

public class C_BurrowSystem extends A_SupportedContainer {
	//
	// CONSTRUCTOR
	//
	/** Constructor sets the affinity to 10 */
	public C_BurrowSystem(int affinity, int lineNo, int colNo) {
		super(affinity, lineNo, colNo);
		this.setAffinity(BURROW_SYSTEM_AFFINITY);
		this.hasToSwitchFace = true;
	}
	//TODO MS 01-2017 action create burrow and put it in the container
	public static C_BurrowSystem createAndPutBurrowInContainer(I_Container currentSoilCell){
		C_BurrowSystem newBurrow = new C_BurrowSystem(BURROW_SYSTEM_AFFINITY, currentSoilCell.getLineNo(), currentSoilCell.getColNo());
		C_ContextCreator.protocol.contextualizeNewAgentInCell(newBurrow, currentSoilCell);// Put burrow in digger's current soilCell
		return newBurrow;
	}
	//
	// METHOD
	//
	/** One agent from the list is leaving the area of this container agent. Version author Q.Baduel 2008, rev. JLF 12.2015,01.2016 */
	@Override
	public boolean agentLeaving(I_SituatedThing thing) {
		if (super.agentLeaving(thing)) {
			if (this.rodentLoad <= 0) {
				this.discardThis();
				this.setDead(true);// TODO JLF 2017.03 ajout de setDead 
			}
			return true;
		}
		else return false;
	}
	//
	// GETTER
	//
	/** Female capacity of burrowSystem is exceeded
	 * @return boolean true => disperse rodents */
	@Override
	public boolean isFull() {
		ArrayList<A_NDS> femaleList = new ArrayList<A_NDS>();
		for (I_SituatedThing agent : occupantList)
			if (agent instanceof C_RodentFossorial) if (((C_RodentFossorial) agent).isFemale()) femaleList.add((A_NDS) agent);
		if (femaleList.size() >= this.getCarryingCapacity_Urodent()) return true;
		else return false;
	}
	/** Display/Enlight saturated burrows in other color JLF 2016 */
	public double getRed() {
		if (this.isFull()) return 1.0;
		else return 0.0;
	}
}