package thing.ground;
import java.util.TreeSet;

import simmasto0.C_Landscape;
import simmasto0.protocol.A_Protocol;
import thing.C_HumanCarrier;
import thing.I_SituatedThing;
import data.constants.I_ConstantTransportation;

/** a city owns a population size, it also take part of several graphs?
 * @author jlefur 2014 */
public class C_City extends C_LandPlot implements I_ConstantTransportation {
	//
	// FIELDS
	//
	private int humanPopSize_Uindividual;
	//
	// CONSTRUCTOR
	//
	public C_City(C_Landscape groundManager) {
		super(groundManager);
		humanPopSize_Uindividual = DEFAULT_HAMLET_SIZE_Uindividual;
		//affinity = EVENT_AFFINITY_CODES.get(CITY);//comment 10.2016 JLF
	}
	//
	// SETTERS & GETTERS
	//
	@Override
	/** Cities are unique, hence remove the id tag to name the city
	 * @see C_LandPlot#setThisName
	 * @args nullString arg kept for compatibility with NDS args / author J.Le Fur 10.2015*/
	public void setThisName(String nullString) {
		super.setThisName(nullString);
		this.name = this.name.substring(0, this.name.indexOf(NAMES_SEPARATOR));
	}
	public void setHumanPopSize_Uindividual(int popSize_Uindividual) {
		this.humanPopSize_Uindividual = popSize_Uindividual;
	}
	/** get cells of the city that belong to a graph of the given type.
	 * @param graphType the requested graph (for a given vehicle) : road,rail,river
	 * @return a the set of cells of the graph type / author PAM, rev. JLF 09.2014 */
	public TreeSet<C_SoilCellGraphed> getGraphCells(String graphType) {
		TreeSet<C_SoilCellGraphed> graphCellsOfCity = new TreeSet<C_SoilCellGraphed>();
		C_SoilCellGraphed oneGraphedCell = null;
		for (C_SoilCell oneCell : getCells()) {// landPlot getCells returns C_SoilCell objects
			oneGraphedCell = (C_SoilCellGraphed) oneCell;
			if (oneCell.isOfGroundType(graphType)) graphCellsOfCity.add(oneGraphedCell);
		}
		if (graphCellsOfCity.size() == 0) {
			A_Protocol.event("A_ProtocolTransportation.getGraphCells : " + this.myId + " has no " + graphType, isError);
		}
		return graphCellsOfCity; // return si faux
	}
	/** Recursively return a treeset of all carriers including those in the contained containers/ Author Le Fur 08.2015
	 * @return carriers.size(): the number of carriers agent (not accounting for superAgent size) in the container
	 * @see A_Container#getFullRodentList() from where is has been copied */
	public int getFullLoad_Ucarrier() {
		TreeSet<C_HumanCarrier> carriers = new TreeSet<C_HumanCarrier>();
		for (I_SituatedThing agent : getFullOccupantList())
			if (agent instanceof C_HumanCarrier) {
				carriers.add((C_HumanCarrier) agent);
			}
		return carriers.size();
	}
	public int getHumanPopSize_Uthousand() {
		return (int) Math.floor(humanPopSize_Uindividual / 1000); // number in source ok JLF 09.2014
	}
	public int getHumanPopSize_Uindividual() {
		return this.humanPopSize_Uindividual;
	}
	@Override
	public int getCarryingCapacity_Urodent() {
		// TODO numbers in source JLF 2015 getCarryingCapacity_Urodent
		if (this.humanPopSize_Uindividual > 1E5) return (int) (this.humanPopSize_Uindividual / 1E3);
		else if (getHumanPopSize_Uthousand() > 1E4) return (int) (getHumanPopSize_Uindividual() / 1E1);
		else if (getHumanPopSize_Uthousand() > 1E3) return (int) (getHumanPopSize_Uindividual() / 1E0);
		else return getHumanPopSize_Uindividual();
	}
}