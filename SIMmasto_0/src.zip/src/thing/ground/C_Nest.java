package thing.ground;

public class C_Nest extends A_SupportedContainer {
	//
	// CONSTRUCTOR
	//
	/** Constructor sets the affinity to 10 */
	public C_Nest(int affinity, int lineNo, int colNo) {
		super(affinity, lineNo, colNo);
		this.setAffinity(NEST_AFFINITY);
		this.hasToSwitchFace = true;
	}
	@Override
	public boolean isDead() {
		return false;
	}

}