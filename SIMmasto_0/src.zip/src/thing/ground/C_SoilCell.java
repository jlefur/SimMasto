/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt */
package thing.ground;

import java.util.TreeSet;

import com.vividsolutions.jts.geom.Coordinate;

import data.C_Parameters;
import data.constants.I_ConstantString;

/** a soil unit, cell, pixel, ... (initially stood for land parcel)
 * @author Q.Baduel - 2009, JLF 2011, PAM 2013 */
public class C_SoilCell extends A_Container implements I_ConstantString {
	//
	// FIELDS
	//
	protected TreeSet<String> groundTypeList = new TreeSet<String>();
	public C_LandPlot affinityLandPlot;
	protected Coordinate coordinate_Ucs;// things added into soil cells have to be located on the continuous space
	protected Coordinate coordinate_Umeter;
	//
	// CONSTRUCTORS
	//
	/** A simple do nothing constructor necessary for daughter classes */
	public C_SoilCell() {};

	public C_SoilCell(int aff, int lineNo, int colNo) {// added PAMboup 21/12/2012, rev. JLF 07.2015
		affinity = aff;
		this.lineNo = lineNo;
		this.colNo = colNo;
		double cellSize_Ucs = C_Parameters.CELL_SIZE_UcontinuousSpace;
		// These coordinates are those of the center of the cell ( + cellSize_Ucs / 2.0)
		this.coordinate_Ucs = new Coordinate((lineNo * cellSize_Ucs) + cellSize_Ucs / 2.0, (colNo * cellSize_Ucs) + cellSize_Ucs
				/ 2.0);
		this.coordinate_Umeter = new Coordinate(coordinate_Ucs.x * C_Parameters.UCS_WIDTH_Umeter, coordinate_Ucs.y
				* C_Parameters.UCS_WIDTH_Umeter);
	}
	//
	// METHODS
	//
	/** Remove a supported container (was formerly a burrowSystem) from the list of C_SoilCell.
	 * @param container a supported container
	 * @return true if remove succeeded */
	public boolean containerRemoved(A_SupportedContainer container) {
		return occupantList.remove(container);
	}
	public int getCarryingCapacity_Urodent() {
		return affinity;// TODO JLF 03.2015 reminder soil cells K = affinity; i.e., better habitat have higher carrying capacity
	}
	@Override
	public String toString() {
		return this.name + "(" + this.lineNo + "," + this.colNo + ")";
	}
	/** To make this soil cell to be one of the ground types
	 * @param groundType : one ground type */
	public void addGroundType(String groundType) {
		this.groundTypeList.add(groundType);
	}
	public void removeGroundType(String groundType) {
		this.groundTypeList.remove(groundType);
	}
	public C_LandPlot getAffinityLandPlot() {
		return affinityLandPlot;
	}
	/** Inform the landPlot of this soilCell <br>
	 * And add this soilcell to the landPlot.
	 * @param plot */
	public void setAffinityLandPlot(C_LandPlot plot) {
		this.affinityLandPlot = plot;
		plot.addCell(this);
	}
	public boolean isOfGroundType(String groundType) {
		return groundTypeList.contains(groundType);
	}
	/** Don't guaranty order, so do not use iterator with this list. Use just add(), remove() and contains() */
	// TODO PAM de JLF, 10.2015, javadoc obsolete ?
	public TreeSet<String> getGroundTypes() {
		return groundTypeList;
	}
	/** This method replaces landscape.espaceContinu.getLocation(this) because soilCell is not contextualized
	 * Version PAMboup 04/2014
	 * @return Location of the soil cell's center in the continuous space */
	public Coordinate getCoordinate_Ucs() {
		return this.coordinate_Ucs;
	}
	/** Author PAMboup 04/2014
	 * @return coordinate of the soil cell in the Continuous space. */
	@Override
	public Coordinate getCoordinate_Umeters() {
		return this.coordinate_Umeter;
	}

}
