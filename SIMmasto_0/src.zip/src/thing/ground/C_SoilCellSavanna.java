package thing.ground;

import java.util.Calendar;
import java.util.TimeZone;

import data.constants.I_ConstantGerbil;

/** Soil unit able to support rain
 * @author JLF MS 10-2015 */
public class C_SoilCellSavanna extends C_SoilCell implements I_ConstantGerbil {
	//
	// FIELD
	//
	private int rainLevel;

	//
	// CONSTRUCTOR
	//
	public C_SoilCellSavanna(int aff, int lineNo, int colNo) {
		super(aff, lineNo, colNo);
	}
	//
	// SETTER & GETTER
	//
	public void setRainLevel(int rainLevel) {
		this.rainLevel = rainLevel;
	}
	public int getRainLevel() {
		return this.rainLevel;
	}
	public boolean isBreedingSeason() {
		if ((Calendar.getInstance(TimeZone.getDefault()).get(Calendar.MONTH) >= 3) && (this.rainLevel > 1)) return true;
		else return false;
	}
	@Override
	public int getCarryingCapacity_Urodent() {
		return 1000;//TODO MS 02.2017 Junk value and numbering in source
	}
}
