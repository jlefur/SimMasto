/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt */
package thing.ground;

import simmasto0.C_ContextCreator;
import thing.C_RodentCmr;

/** A trap may be opened, closed, full; it can catch rodent
 * @author J.Le Fur and M.Diakhate, july 2013, rev. 27.09.13 */
public class C_Trap extends C_BurrowSystem implements data.constants.I_ConstantCmr {
	//
	// FIELD
	//
	private boolean open = true;
	//
	// CONSTRUCTOR
	//
	public C_Trap(int affinity, int lineNo, int colNo) {
		super(affinity, lineNo, colNo);
	}
	//
	// METHODS
	//
	/** Add rodent in trap's occupantList if : 1� Trap is open, 2� Rodent is not within the trap or a burrow, 3� Trap is not full of
	 * rodents, 4� TRAP_LOADING_PROBA >= randomProbability */
	public void trapRodent(C_RodentCmr rodentBandia) {
		if (this.open && !rodentBandia.trappedOnBoard && TRAP_MAX_LOAD >= this.getLoad_Urodent()
				&& C_ContextCreator.randomGeneratorForDeathProb.nextDouble() <= TRAP_LOADING_PROBA) {
			rodentBandia.trappedOnBoard = true;
			closeTrap();
		}
		else rodentBandia.actionRandomExitOfBurrow();// put rodent besides the trap.
	}
	public void openTrap() {
		this.open = true;
		this.hasToSwitchFace = true;
	}
	public void closeTrap() {
		this.open = false;
		this.hasToSwitchFace = true;
	}
	//
	// GETTERS
	//
	public boolean isOpen() {
		return this.open;
	}
	@Override
	public int getCarryingCapacity_Urodent() {
		return TRAP_MAX_LOAD;
	}
}
