/* This source code is licensed under a BSD licence as detailed in file SIMmasto_0.license.txt */
package thing.ground;

import java.util.TreeSet;
import thing.C_Rodent;
import thing.I_SituatedThing;

/** J.Le Fur 03.2014, rev. 2014-2017 */
public interface I_Container extends I_SituatedThing {

	public boolean agentIncoming(I_SituatedThing a_thing);
	public boolean agentLeaving(I_SituatedThing agent);

	public TreeSet<I_SituatedThing> getOccupantList();
	public TreeSet<I_SituatedThing> getFullOccupantList();
	public TreeSet<C_Rodent> getRodentList();
	public TreeSet<C_Rodent> getFullRodentList();
	public TreeSet<I_Container> getContainerList();
	public int getLoad_Urodent();
	public int getFullLoad_Urodent();
	public int getCarryingCapacity_Urodent();

	public boolean isFull();
	public void setAffinity(int a);
	public int getAffinity();
	public int getLineNo();
	public int getColNo();
}
